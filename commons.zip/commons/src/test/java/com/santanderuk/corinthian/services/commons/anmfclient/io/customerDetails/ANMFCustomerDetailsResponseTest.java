package com.santanderuk.corinthian.services.commons.anmfclient.io.customerDetails;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ANMFCustomerDetailsResponseTest {

    @Test
    public void testLoadingCorrectlyFromTheJson() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = TestDataCreator.generateMortgageCustomerDetailsDefaultResponse();

        OStruc customerOutputStruc = customerDetailsResponse.getCustomerServiceResponse().getOStruc();

        assertEquals("MRS P BARBARINO & MR C C TIDEWATER", customerOutputStruc.getOAccountTitle());
        assertEquals(2, customerOutputStruc.getOCustomerList().size());
        assertEquals(Integer.valueOf(1), customerOutputStruc.getOCustomerList().get(0).getOCustomerNo());
        assertEquals("F", customerOutputStruc.getOCustomerList().get(0).getOBdpType());
        assertEquals(Integer.valueOf(24463250), customerOutputStruc.getOCustomerList().get(0).getOCustomerId());
        assertEquals("MRS", customerOutputStruc.getOCustomerList().get(0).getOCustomerTitle());
        assertEquals("P", customerOutputStruc.getOCustomerList().get(0).getOInitials());
        assertEquals("PATSY", customerOutputStruc.getOCustomerList().get(0).getOForename1());
        assertEquals("forname2", customerOutputStruc.getOCustomerList().get(0).getOForename2());
        assertEquals("forname3", customerOutputStruc.getOCustomerList().get(0).getOForename3());
        assertEquals("BARBARINO", customerOutputStruc.getOCustomerList().get(0).getOSurname());
        assertEquals("23 Merton Avenue", customerOutputStruc.getOCustomerList().get(0).getOCorrespAddr1());
        assertEquals("Hartley", customerOutputStruc.getOCustomerList().get(0).getOCorrespAddr2());
        assertEquals("Longfield", customerOutputStruc.getOCustomerList().get(0).getOCorrespAddr3());
        assertEquals("Kent", customerOutputStruc.getOCustomerList().get(0).getOCorrespAddr4());
        assertEquals("UNITED KINGDOM", customerOutputStruc.getOCustomerList().get(0).getOCorrespCountry());
        assertEquals("DA3 7EB", customerOutputStruc.getOCustomerList().get(0).getOCorrespPostcode());
        assertEquals("UK", customerOutputStruc.getOCustomerList().get(0).getOCorrespCountryCode());
        assertEquals("PROPERTY", customerOutputStruc.getOCustomerList().get(0).getOCorrespAddrType());
        assertEquals("28/10/1966", customerOutputStruc.getOCustomerList().get(0).getODateOfBirth());
        assertEquals("", customerOutputStruc.getOCustomerList().get(0).getOCcnFlag());
        assertEquals("N", customerOutputStruc.getOCustomerList().get(0).getOStaffMortgage());
        assertEquals("F", customerOutputStruc.getOCustomerList().get(0).getOGender());
        assertEquals("FEMALE", customerOutputStruc.getOCustomerList().get(0).getOGenderDesc());
        assertEquals("M", customerOutputStruc.getOCustomerList().get(0).getOMaritalStatus());
        assertEquals("MARRIED", customerOutputStruc.getOCustomerList().get(0).getOMaritalStatusDesc());
        assertEquals("TEST@ISBANUK.COM", customerOutputStruc.getOCustomerList().get(0).getOEMailAddress());
        assertEquals("01670813309", customerOutputStruc.getOCustomerList().get(0).getOHomePhone());
        assertEquals("07777777777", customerOutputStruc.getOCustomerList().get(0).getOMobilePhone());
        assertEquals("01670813308", customerOutputStruc.getOCustomerList().get(0).getOBusinessPhone());
        assertEquals(0, customerOutputStruc.getOCustomerList().get(0).getOBusinessPhoneExt());
        assertEquals("", customerOutputStruc.getOCustomerList().get(0).getOFaxNumber());

    }
}
