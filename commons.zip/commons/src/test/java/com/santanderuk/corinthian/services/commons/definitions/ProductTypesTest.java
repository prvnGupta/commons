package com.santanderuk.corinthian.services.commons.definitions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class ProductTypesTest {

    @Test
    public void testNumberOfValuesIsCorrect() {
        assertEquals(8, ProductTypes.values().length);
    }

    @Test
    public void testListOfValuesIsCorrect() {
        assertEquals(ProductTypes.FIXED, ProductTypes.valueOf("FIXED"));
        assertEquals(ProductTypes.VARIABLE, ProductTypes.valueOf("VARIABLE"));
        assertEquals(ProductTypes.STT, ProductTypes.valueOf("STT"));
        assertEquals(ProductTypes.SVR, ProductTypes.valueOf("SVR"));
        assertEquals(ProductTypes.FOR, ProductTypes.valueOf("FOR"));
        assertEquals(ProductTypes.UNKNOWN, ProductTypes.valueOf("UNKNOWN"));
        assertEquals(ProductTypes.LTT, ProductTypes.valueOf("LTT"));
        assertEquals(ProductTypes.FLEXI, ProductTypes.valueOf("FLEXI"));
    }
}
