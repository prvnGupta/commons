package com.santanderuk.corinthian.services.commons.operativesecurity;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
public class AnmfBelongsToCustomerWithBorrowerListServiceTest {

    public static final String ANMF_BORROWER_INFO_URL = "https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/mortgage-customer-details/accounts/{account}/customers";

    @MockBean
    AnmfCoreClient anmfClient;

    @InjectMocks
    AnmfBelongToCustomerWithBorrowerListService service;

    @SpyBean
    Validations validations;

    @BeforeEach
    public void setUp() {
        initMocks(this);
    }

    @Test
    public void testHappyPath() throws ConnectionException, ValidationsException, IOException {

        String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g ";
        int account = 12345;
        CustomerDetailsResponse customerDetailsResponse = TestDataCreator.generateMortgageCustomerDetailsDefaultResponse();
        when(anmfClient.fetchMortgageCustomerDetailsV4(anyInt(), anyString(), any())).thenReturn(customerDetailsResponse);

        AnmfBelongsToCustomerWithBorrowerList result = service.anmfBelongsToCustomerWithBorrowerList(account, jwtToken, ANMF_BORROWER_INFO_URL, AnmfRegion.A);

        assertTrue(result.getAnmfBelongsToCustomer());
        assertNotNull(result.getCustomerDetailsResponse());
        List<OCustomer> oCustomerList = result.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList();
        assertEquals(2, oCustomerList.size());
        assertEquals(Integer.valueOf(24463250), oCustomerList.get(0).getOCustomerId());
        assertEquals(Integer.valueOf(554), oCustomerList.get(1).getOCustomerId());
        assertEquals("F", oCustomerList.get(0).getOBdpType());
        assertEquals("F", oCustomerList.get(1).getOBdpType());
        assertEquals(554, result.getBdpCustomer().getCustomerNumber());
        assertEquals("F", result.getBdpCustomer().getCustomerType());
    }

    @Test
    public void testAmnfNotBelong() throws ConnectionException, ValidationsException, IOException {

        String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g ";
        int account = 12345;

        CustomerDetailsResponse customerDetailsResponse = TestDataCreator.generateMortgageCustomerDetailsDefaultResponse();
        customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(1).setOCustomerId(555);
        when(anmfClient.fetchMortgageCustomerDetailsV4(anyInt(), anyString(), any())).thenReturn(customerDetailsResponse);

        AnmfBelongsToCustomerWithBorrowerList result = service.anmfBelongsToCustomerWithBorrowerList(account, jwtToken, ANMF_BORROWER_INFO_URL, AnmfRegion.A);

        assertFalse(result.getAnmfBelongsToCustomer());
        assertNotNull(result.getCustomerDetailsResponse());
        List<OCustomer> oCustomerList = result.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList();
        assertEquals(2, oCustomerList.size());
        assertEquals(Integer.valueOf(24463250), oCustomerList.get(0).getOCustomerId());
        assertEquals(Integer.valueOf(555), oCustomerList.get(1).getOCustomerId());
        assertEquals("F", oCustomerList.get(0).getOBdpType());
        assertEquals("F", oCustomerList.get(1).getOBdpType());
        assertEquals(554, result.getBdpCustomer().getCustomerNumber());
        assertEquals("F", result.getBdpCustomer().getCustomerType());
    }

    @Test
    public void testInvalidAccount() {

        String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g ";
        int account = -1;

        ValidationsException e = assertThrows(ValidationsException.class, () -> service.anmfBelongsToCustomerWithBorrowerList(account, jwtToken, ANMF_BORROWER_INFO_URL, AnmfRegion.A));

        assertEquals("EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT", e.getCode());
        assertEquals("The input account format is not valid", e.getMessage());
    }
}
