package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.AnmfPaymentHolidayAmendCancelRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.IStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.PaymentHolidayRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.Request;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response.AnmfPaymentHolidayAmendCancelResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response.ErStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response.OPaymentHoliday;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientPaymentHolidayDetailsAmendCancelTest extends AnmfCoreClientTest {

    public static final String ANMF_PAYMENT_HOLIDAY_AMEND_URL = "https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mortgage-payment-arrangements/v4/{region}/payment/holidayarrangement/request";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    public void testCanFetchFromANMF() throws IOException, ConnectionException {

        mockAnmfWhenEverythingIsOk();

        AnmfPaymentHolidayAmendCancelRequest request = createAnmfPaymentHolidayAmendCancelRequest();
        AnmfPaymentHolidayAmendCancelResponse response = anmfCoreClient.amendCancelPaymentHoliday(request, ANMF_PAYMENT_HOLIDAY_AMEND_URL, AnmfRegion.A);
        List<OPaymentHoliday> oPaymentHolidays = response.getPaymentHolidayResponse().getOPaymentHolidayTab().getOPaymentHoliday();
        ErStruc erStruc = response.getPaymentHolidayResponse().getOPaymentHolidayTab().getErStruc();

        OPaymentHoliday firstElement = oPaymentHolidays.get(0);
        OPaymentHoliday secondElement = oPaymentHolidays.get(1);

        assertEquals(1, firstElement.getOPhSeq());
        assertEquals("A1", firstElement.getOPhStatus());
        assertEquals("ACTIVATED1", firstElement.getOPhStatusDesc());
        assertEquals("EVENT1", firstElement.getOPhEvent());
        assertEquals("EVENT_DATE1", firstElement.getOPhEventDate());
        assertEquals("28/03/2021", firstElement.getOPhReqDate());
        assertEquals("08/04/2021", firstElement.getOPhAppDate());
        assertEquals("05/05/2021", firstElement.getOPhEffDate());
        assertEquals("05/08/2021", firstElement.getOPhEndDate());
        assertEquals(31, firstElement.getOPhTermReqMth());
        assertEquals(1, firstElement.getOPhTermAdjMth());
        assertEquals("SOURCE_CODE_1", firstElement.getOPhSourceCode());
        assertEquals("CAN_MTH_USED_1", firstElement.getOPhCancMthUsed());
        assertEquals("077777771", firstElement.getOPhMobile());
        assertEquals("SDSDSDS1", firstElement.getOPhEmail());


        assertEquals(2, secondElement.getOPhSeq());
        assertEquals("A2", secondElement.getOPhStatus());
        assertEquals("ACTIVATED2", secondElement.getOPhStatusDesc());
        assertEquals("EVENT2", secondElement.getOPhEvent());
        assertEquals("EVENT_DATE2", secondElement.getOPhEventDate());
        assertEquals("28/03/2022", secondElement.getOPhReqDate());
        assertEquals("08/04/2022", secondElement.getOPhAppDate());
        assertEquals("05/05/2022", secondElement.getOPhEffDate());
        assertEquals("05/08/2022", secondElement.getOPhEndDate());
        assertEquals(32, secondElement.getOPhTermReqMth());
        assertEquals(2, secondElement.getOPhTermAdjMth());
        assertEquals("SOURCE_CODE_2", secondElement.getOPhSourceCode());
        assertEquals("CAN_MTH_USED_2", secondElement.getOPhCancMthUsed());
        assertEquals("077777772", secondElement.getOPhMobile());
        assertEquals("SDSDSDS2", secondElement.getOPhEmail());


        assertEquals("er_code_value", erStruc.getErCode());
        assertEquals("er_message_value", erStruc.getErMessage());
        assertEquals("er_progname_value", erStruc.getErProgname());
    }

    @Test
    public void testAnmfCoreDoesNotConnect() {

        mockAnmfWhenDoesNotConnect();

        AnmfPaymentHolidayAmendCancelRequest request = createAnmfPaymentHolidayAmendCancelRequest();
        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.amendCancelPaymentHoliday(request, ANMF_PAYMENT_HOLIDAY_AMEND_URL, AnmfRegion.A));

        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Disabled
    @Test
    public void testDoesRespondWithBadFormat() throws IOException {

        mockAnmfWhenRespondWithBadFormat();

        AnmfPaymentHolidayAmendCancelRequest request = createAnmfPaymentHolidayAmendCancelRequest();
        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.amendCancelPaymentHoliday(request, ANMF_PAYMENT_HOLIDAY_AMEND_URL, AnmfRegion.A));

        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }

    private AnmfPaymentHolidayAmendCancelRequest createAnmfPaymentHolidayAmendCancelRequest() {
        AnmfPaymentHolidayAmendCancelRequest amendCancelRequest = new AnmfPaymentHolidayAmendCancelRequest();

        PaymentHolidayRequest paymentHolidayRequest = new PaymentHolidayRequest();
        Request request = new Request();
        IStruc iStruc = new IStruc();
        iStruc.setIAction("value-setIAction");
        iStruc.setIChannelCode("value-setIChannelCode");
        iStruc.setIMortAccNo("value-setIMortAccNo");
        iStruc.setINewPeriod("value-setINewPeriod");
        iStruc.setISeqNumber(1);
        iStruc.setIUserId("value-setIUserId");
        request.setIStruc(iStruc);
        paymentHolidayRequest.setRequest(request);
        amendCancelRequest.setPaymentHolidayRequest(paymentHolidayRequest);

        return amendCancelRequest;
    }

    private void mockAnmfWhenEverythingIsOk() throws IOException {
        AnmfPaymentHolidayAmendCancelResponse response = generateDefaultPaymentHolidayAmendCancelServiceResponse();
        ResponseEntity<AnmfPaymentHolidayAmendCancelResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private AnmfPaymentHolidayAmendCancelResponse generateDefaultPaymentHolidayAmendCancelServiceResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-amend-cancel.json", AnmfPaymentHolidayAmendCancelResponse.class);
    }

    protected void mockAnmfWhenDoesNotConnect() {
        when(mockRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
    }
}
