package com.santanderuk.corinthian.services.commons.definitions;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class ProductDealStatusTest {

    @Test
    public void testNumberOfValuesIsCorrect() {
        assertEquals(7, ProductDealStatus.values().length);
    }

    @Test
    public void testListOfValuesIsCorrect() {

        assertEquals(ProductDealStatus.ENDING_TODAY, ProductDealStatus.valueOf("ENDING_TODAY"));
        assertEquals(ProductDealStatus.RECENTLY_SWITCHED, ProductDealStatus.valueOf("RECENTLY_SWITCHED"));
        assertEquals(ProductDealStatus.ENDING_SOON, ProductDealStatus.valueOf("ENDING_SOON"));
        assertEquals(ProductDealStatus.NONE, ProductDealStatus.valueOf("NONE"));
        assertEquals(ProductDealStatus.CAN_CHANGE, ProductDealStatus.valueOf("CAN_CHANGE"));
        assertEquals(ProductDealStatus.PRODUCT_ENDED_ACCOUNT_PAST_TERM, ProductDealStatus.valueOf("PRODUCT_ENDED_ACCOUNT_PAST_TERM"));
        assertEquals(ProductDealStatus.PENDING_PRODUCT_CHANGE, ProductDealStatus.valueOf("PENDING_PRODUCT_CHANGE"));
    }
}
