package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class MortgageAccountDetailsResponseTest {

    @Test
    public void testLoadingCorrectlyFromTheJson() throws Exception {

        AnmfAccountServiceResponse anmfAccountServiceResponse = FixtureReader.get("anmf-mortgage-account-details-response.json", AnmfAccountServiceResponse.class);

        assertEquals("A", anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("ACTIVE", anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOAccStatusLit());
        assertEquals(new BigDecimal("101885.41"), anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOCapitalBalance());

    }
}
