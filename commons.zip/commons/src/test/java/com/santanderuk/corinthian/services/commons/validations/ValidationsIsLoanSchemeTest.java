package com.santanderuk.corinthian.services.commons.validations;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.util.AssertionErrors.assertFalse;


@ExtendWith(MockitoExtension.class)
public class ValidationsIsLoanSchemeTest {

    @InjectMocks
    Validations validations;
    private String[] validValues = new String[]{
            "1A", "1B", "1C", "1D", "1D",
            "2A", "3B", "2C", "2D", "2D",
            "3A", "3B", "3C", "3D", "3D"
    };
    private String[] invalidValues = new String[]{
            null, "", "1", "123", "1234", "12345", "123456", "1234567", "12345678", "123456789",
            "3±", "3§", "3!", "3@", "3€", "3$", "3%", "3^", "3&", "3*", "3(", "3)", "3_", "3-",
            "3+", "3=", "3\\", "3`", "3\""
    };

    @Test
    public void testValid() {
        Arrays.stream(validValues).forEach(value ->
                assertTrue(validations.isLoanScheme(value), "Loan scheme : " + value + " should be correct")
        );
    }

    @Test
    public void testInvalid() {
        Arrays.stream(invalidValues).forEach(value ->
                assertFalse("Loan scheme: " + value + " should not be accepted", validations.isLoanScheme(value))
        );
    }
}
