package com.santanderuk.corinthian.services.commons.anmfclient;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SimulationClientTest {
    SimulationClient simulationClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    void setUp() {
        simulationClient = new SimulationClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("clientSecret");
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(generateOKResponseEntity());
        ANMFSimulationResponse simulationResponse = simulationClient.simulate("simulationUrl/simulation)", new ANMFSimulationRequest(), AnmfRegion.A);
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ANMFSimulationResponse.class));
        assertEquals("A", argumentCaptorHttpEntity.getValue().getHeaders().get("Region").get(0));


        assertEquals(6983663, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals(new BigDecimal("36410.89"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOCapBalAftSim());
        assertEquals(new BigDecimal("8679.77"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData().get(0).getOLnIntAftSim());
    }

    @Test
    void testWeMapRegionAsAHeader() throws ConnectionException, IOException {
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(generateOKResponseEntity());
        ANMFSimulationResponse simulationResponse = simulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.W);
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ANMFSimulationResponse.class));
        assertEquals("W", argumentCaptorHttpEntity.getValue().getHeaders().get("Region").get(0));
        assertEquals(6983663, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals(new BigDecimal("36410.89"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOCapBalAftSim());
        assertEquals(new BigDecimal("8679.77"), simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOLoanData().get(0).getOLnIntAftSim());
    }

    @Test
    void testSimulationRestClientExc() {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> simulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.A));
    }

    @Test
    void testSimulationErrorBody() throws ConnectionException, IOException {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(generateKoResponseEntity());
        ANMFSimulationResponse simulationResponse = simulationClient.simulate("simulationUrl/simulation", new ANMFSimulationRequest(), AnmfRegion.A);

        assertEquals(0, simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
        assertEquals("MBSOSIMU", simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getEStruc().getEProgname());
        assertEquals("ERRWSSAP", simulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getEStruc().getECode());
    }

    private ResponseEntity<ANMFSimulationResponse> generateOKResponseEntity() throws IOException {
        ANMFSimulationResponse anmfSimulationResponse = TestDataCreator.generateSimulationResponseOK();
        return new ResponseEntity<>(anmfSimulationResponse, HttpStatus.OK);
    }

    private ResponseEntity<ANMFSimulationResponse> generateKoResponseEntity() throws IOException {
        ANMFSimulationResponse anmfSimulationResponse = TestDataCreator.generateSimulationResponseKo();
        return new ResponseEntity<>(anmfSimulationResponse, HttpStatus.OK);
    }
}
