package com.santanderuk.corinthian.services.commons.operativesecurity;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AdditionalInfo;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AccountBalanceValidatorTest {

    private AccountBalanceValidator accountBalanceValidator;

    @Mock
    private AccountBalancesClient accountBalancesClient;
    @Mock
    private InternalAccountFormatConverter internalAccountFormatConverter;

    @BeforeEach
    void setUp() {
        accountBalanceValidator = new AccountBalanceValidator(accountBalancesClient, internalAccountFormatConverter);
    }

    @Test
    void testWeCallAccountBalancesClientIncludingOverdraft() throws GeneralException {

        BigDecimal feeAmount = new BigDecimal("109.00");
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber();
        partenonAccountNumber.setCompany("1");
        partenonAccountNumber.setCentre("2");
        partenonAccountNumber.setProduct("3");
        partenonAccountNumber.setContract("4");
        String accountBalancesUrl = "fake-account-balances-url";
        List<String> partenonContractIds = singletonList("1234");

        when(internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber)).thenReturn("1234");
        when(accountBalancesClient.fetchBalances(accountBalancesUrl, partenonContractIds)).thenReturn(generateDefaultAccountBalancesResponse());

        accountBalanceValidator.validate(feeAmount, partenonAccountNumber, accountBalancesUrl, false);

        verify(accountBalancesClient, times(1)).fetchBalances(accountBalancesUrl, partenonContractIds);
    }

    @Test
    void testWeCallAccountBalancesClientExcludingOverdraft() throws GeneralException {

        BigDecimal feeAmount = new BigDecimal("100.00");
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber();
        partenonAccountNumber.setCompany("1");
        partenonAccountNumber.setCentre("2");
        partenonAccountNumber.setProduct("3");
        partenonAccountNumber.setContract("4");
        String accountBalancesUrl = "fake-account-balances-url";
        List<String> partenonContractIds = singletonList("1234");

        when(internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber)).thenReturn("1234");
        when(accountBalancesClient.fetchBalances(accountBalancesUrl, partenonContractIds)).thenReturn(generateDefaultAccountBalancesResponse());

        accountBalanceValidator.validate(feeAmount, partenonAccountNumber, accountBalancesUrl, true);

        verify(accountBalancesClient, times(1)).fetchBalances(accountBalancesUrl, partenonContractIds);
    }

    @Test
    void testWeThrowExceptionWhenNoAccountBalancesFoundForAccount() throws GeneralException {

        BigDecimal feeAmount = new BigDecimal("100.00");
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber();
        partenonAccountNumber.setCompany("1");
        partenonAccountNumber.setCentre("2");
        partenonAccountNumber.setProduct("3");
        partenonAccountNumber.setContract("4");
        String accountBalancesUrl = "fake-account-balances-url";
        List<String> partenonContractIds = singletonList("1234");

        when(internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber)).thenReturn("1234");
        when(accountBalancesClient.fetchBalances(accountBalancesUrl, partenonContractIds)).thenReturn(generateNoBalancesFoundForAccount());

        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> accountBalanceValidator.validate(feeAmount, partenonAccountNumber, accountBalancesUrl, false));
        assertThat(validationsException.getCode(), equalTo("EXC_ACCOUNT_BALANCES_NOT_FOUND"));
        assertThat(validationsException.getMessage(), equalTo("No balances found for selected account"));
    }

    @Test
    void testWeThrowExceptionWhenAccountBalanceNotSufficientToPayIncludingOverdraft() throws GeneralException {

        BigDecimal feeAmount = new BigDecimal("62.00");
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber();
        partenonAccountNumber.setCompany("1");
        partenonAccountNumber.setCentre("2");
        partenonAccountNumber.setProduct("3");
        partenonAccountNumber.setContract("4");
        String accountBalancesUrl = "fake-account-balances-url";
        List<String> partenonContractIds = singletonList("1234");

        when(internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber)).thenReturn("1234");
        when(accountBalancesClient.fetchBalances(accountBalancesUrl, partenonContractIds)).thenReturn(generateAccountInsufficientBalanceResponse());

        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> accountBalanceValidator.validate(feeAmount, partenonAccountNumber, accountBalancesUrl, false));
        assertThat(validationsException.getCode(), equalTo("EXC_ACCOUNT_INSUFFICIENT_BALANCE"));
        assertThat(validationsException.getMessage(), equalTo("The account selected does not have enough balance to make payment"));
    }

    @Test
    void testWeThrowExceptionWhenAccountBalanceNotSufficientToPayExcludingOverdraft() throws GeneralException {

        BigDecimal feeAmount = new BigDecimal("55.00");
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber();
        partenonAccountNumber.setCompany("1");
        partenonAccountNumber.setCentre("2");
        partenonAccountNumber.setProduct("3");
        partenonAccountNumber.setContract("4");
        String accountBalancesUrl = "fake-account-balances-url";
        List<String> partenonContractIds = singletonList("1234");

        when(internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber)).thenReturn("1234");
        when(accountBalancesClient.fetchBalances(accountBalancesUrl, partenonContractIds)).thenReturn(generateAccountInsufficientBalanceResponse());

        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> accountBalanceValidator.validate(feeAmount, partenonAccountNumber, accountBalancesUrl, true));
        assertThat(validationsException.getCode(), equalTo("EXC_ACCOUNT_INSUFFICIENT_BALANCE"));
        assertThat(validationsException.getMessage(), equalTo("The account selected does not have enough balance to make payment"));
    }

    private AccountBalancesResponse generateDefaultAccountBalancesResponse() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setPartenonContractId("1234");
        accountBalance.setBalanceIncPending("100.00 C");
        accountBalance.setOverdraftRemaining("10.00 C");
        accountBalances.add(accountBalance);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }

    private AccountBalancesResponse generateAccountInsufficientBalanceResponse() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setPartenonContractId("1234");
        accountBalance.setBalanceIncPending("50.00 C");
        accountBalance.setOverdraftRemaining("10.00 C");
        accountBalances.add(accountBalance);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }

    private AccountBalancesResponse generateNoBalancesFoundForAccount() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AdditionalInfo> additionalInfos = new ArrayList<>();
        AdditionalInfo additionalInfo = new AdditionalInfo();
        additionalInfo.setPartenonContractId("1234");
        additionalInfo.setErrorMessage("NOT CARRIED OUT: ACCOUNT DOES NOT EXIST. ");
        additionalInfos.add(additionalInfo);
        accountBalancesResponse.setAdditionalInfo(additionalInfos);
        List<AccountBalance> accountBalances = new ArrayList<>();
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }
}
