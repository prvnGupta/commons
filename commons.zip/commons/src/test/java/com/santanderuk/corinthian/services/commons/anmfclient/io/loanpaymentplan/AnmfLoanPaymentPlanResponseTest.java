package com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
public class AnmfLoanPaymentPlanResponseTest {

    @Test
    void serializingCorrectlyFromJsonToObject() throws IOException {
        AnmfLoanPaymentPlanResponse response = FixtureReader.get("anmf-loan-payment-plan.json", AnmfLoanPaymentPlanResponse.class);

        assertEquals(61313568, response.getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails().getOBankAccount());
        assertEquals(809103, response.getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails().getOBacsAuthCode());
        assertEquals("06/04/2001", response.getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails().getOPendingAud().get(0).getOAuddisDate());
    }
}
