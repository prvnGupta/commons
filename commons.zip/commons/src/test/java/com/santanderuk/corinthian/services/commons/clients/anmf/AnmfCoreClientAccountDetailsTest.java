package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveFlexiLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnmfCoreClientAccountDetailsTest extends AnmfCoreClientTest {

    public static final String ANMF_ACCOUNT_DETAILS_URL = "https://domain/sanuk/internal/mortgage-account-details/accounts/{account}";

    @Test
    void fetchMortgageAccountDetails() throws IOException, ConnectionException {
        mockAnmfWhenEverythingIsOk();

        AnmfAccountServiceResponse response = anmfCoreClient.fetchMortgageAccountDetailsV5(12345678, ANMF_ACCOUNT_DETAILS_URL, AnmfRegion.A);

        OStruc oStruc = response.getAccountServiceResponse().getResponse().getOStruc();
        assertEquals("A", oStruc.getOAccStatus());
        assertEquals(new BigDecimal("101885.41"), oStruc.getOCapitalBalance());
        assertEquals(new BigDecimal("101885.41"), oStruc.getOOutstandingBalance());
        assertEquals("STANDARD", oStruc.getOMortgageType());

        // testing flexi accounts mapping
        OActiveFlexiLoanDetail oFlexiLoanDetails = oStruc.getOActiveFlexiLoanDetails().get(0);
        assertEquals("3F", oFlexiLoanDetails.getOLoanScheme());
        assertEquals(10, oFlexiLoanDetails.getORemTermMonths());

        // testing linked accounts mapping
        assertEquals(new BigInteger("9035611091666"), oStruc.getOLinkedAccount().get(0).getOLegSysAcNo());
        assertEquals("S", oStruc.getOLinkedAccount().get(0).getOLinkType());

        // testing blocked accounts mapping
        assertEquals("PE", oStruc.getOActiveBlocks().get(0).getOActivityCode());
        assertEquals("blocked", oStruc.getOActiveBlocks().get(0).getOActivityDesc());

        //stepped ERC
        assertEquals("Y", oStruc.getOActiveLoanDetails().get(0).getOErcDetailsGrp().getOErcApplFlag());
        assertEquals(1, oStruc.getOActiveLoanDetails().get(0).getOErcDetailsGrp().getOErcStepDetailsTab().getOErcStepDetails().size());

        //inactive loan
        assertEquals("3R", oStruc.getOInActiveLoanDetails().get(0).getOLoanScheme());
        //inactive flexi loan
        assertEquals("3F", oStruc.getOInActiveFlexiLoanDetails().get(0).getOLoanScheme());

    }

    @Test
    void shouldReturnAnmfIsNotAvailable() {
        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageAccountDetailsV5(1234, ANMF_ACCOUNT_DETAILS_URL, AnmfRegion.A));
        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    void shouldReturnAnmfRespondWithBadFormat() throws IOException {
        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageAccountDetailsV5(1234, ANMF_ACCOUNT_DETAILS_URL, AnmfRegion.A));
        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }

    private void mockAnmfWhenEverythingIsOk() throws IOException {
        AnmfAccountServiceResponse response = FixtureReader.get("anmf-mortgage-account-details-response.json", AnmfAccountServiceResponse.class);

        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(response);
    }

}
