package com.santanderuk.corinthian.services.commons.clients.bksconnect;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.*;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.BdpCustomer;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.ContractsInMccRequest;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.Input;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

class BksConnectMapperTest {

    BksConnectMapper bksConnectMapper;

    @BeforeEach
    void setUp() {
        bksConnectMapper = new BksConnectMapper();
    }

    @Test
    void decorate() {

        ContractsInMccRequest response = bksConnectMapper.getCustomerAccountsRequest(createMccControllerResponse(), createCustomersBdpCredentials());

        assertAll(() -> {
            assertEquals("OFI", response.getDataRequest().getSecurityInput().getChannel());

            Input input = response.getDataRequest().getInput();
            assertEquals("L", input.getOperation());
            assertEquals("INT", input.getPersonalizationChannel());
            assertEquals("INT", input.getElectronicChannel());
            assertEquals("I", input.getBdpCustomer().getBdpCustomertype());
            assertEquals(123123, input.getBdpCustomer().getBdpCustomerCode());
            assertEquals("R", input.getMccPartenonContract().getContractNumber());
            assertEquals("I", input.getMccPartenonContract().getProductTypeCode());
            assertEquals("0015", input.getCompany());
            assertEquals("00000024", input.getService());
        });
    }

    private RetrieveMccResponse createMccControllerResponse() {
        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setContractNumber("R");
        partenonContract.setProductTypeCode("I");
        partenonContract.setCentre(new Centre());

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(partenonContract);

        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();
        dataResponse.setMccContract(mccContract);

        RetrieveMccResponse response = new RetrieveMccResponse();
        response.setDataResponse(dataResponse);
        return response;
    }

    private BdpCustomer createCustomersBdpCredentials() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomerCode(123123);
        bdpCustomer.setBdpCustomertype("I");
        return bdpCustomer;
    }
}
