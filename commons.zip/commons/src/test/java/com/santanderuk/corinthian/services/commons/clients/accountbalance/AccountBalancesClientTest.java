package com.santanderuk.corinthian.services.commons.clients.accountbalance;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static java.util.Arrays.asList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

class AccountBalancesClientTest {

    private AccountBalancesClient accountBalancesClient;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    public static final String BASE_URL = "http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances";

    @BeforeEach
    void setUp() {
        initMocks(this);
        accountBalancesClient = new AccountBalancesClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("client-id-from-config");
    }

    @Test
    void testWeThrowExceptionWhenListIsEmpty() {

        ResponseEntity<AccountBalancesResponse> serviceResponse = generateSuccessfulAccountBalancesResponse();

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenReturn(serviceResponse);

        assertAll(() -> {
            ValidationsException exc = assertThrows(ValidationsException.class, () -> accountBalancesClient.fetchBalances(BASE_URL, new ArrayList<>()));
            assertThat(exc.getCode(), equalTo("EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT"));
            assertThat(exc.getMessage(), equalTo("The list of accounts to retrieve balances for is empty"));
        });
    }

    @Test
    void testWeCallRestTemplateWithCorrectUrlWhenListContainsOneAccount() throws
            ConnectionException, ValidationsException {

        ResponseEntity<AccountBalancesResponse> serviceResponse = generateSuccessfulAccountBalancesResponse();

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenReturn(serviceResponse);

        List<String> partenonContractIds = new ArrayList<>(Collections.singleton("001542483000010379"));

        accountBalancesClient.fetchBalances(BASE_URL, partenonContractIds);

        verify(restTemplate, times(1)).exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379"), eq(HttpMethod.GET), any(), eq(AccountBalancesResponse.class));
    }

    @Test
    void testWeCallRestTemplateWithCorrectUrlWhenListContainsMultipleAccounts() throws
            ConnectionException, ValidationsException {

        ResponseEntity<AccountBalancesResponse> serviceResponse = generateSuccessfulAccountBalancesResponse();

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenReturn(serviceResponse);

        List<String> partenonContractIds = asList("001542483000010379", "001542473000010379");

        accountBalancesClient.fetchBalances(BASE_URL, partenonContractIds);

        verify(restTemplate, times(1)).exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), any(), eq(AccountBalancesResponse.class));
    }

    @Test
    void testWeCallRestTemplateWithCorrectHeaders() throws ConnectionException, ValidationsException {

        ResponseEntity<AccountBalancesResponse> serviceResponse = generateSuccessfulAccountBalancesResponse();

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenReturn(serviceResponse);

        List<String> partenonContractIds = asList("001542483000010379", "001542473000010379");

        accountBalancesClient.fetchBalances(BASE_URL, partenonContractIds);

        verify(restTemplate, times(1)).exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class));
    }

    @Test
    void testWeReturnResponseFromClientCall() throws ConnectionException, ValidationsException {

        ResponseEntity<AccountBalancesResponse> serviceResponse = generateSuccessfulAccountBalancesResponse();

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenReturn(serviceResponse);

        List<String> partenonContractIds = asList("001542483000010379", "001542473000010379");

        AccountBalancesResponse accountBalancesResponse = accountBalancesClient.fetchBalances(BASE_URL, partenonContractIds);

        assertThat(accountBalancesResponse, equalTo(serviceResponse.getBody()));
    }

    @Test
    void testWeHandleRestClientException() {

        when(restTemplate.exchange(eq("http://dummyurl.com/sanuk/internal/accounts-balances/v1/balances?partenoncontractid=001542483000010379,001542473000010379"), eq(HttpMethod.GET), eq(generateExpectedHttpHeaders()), eq(AccountBalancesResponse.class))).thenThrow(RestClientException.class);

        List<String> partenonContractIds = asList("001542483000010379", "001542473000010379");

        assertAll(() -> {
            ConnectionException exc = assertThrows(ConnectionException.class, () -> accountBalancesClient.fetchBalances(BASE_URL, partenonContractIds));
            assertThat(exc.getCode(), equalTo("ACCOUNT_BALANCES_UNAVAILABLE"));
            assertThat(exc.getMessage(), equalTo("Exception while calling Account Balances API"));
        });
    }

    private HttpEntity<Void> generateExpectedHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", "client-id-from-config");
        headers.add("Content-Type", "application/json");
        return new HttpEntity<>(headers);
    }

    private ResponseEntity<AccountBalancesResponse> generateSuccessfulAccountBalancesResponse() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        accountBalancesResponse.setAccountBalances(Collections.singletonList(new AccountBalance()));
        return new ResponseEntity<>(accountBalancesResponse, HttpStatus.OK);
    }
}
