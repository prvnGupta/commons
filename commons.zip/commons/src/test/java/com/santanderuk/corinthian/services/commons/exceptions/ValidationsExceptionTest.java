package com.santanderuk.corinthian.services.commons.exceptions;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ValidationsExceptionTest {

    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(ValidationsException.class));
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        ValidationsException exc = new ValidationsException(ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT);

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        ValidationsException exc = new ValidationsException(ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT, new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUN() {

        String expectedCode = "EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT";
        String expectedMessage = "The input account format is not valid";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ValidationsException exc = new ValidationsException(ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ValidationsException withException = new ValidationsException(ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

}
