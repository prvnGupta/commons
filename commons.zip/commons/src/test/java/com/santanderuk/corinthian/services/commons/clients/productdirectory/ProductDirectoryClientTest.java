package com.santanderuk.corinthian.services.commons.clients.productdirectory;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.clients.productdirectory.io.ProductDetailsResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ProductDirectoryClientTest {

    public static final String PRODUCT_DIRECTORY_URL = "https://dummy-url/mortgage-product-directory/products/conditions";

    public static final String PRODUCT_DESC_DIRECTORY_URL = "https://dummy-url/mortgage-product-directory/products/{productCode}";
    ProductDirectoryClient productDirectoryClient;

    @Mock
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        productDirectoryClient = new ProductDirectoryClient(mockRestTemplate);
    }

    @Test
    public void shouldReturnOkayWhenProductDirectoryIsCalled() throws IOException, ConnectionException, ValidationsException {
        mockProductDirectoryResponseOkay("productdirectory/product-directory-response.json");
        ProductDirectoryResponse response = productDirectoryClient.fetchProductDirectoryData(PRODUCT_DIRECTORY_URL, createQueryParams());

        assertEquals("2022-02-05", response.getFarthestCompletionDate());
        assertEquals("2078-12-02", response.getNearestChargeEndDate());
    }

    @Test
    public void shouldReturnOkayWithProdDescWhenProductDirectoryIsCalled() throws IOException, ConnectionException, ValidationsException {
        mockProductDetailsDirectoryResponseOkay("productdirectory/product-desc-response.json");
        ProductDetailsResponse response = productDirectoryClient.fetchProductDetailsFromDirectoryData("SVV", PRODUCT_DESC_DIRECTORY_URL );

        var product = response.getProduct();

        assertEquals("2 Year Tracker", product.getName());
        assertEquals(new BigDecimal("5.59"), product.getConditions().getInterestRate());
        assertEquals(new BigDecimal("999"), product.getConditions().getProductFee());

    }

    @Test
    public void shouldHandleNoConnectionException() {
        mockProductDirectoryRestClientException();
        ConnectionException e = assertThrows(ConnectionException.class, () -> productDirectoryClient.fetchProductDirectoryData(PRODUCT_DIRECTORY_URL, createQueryParams()));
        assertEquals("500 Product-directory core service return 500 internal error", e.getCode());
        assertEquals("Product-directory core service did not respond correctly", e.getMessage());
    }

    @Test
    public void shouldHandleNoConnectionExceptionDetailsEndpoint() {
        mockProductDirectoryRestClientException();
        ConnectionException e = assertThrows(ConnectionException.class, () -> productDirectoryClient.fetchProductDetailsFromDirectoryData("SVV", PRODUCT_DESC_DIRECTORY_URL ));
        assertEquals("500 Product-directory core service return 500 internal error", e.getCode());
        assertEquals("Product-directory core service did not respond correctly", e.getMessage());
    }

    @Test
    void shouldHandleWhenBadRequestIsReturned() {
        mockProductDirectoryBadRequest();
        ConnectionException e = assertThrows(ConnectionException.class, () -> productDirectoryClient.fetchProductDirectoryData(PRODUCT_DIRECTORY_URL, createQueryParams()));
        assertEquals("400 PRODUCT_DIRECTORY_API_REQUEST_VALIDATION_EXCEPTION", e.getCode());
        assertEquals("Product-directory core service did not respond correctly", e.getMessage());

    }

    @Test
    void shouldHandleWhenBadRequestIsReturnedForDetailsEndpoint() {
        mockProductDirectoryBadRequest();
        ConnectionException e = assertThrows(ConnectionException.class, () -> productDirectoryClient.fetchProductDetailsFromDirectoryData("SVV", PRODUCT_DESC_DIRECTORY_URL ));
        assertEquals("400 PRODUCT_DIRECTORY_API_REQUEST_VALIDATION_EXCEPTION", e.getCode());
        assertEquals("Product-directory core service did not respond correctly", e.getMessage());

    }

    private void mockProductDirectoryBadRequest() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "PRODUCT_DIRECTORY_API_REQUEST_VALIDATION_EXCEPTION", new HttpHeaders(), null, null));
    }

    private QueryParams createQueryParams() {
        QueryParams queryParams = new QueryParams();
        queryParams.setResultFilter("FARTHEST_COMPLETION_DATE,NEAREST_CHARGE_END_DATE");
        queryParams.setApplicationType("INTERNAL_TRANSFER");
        queryParams.setRangeType("STANDARD");
        return queryParams;
    }

    private void mockProductDirectoryResponseOkay(String mockFilePath) throws IOException {
        ProductDirectoryResponse response = FixtureReader.get(mockFilePath, ProductDirectoryResponse.class);
        ResponseEntity<ProductDirectoryResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private void mockProductDetailsDirectoryResponseOkay(String mockFilePath) throws IOException {
        ProductDetailsResponse response = FixtureReader.get(mockFilePath, ProductDetailsResponse.class);
        ResponseEntity<ProductDetailsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private void mockProductDirectoryRestClientException() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "Product-directory core service return 500 internal error", new HttpHeaders(), null, null));
    }
}
