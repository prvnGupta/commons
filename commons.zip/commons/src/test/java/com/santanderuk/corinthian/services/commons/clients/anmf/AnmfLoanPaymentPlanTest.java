package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.LoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.OutputStruc;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnmfLoanPaymentPlanTest extends AnmfCoreClientTest {

    public static final String LOAN_PAYMENT_PLAN_URL = "http://localhost/{region}/{account}";


    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    void fetchLoanPaymentPlanFromAnmf() throws IOException, ConnectionException {
        mockAnmfWhenEverythingIsOk();

        AnmfLoanPaymentPlanResponse response = anmfCoreClient.fetchLoanPaymentPlan(1234, LOAN_PAYMENT_PLAN_URL, AnmfRegion.A);
        assertEquals("21/11/2020", response.getLoanPaymentPlanResponse().getOutputStruc().getOLastPaymentDate());
    }

    @Test
    void anmfIsNotAvailable() {
        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchLoanPaymentPlan(1234, LOAN_PAYMENT_PLAN_URL, AnmfRegion.A));
        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    void anmfRespondWithBadFormat() throws IOException {
        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchLoanPaymentPlan(1234, LOAN_PAYMENT_PLAN_URL, AnmfRegion.A));
        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }

    private void mockAnmfWhenEverythingIsOk() throws IOException {
        AnmfLoanPaymentPlanResponse accountInfoResponse = createLoanPaymentPlanResponse();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(accountInfoResponse);
    }

    public AnmfLoanPaymentPlanResponse createLoanPaymentPlanResponse() {
        OutputStruc outputStruc = new OutputStruc();
        outputStruc.setOLastPaymentDate("21/11/2020");

        LoanPaymentPlanResponse loanPaymentPlanResponse = new LoanPaymentPlanResponse();
        loanPaymentPlanResponse.setOutputStruc(outputStruc);

        AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse = new AnmfLoanPaymentPlanResponse();
        anmfLoanPaymentPlanResponse.setLoanPaymentPlanResponse(loanPaymentPlanResponse);

        return anmfLoanPaymentPlanResponse;
    }
}
