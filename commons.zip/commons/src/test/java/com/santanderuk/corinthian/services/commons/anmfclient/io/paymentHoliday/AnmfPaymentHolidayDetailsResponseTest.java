package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentHoliday;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.AnmfPaymentHolidayResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.OPhList;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.OutputStruc;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AnmfPaymentHolidayDetailsResponseTest {

    @Test
    public void testResponseObjectMatchJsonResponse() throws Exception {
        AnmfPaymentHolidayResponse response = FixtureReader.get("anmf-payment-holiday-response.json", AnmfPaymentHolidayResponse.class);

        OutputStruc outputStruc = response.getPaymentHolidayResponse().getOutputStruc();
        assertEquals(3, outputStruc.getOPhTermMaxMths());
        assertEquals(1, outputStruc.getOPhTermTotGtdMths());
        assertEquals(2, outputStruc.getOPhTermExtElgMths());
        assertEquals("15/04/2020", outputStruc.getOPhSimStrtDtSet());
        assertEquals("15/06/2020", outputStruc.getOPhSimNxpyDtCan());
        assertEquals(2, outputStruc.getOPhList().size());

        OPhList firstElement = outputStruc.getOPhList().get(0);
        OPhList secondElement = outputStruc.getOPhList().get(1);
        EStruc eStruc = outputStruc.getEStruc();

        assertEquals(1, firstElement.getOPhSeq());
        assertEquals("C", firstElement.getOPhStatus());
        assertEquals("CANCELLED", firstElement.getOPhStatusDesc());
        assertEquals("statusDate", firstElement.getOPhStatusDate());
        assertEquals("event", firstElement.getOPhEvent());
        assertEquals("eventDesc", firstElement.getOPhEventDesc());
        assertEquals("eventDate", firstElement.getOPhEventDate());
        assertEquals("28/03/2020", firstElement.getOPhReqDate());
        assertEquals("08/04/2020", firstElement.getOPhAppDate());
        assertEquals("05/05/2020", firstElement.getOPhEffDate());
        assertEquals("05/08/2020", firstElement.getOPhEndDate());
        assertEquals(3, firstElement.getOPhTermReqMths());
        assertEquals(0, firstElement.getOPhTermAdjMths());
        assertEquals(2, firstElement.getOPhTermRemMths());
        assertEquals(0, firstElement.getOPhTermUsedMths());
        assertEquals("S", firstElement.getOPhSourceCode());
        assertEquals("source", firstElement.getOPhSource());
        assertEquals("mobile", firstElement.getOPhMobile());
        assertEquals("email", firstElement.getOPhEmail());
        assertEquals("o_ph_nx_paydt_nend", firstElement.getOPhNxPaydtNend());

        assertEquals(2, secondElement.getOPhSeq());
        assertEquals("A", secondElement.getOPhStatus());
        assertEquals("ACTIVE", secondElement.getOPhStatusDesc());

        assertEquals("e_code", eStruc.getECode());
        assertEquals("e_message", eStruc.getEMessage());
        assertEquals("e_progname", eStruc.getEProgname());
    }

}
