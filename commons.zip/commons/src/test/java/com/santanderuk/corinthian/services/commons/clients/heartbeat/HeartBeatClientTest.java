package com.santanderuk.corinthian.services.commons.clients.heartbeat;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.io.HeartBeatResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
public class HeartBeatClientTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private HeartBeatClient heartBeatClient;

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(heartBeatClient, "getRegionUrl", "getRegionUrl");
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void test_returnsRegionA() throws MaintenanceException, ConnectionException {

        ResponseEntity<HeartBeatResponse> responseEntity = createResponseEntityForRegion("a");

        mockRestTemplateExchange(responseEntity);

        assertEquals(AnmfRegion.A, heartBeatClient.fetchCurrentRegion());
    }

    @Test
    public void test_returnsRegionW() throws MaintenanceException, ConnectionException {

        ResponseEntity<HeartBeatResponse> responseEntity = createResponseEntityForRegion("w");

        mockRestTemplateExchange(responseEntity);

        assertEquals(AnmfRegion.W, heartBeatClient.fetchCurrentRegion());
    }

    @Test
    public void test_returnsRegionX() throws MaintenanceException, ConnectionException {

        ResponseEntity<HeartBeatResponse> responseEntity = createResponseEntityForRegion("x");

        mockRestTemplateExchange(responseEntity);


        assertThrows(MaintenanceException.class, () -> {
          heartBeatClient.fetchCurrentRegion();
        });
    }


    @Test
    public void test_connectionWithHeartBeatFails() throws MaintenanceException {

        Mockito.when(restTemplate.exchange(
                anyString(), any(), any(), Mockito.<Class<HeartBeatResponse>>any())).thenThrow(RestClientException.class);

        try {
            heartBeatClient.fetchCurrentRegion();
        } catch (ConnectionException e) {
            assertEquals("HEARTBEAT_CONNECTION_ERROR", e.getCode());
            assertEquals("An error occurred when trying to connect with heartbeat", e.getMessage());
        }
    }

    private ResponseEntity<HeartBeatResponse> createResponseEntityForRegion(String a) {

        HeartBeatResponse response = new HeartBeatResponse();
        response.setRegion(a);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private void mockRestTemplateExchange(ResponseEntity<HeartBeatResponse> responseEntity) {

        Mockito.when(restTemplate.exchange(
                anyString(), any(), any(), Mockito.<Class<HeartBeatResponse>>any())).
                thenReturn(responseEntity);
    }


}
