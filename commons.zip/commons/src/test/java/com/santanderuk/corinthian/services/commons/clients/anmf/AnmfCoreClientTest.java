package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public abstract class AnmfCoreClientTest {

    @Mock
    RestTemplate mockRestTemplate;

    @Mock
    ObjectMapper mockObjectMapper;

    @InjectMocks
    AnmfCoreClient anmfCoreClient;

    @Mock
    ApiManagerConfig apiManagerConfig;

    AnmfRegion anmfRegion;

    @BeforeEach
    public void setUp() {
        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        Mockito.when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
    }

    protected void mockAnmfWhenDoesNotConnect() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
    }
    protected void mockAnmfWhenPostDoesNotConnect() {
        when(mockRestTemplate.postForEntity(anyString(),any(HttpEntity.class),any(Class.class))).thenThrow(RestClientException.class);
    }

    protected void mockAnmfWhenRespondWithBadFormat() throws IOException {
        ResponseEntity<String> responseEntity = new ResponseEntity<>("{\"gone\": \"bad\"}", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenThrow(JsonMappingException.class);
    }
}
