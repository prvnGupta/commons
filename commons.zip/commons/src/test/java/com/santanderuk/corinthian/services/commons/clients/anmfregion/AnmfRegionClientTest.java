package com.santanderuk.corinthian.services.commons.clients.anmfregion;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.clients.anmfregion.io.AnmfRegionResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class AnmfRegionClientTest {

    AnmfRegionClient anmfRegionClient;

    @Mock
    RestTemplate mockRestTemplate;
    @Mock
    ObjectMapper mockObjectMapper;

    @BeforeEach
    void setUp() {
        anmfRegionClient = new AnmfRegionClient(mockRestTemplate);
        ReflectionTestUtils.setField(anmfRegionClient, "clientSecret", "client-secret");
        ReflectionTestUtils.setField(anmfRegionClient, "clientId", "client-id");
        ReflectionTestUtils.setField(anmfRegionClient, "anmfRegionUrl", "anmf-region-url");
    }

    @Test
    void shouldReturnRegion_A() throws MaintenanceException, ConnectionException, IOException {
        mockAnmfRegion("heartbeat/anmf-region-response-a.json");
        AnmfRegion anmfRegion = anmfRegionClient.fetchCurrentRegion();
        Assertions.assertEquals(AnmfRegion.A, anmfRegion);
    }

    @Test
    void shouldReturnRegion_W() throws MaintenanceException, ConnectionException, IOException {
        mockAnmfRegion("heartbeat/anmf-region-response-w.json");
        AnmfRegion anmfRegion = anmfRegionClient.fetchCurrentRegion();
        Assertions.assertEquals(AnmfRegion.W, anmfRegion);
    }

    @Test
    void shouldReturnRegion_X() throws IOException {
        mockAnmfRegion("heartbeat/anmf-region-response-x.json");
        MaintenanceException e = assertThrows(MaintenanceException.class, () -> anmfRegionClient.fetchCurrentRegion());
        assertEquals("MAINTENANCE_REGION_X", e.getCode());
    }

    @Test
    void shouldReturnAnmfIsNotAvailable() {
        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfRegionClient.fetchCurrentRegion());
        assertEquals("ANMF_REGION_CONNECTION_ERROR", e.getCode());
        assertEquals("An error occurred when trying to connect with anmf region api", e.getMessage());
    }

    private void mockAnmfRegion(String regionFile) throws IOException {
        AnmfRegionResponse response = FixtureReader.get(regionFile, AnmfRegionResponse.class);
        ResponseEntity<AnmfRegionResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(response);
    }

    protected void mockAnmfWhenDoesNotConnect() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
    }

    protected void mockAnmfWhenRespondWithBadFormat() throws IOException {
        ResponseEntity<String> responseEntity = new ResponseEntity<>("{\"gone\": \"bad\"}", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenThrow(JsonMappingException.class);
    }
}
