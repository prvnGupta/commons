package com.santanderuk.corinthian.services.commons;

import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.warning.AnmfWarnResponse;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.clients.insurance.io.GetInstantPriceResponse;

import java.io.IOException;

public class TestDataCreator {
    public static CustomerInformationResponse generateDefaultCustomerCustomerInformationResponseBoth() throws IOException {
        return FixtureReader.get("partydata/customer-information-response.json", CustomerInformationResponse.class);
    }

    public static GetInstantPriceResponse generateDefaultGetInstantPriceResponse() throws IOException {
        return FixtureReader.get("insurance/get-instant-price-response.json", GetInstantPriceResponse.class);
    }

    public static GetInstantPriceResponse generateDefaultGetInstantPriceResponseNoProducts() throws IOException {
        return FixtureReader.get("insurance/get-instant-price-response-no-products.json", GetInstantPriceResponse.class);
    }

    public static CustomerDetailsResponse generateMortgageCustomerDetailsDefaultResponse() throws IOException {
        return FixtureReader.get("mortgage-customer-details-v4.json", CustomerDetailsResponse.class);
    }

    public static ANMFSimulationResponse generateSimulationResponseOK() throws IOException {
        return FixtureReader.get("simulation/default-ok-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateSimulationResponseKo() throws IOException {
        return FixtureReader.get("simulation/default-ko-response.json", ANMFSimulationResponse.class);
    }

    public static ApplyOverpaymentResponse generateApplyOverpaymentResponseOK() throws IOException {
        return FixtureReader.get("applyoverpayment/default-ok-response.json", ApplyOverpaymentResponse.class);
    }

    public static ApplyOverpaymentResponse generateApplyOverpaymentResponseKo() throws IOException {
        return FixtureReader.get("applyoverpayment/default-ko-response.json", ApplyOverpaymentResponse.class);
    }

    public static AnmfWarnResponse generateAccountWarningResponse() throws IOException {
        return FixtureReader.get("accountwarningservice/account-warning-service.json", AnmfWarnResponse.class);
    }
}
