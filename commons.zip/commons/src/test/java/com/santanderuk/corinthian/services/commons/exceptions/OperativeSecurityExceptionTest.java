package com.santanderuk.corinthian.services.commons.exceptions;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class OperativeSecurityExceptionTest {

    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(OperativeSecurityException.class));
    }

    @Test
    public void test_toString() {
        // Expected json string
        String expected = "{\"code\":\"YOUR_CODE\",\"message\":\"Your message\"}";
        OperativeSecurityException exc = new OperativeSecurityException("YOUR_CODE", "Your message");
        assertEquals(expected, exc.toString());
    }

    @Test
    public void test_toString_constructorWithException() {
        // Expected json string
        String expected = "{\"code\":\"YOUR_CODE\",\"message\":\"Your message\"}";
        OperativeSecurityException exc = new OperativeSecurityException("YOUR_CODE", "Your message", new Exception());
        assertEquals(expected, exc.toString());
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        OperativeSecurityException exc = new OperativeSecurityException("YOUR_CODE", "Your message");

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        OperativeSecurityException exc = new OperativeSecurityException("YOUR_CODE", "Your message", new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }
}
