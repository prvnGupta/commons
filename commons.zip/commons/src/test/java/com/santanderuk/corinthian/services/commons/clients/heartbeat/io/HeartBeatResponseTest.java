package com.santanderuk.corinthian.services.commons.clients.heartbeat.io;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class HeartBeatResponseTest {

    @Test
    public void testPojo() {
        HeartBeatResponse response = new HeartBeatResponse();

        response.setCode("ok");
        response.setMessage("Message ok");
        response.setRegion("a");

        assertEquals("ok", response.getCode());
        assertEquals("Message ok", response.getMessage());
        assertEquals("a", response.getRegion());
    }

}
