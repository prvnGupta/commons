package com.santanderuk.corinthian.services.commons.utilities;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.JsonParseException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


@ExtendWith(MockitoExtension.class)

public class JwtUtilitiesTest {

    private String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0QmFja2VuZF9SUzI1NiJ9.eyJpc3MiOiJJbnRlcm5ldEJhY2tlbmQiLCJzdWIiOiIzMmNOUld5dSIsImF1ZCI6WyJjb3JpbnRoaWFuIiwiYW5tZiJdLCJuYmYiOjE1NDQ3ODk0OTUsImV4cCI6MTU0NDc5MzA5NSwiaWF0IjoxNTQ0Nzg5NDk1LCJqdGkiOiI0NDc3YzI3Ni1hYmJlLTQ4NWUtYjlkZi0wZWQ5ZjI0ZDMwZWQiLCJtaXMiOiJbcjpnYXRld2F5XWE6NkI3MzcwMzYzNzhERDI1NUFDOTU5RjhFOkY2NzY4Mzk3MTowMDE1OmViYW5raW5nIiwiZW50IjoicmV0YWlsIiwiZW52IjoiaW50ZXJuZXQifQ.WFjqsxwDMHpB_faHaQsOcqcqaqjob_6d8hXm0RGH7LiRTTfU81B98n-ZqQQHyeqjZE2OnjD5HcJ9h2pkckQx-PYDGFcLih4Kuy30nIsr7AXts7MFGvM3OkLYpjjGb4WwsScJSKadZ-oTpOgdYUdHkgJ74gO2XximzVAgxL_RxSaNqobOjfUU78v5C8v5_GI2PWtDhfu_fevmwsmIV8nWZYOqimPPjA4lRZyasL6C4yYoZOOhKqRFZe4Tl8CDB67J5A0zIy7hWJbLBAYWzw3NQvI-x6n4LadJnnjyK7B-WIlMZIHvi1ndA4x_U1ntV6t2paxvQKeNelwvvcB9ykaqxg";
    private String invalidJwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0QmFja2VuZF9SUzI1NiJ9...eyJpc3MiO";
    private String jwtAuthNoValidation = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0QmFja2VuZF9SUzI1NiIsInZlciI6IjEuMi4wOnNhbnVrIn0.eyJpc3MiOiJJbnRlcm5ldEJhY2tlbmQiLCJzdWIiOiI2eDFXQjc4RyIsImF1ZCI6WyJjb3JpbnRoaWFuIiwiYW5tZiJdLCJuYmYiOjE1NDQ3MTEwNjAsImV4cCI6MTU0NDcxNDY2MCwiaWF0IjoxNTQ0NzExMDYwLCJqdGkiOiJiZmYwNzE3OC1iYWViLTRmMTUtYTk2Yy04NGQzNmJhNWM2MjciLCJtaXMiOiJbcjpnYXRld2F5XSIsImVudCI6InJldGFpbCIsImVudiI6ImludGVybmV0In0.BEfinocgue3ESapjNZOSDfq_DDUM1ioWD1GZXNfJhpvtl-W_s80ex8ue8DmVUsyrKKjn7RYyso9cMEpeobdVAS-ZSD4F_hhKAW2AaJ9vaYxlofWvrj3py7ocdeI6NXl5qCVvt6lV7tU6oId6KyAt4e3mJ6k4FFkxibT02XkrUyuUPgTaihdTTBXaXOAeeUhAsMwC59Sw5D_4mQKMcFLhJ7dwOGHz4uLyDwS9c0N4oakenyej5QV-IFxaYjGiErtaR_-xxPW-qKea4HHL-aS2HdgIDprzZhTobuH2_VsBzIeA20R3e5ljZoReBXBvqFhRw5Dv50q3dK8Ha_S43upM4A";

    @Test
    public void testExtractLdapUidFromJwt() throws GeneralException {
        String ldapUid = JwtUtilities.getLdapUidFromJWT(jwtAuth);
        assertEquals("32cNRWyu", ldapUid);
    }

    @Test
    void shouldThrowExceptionForInvalidJwt() {
        JsonParseException e = assertThrows(JsonParseException.class, () -> JwtUtilities.getLdapUidFromJWT(invalidJwtAuth));
        assertEquals("EXC_TECH_INVALID_JWT", e.getCode());
    }

    @Test
    public void testExtractBdpCustomerFromJwt() {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtAuth);
        assertEquals("F", bdpCustomer.getCustomerType());
        assertEquals(67683971, bdpCustomer.getCustomerNumber());
    }

    @Test
    public void testExtractDefaultBdpCustomerWhenNoCustomerOnJwt() {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtAuthNoValidation);
        assertEquals("F", bdpCustomer.getCustomerType());
        assertEquals(999999999, bdpCustomer.getCustomerNumber());
    }

}
