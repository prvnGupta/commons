package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.OutputStructure;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.PropertyEnquiryResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientAddressTest extends AnmfCoreClientTest {

    public static final String ANMF_ADDRESS_URL = "https://domain/sanuk/internal/collateral-asset-administration/accounts/{account}/property";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    public void testCanFetchFromANMFRegionA() throws IOException, ConnectionException {

        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);
        ArgumentCaptor<String> argumentCaptorUrl = ArgumentCaptor.forClass(String.class);

        ANMFPropertyResponse mockedResponse = createAddressResponse();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(argumentCaptorUrl.capture(), any(HttpMethod.class), argumentCaptorHttpEntity.capture(), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(mockedResponse);

        ANMFPropertyResponse response = anmfCoreClient.fetchAddress(1234, ANMF_ADDRESS_URL, AnmfRegion.A);

        assertTrue(argumentCaptorHttpEntity.getValue().getHeaders().containsKey("Region"));
        assertEquals("A", argumentCaptorHttpEntity.getValue().getHeaders().get("Region").get(0));
        assertEquals("https://domain/sanuk/internal/collateral-asset-administration/accounts/1234/property", argumentCaptorUrl.getValue());

        assertEquals("500 Elder Gate", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr1());
        assertNull(response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr2());
        assertEquals("3rd line", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr3());
        assertEquals("4th line", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr4());
        assertEquals("Country_comm", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyCountryComm());

    }

    @Test
    public void testCanFetchFromANMFRegionW() throws IOException, ConnectionException {

        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);
        ArgumentCaptor<String> argumentCaptorUrl = ArgumentCaptor.forClass(String.class);

        ANMFPropertyResponse mockedResponse = createAddressResponse();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(argumentCaptorUrl.capture(), any(HttpMethod.class), argumentCaptorHttpEntity.capture(), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(mockedResponse);

        ANMFPropertyResponse response = anmfCoreClient.fetchAddress(1234, ANMF_ADDRESS_URL, AnmfRegion.W);

        assertTrue(argumentCaptorHttpEntity.getValue().getHeaders().containsKey("Region"));
        assertEquals("W", argumentCaptorHttpEntity.getValue().getHeaders().get("Region").get(0));
        assertEquals("https://domain/sanuk/internal/collateral-asset-administration/accounts/1234/property", argumentCaptorUrl.getValue());

        assertEquals("500 Elder Gate", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr1());
        assertNull(response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr2());
        assertEquals("3rd line", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr3());
        assertEquals("4th line", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyAddr4());
        assertEquals("Country_comm", response.getPropertyEnquiryResponse().getOutputStructure().getOPropertyCountryComm());

    }

    @Test
    public void testAnmfCoreDoesNotConnect() {

        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchAddress(1234, ANMF_ADDRESS_URL, AnmfRegion.A));

        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    public void testDoesRespondWithBadFormat() throws IOException {

        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchAddress(1234, ANMF_ADDRESS_URL, AnmfRegion.A));

        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }

    private ANMFPropertyResponse createAddressResponse() {
        ANMFPropertyResponse response = new ANMFPropertyResponse();
        PropertyEnquiryResponse propertyEnquiryResponse = new PropertyEnquiryResponse();
        OutputStructure output = new OutputStructure();
        output.setOPropertyAddr1("500 Elder Gate");
        output.setOPropertyAddr2(null);
        output.setOPropertyAddr3("3rd line");
        output.setOPropertyAddr4("4th line");
        output.setOPropertyCountryComm("Country_comm");
        propertyEnquiryResponse.setOutputStructure(output);
        response.setPropertyEnquiryResponse(propertyEnquiryResponse);

        return response;

    }
}
