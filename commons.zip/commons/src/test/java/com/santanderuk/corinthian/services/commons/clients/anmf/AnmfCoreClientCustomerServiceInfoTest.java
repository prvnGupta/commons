package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientCustomerServiceInfoTest extends AnmfCoreClientTest {

    public static final String ANMF_CUSTOMER_SERVICE_INFO_URL = "https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/mortgage-customer-details/accounts/{account}/customers";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    public void testCanFetchFromAMF() throws IOException, ConnectionException {

        mockAnmfWhenEverythingIsOk();

        CustomerDetailsResponse response = anmfCoreClient.fetchMortgageCustomerDetailsV4(1234, ANMF_CUSTOMER_SERVICE_INFO_URL, AnmfRegion.A);

        assertEquals(2, response.getCustomerServiceResponse().getOStruc().getOCustomerList().size());
        assertEquals("BARBARINO", response.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("F", response.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOBdpType());
        assertEquals("F", response.getCustomerServiceResponse().getOStruc().getOCustomerList().get(1).getOBdpType());
        assertEquals(24463250, response.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOCustomerId());
        assertEquals(554, response.getCustomerServiceResponse().getOStruc().getOCustomerList().get(1).getOCustomerId());
    }

    @Test
    public void testAnmfCoreDoesNotConnect() {

        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageCustomerDetailsV4(1234, ANMF_CUSTOMER_SERVICE_INFO_URL, AnmfRegion.A));

        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    public void testDoesRespondWithBadFormat() throws IOException {

        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageCustomerDetailsV4(1234, ANMF_CUSTOMER_SERVICE_INFO_URL, AnmfRegion.A));

        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }


    private void mockAnmfWhenEverythingIsOk() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = TestDataCreator.generateMortgageCustomerDetailsDefaultResponse();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(customerDetailsResponse);
    }

}
