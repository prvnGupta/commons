package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;


import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AnmfPaymentHolidayAmendCancelResponseTest {


    @Test
    public void test_data() {


        AnmfPaymentHolidayAmendCancelResponse response = createEmptyAnmfPaymentHolidayAmendCancelResponse();

        OPaymentHoliday oPaymentHoliday = getoPaymentHoliday(response, 0);

        oPaymentHoliday.setOPhSeq(1);
        assertEquals(1, oPaymentHoliday.getOPhSeq());

        oPaymentHoliday.setOPhStatus("status");
        assertEquals("status", oPaymentHoliday.getOPhStatus());

        oPaymentHoliday.setOPhStatusDesc("status_desc");
        assertEquals("status_desc", oPaymentHoliday.getOPhStatusDesc());

        oPaymentHoliday.setOPhEvent("event");
        assertEquals("event", oPaymentHoliday.getOPhEvent());

        oPaymentHoliday.setOPhEventDate("event_date");
        assertEquals("event_date", oPaymentHoliday.getOPhEventDate());

        oPaymentHoliday.setOPhReqDate("req_date");
        assertEquals("req_date", oPaymentHoliday.getOPhReqDate());

        oPaymentHoliday.setOPhAppDate("app_date");
        assertEquals("app_date", oPaymentHoliday.getOPhAppDate());

        oPaymentHoliday.setOPhEffDate("eff_date");
        assertEquals("eff_date", oPaymentHoliday.getOPhEffDate());

        oPaymentHoliday.setOPhEndDate("end_date");
        assertEquals("end_date", oPaymentHoliday.getOPhEndDate());

        oPaymentHoliday.setOPhTermReqMth(2);
        assertEquals(2, oPaymentHoliday.getOPhTermReqMth());

        oPaymentHoliday.setOPhTermAdjMth(3);
        assertEquals(3, oPaymentHoliday.getOPhTermAdjMth());

        oPaymentHoliday.setOPhSourceCode("source_code");
        assertEquals("source_code", oPaymentHoliday.getOPhSourceCode());

        oPaymentHoliday.setOPhCancMthUsed("can_month_used");
        assertEquals("can_month_used", oPaymentHoliday.getOPhCancMthUsed());

        oPaymentHoliday.setOPhMobile("0712345678");
        assertEquals("0712345678", oPaymentHoliday.getOPhMobile());

        oPaymentHoliday.setOPhEmail("e@email.com");
        assertEquals("e@email.com", oPaymentHoliday.getOPhEmail());


    }

    private OPaymentHoliday getoPaymentHoliday(AnmfPaymentHolidayAmendCancelResponse response, int index) {
        return response.getPaymentHolidayResponse().getOPaymentHolidayTab().getOPaymentHoliday().get(index);
    }

    private AnmfPaymentHolidayAmendCancelResponse createEmptyAnmfPaymentHolidayAmendCancelResponse() {
        AnmfPaymentHolidayAmendCancelResponse anmfPaymentHolidayAmendCancelResponse
                = new AnmfPaymentHolidayAmendCancelResponse();


        PaymentHolidayResponse paymentHolidayResponse = new PaymentHolidayResponse();
        OPaymentHolidayTab oPaymentHolidayTab = new OPaymentHolidayTab();
        List<OPaymentHoliday> oPaymentHolidayList = new ArrayList<>();
        ErStruc erStruct = new ErStruc();
        OPaymentHoliday oPaymentHoliday = new OPaymentHoliday();

        oPaymentHolidayList.add(oPaymentHoliday);
        oPaymentHolidayTab.setOPaymentHoliday(oPaymentHolidayList);
        oPaymentHolidayTab.setErStruc(erStruct);
        paymentHolidayResponse.setOPaymentHolidayTab(oPaymentHolidayTab);
        anmfPaymentHolidayAmendCancelResponse.setPaymentHolidayResponse(paymentHolidayResponse);

        return anmfPaymentHolidayAmendCancelResponse;
    }
}
