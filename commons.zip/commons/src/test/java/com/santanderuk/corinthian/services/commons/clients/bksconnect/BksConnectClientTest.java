package com.santanderuk.corinthian.services.commons.clients.bksconnect;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.ServiceInfo;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.ContractsInMccRequest;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class BksConnectClientTest extends BksConnetCommonsBaseTest {

    private BksConnectClient bksConnectClient;

    @MockBean
    private ApiManagerConfig mockConfig;

    @MockBean
    private RestTemplate mockRestTemplate;

    @MockBean
    private BksConnectMapper bksConnectMapper;

    @BeforeEach
    void setUp() {
        bksConnectClient = new BksConnectClient(mockConfig, mockRestTemplate, bksConnectMapper);
        when(mockConfig.getClientIdValue()).thenReturn("client-id");
    }


    @Test
    public void testDefaultRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccResponse retrieveMccResponse = generateDefaultResponseRetrieveMcc();
        ResponseEntity<RetrieveMccResponse> responseEntity
                = new ResponseEntity<>(retrieveMccResponse, HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(RetrieveMccResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccResponse response = bksConnectClient.getMcc("dummy-url", retrieveMccControllerRequest);

        assertEquals("Status", response.getInfo().getStatus());
        assertEquals("Code", response.getInfo().getCode());
        assertEquals("Message", response.getInfo().getMessage());
    }

    @Test
    public void testRetrieveMccFromLdapUid() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccResponse retrieveMccResponse = generateDefaultResponseRetrieveMcc();
        ResponseEntity<RetrieveMccResponse> responseEntity
                = new ResponseEntity<>(retrieveMccResponse, HttpStatus.OK);
        when(bksConnectMapper.getRetrieveMccRequest("ldapUid")).thenReturn(retrieveMccControllerRequest);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(RetrieveMccResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccResponse response = bksConnectClient.getMccFromLdapUid("dummy-url", "ldapUid");

        assertEquals("Status", response.getInfo().getStatus());
        assertEquals("Code", response.getInfo().getCode());
        assertEquals("Message", response.getInfo().getMessage());
    }


    @Test
    public void testHappyPathRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccResponse retrieveMccResponse = generateOkResponseRetrieveMcc();
        ResponseEntity<RetrieveMccResponse> responseEntity
                = new ResponseEntity<>(retrieveMccResponse, HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(RetrieveMccResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccResponse response = bksConnectClient.getMcc("dummy-url", retrieveMccControllerRequest);

        assertEquals("ok", response.getInfo().getStatus());
        assertEquals("", response.getInfo().getCode());
        assertEquals("Data found", response.getInfo().getMessage());
    }


    @Test
    public void testGeneralExceptionRetrieveMcc() throws GeneralException {
        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();
        when(mockRestTemplate.postForEntity(anyString(), any(), eq(RetrieveMccResponse.class)))
                .thenThrow(RestClientException.class);

        assertThrows(ConnectionException.class, () -> bksConnectClient.getMcc("dummy-url", retrieveMccControllerRequest));
    }

    @Test
    public void testIscBusExcRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccResponse retrieveMccResponse = generate500ResponseRetrieveMcc();
        ResponseEntity<RetrieveMccResponse> responseEntity
                = new ResponseEntity<>(retrieveMccResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(RetrieveMccResponse.class)))
                .thenReturn(responseEntity);

        assertThrows(ConnectionException.class, () -> bksConnectClient.getMcc("dummy-url", retrieveMccControllerRequest));
    }


    @Test
    void callIocCoreServiceToGetMccContracts() throws ConnectionException {

        ResponseEntity<ContractsInMccControllerResponse> responseEntity
                = new ResponseEntity<>(generateOkResponseForContractInMcc(), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenReturn(responseEntity);

        ContractsInMccControllerResponse res = bksConnectClient.getCustomerAccount("dummy-url", new ContractsInMccRequest());

        assertEquals("ok", res.getInfo().getStatus());
        assertEquals("", res.getInfo().getCode());
        assertEquals("data found", res.getInfo().getMessage());
    }

    @Test
    void shouldCatchConnectionException() {
        when(mockRestTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenThrow(RestClientException.class);

        assertThrows(ConnectionException.class, () -> {
            bksConnectClient.getCustomerAccount("dummy-url", new ContractsInMccRequest());
        });
    }

    private ContractsInMccControllerResponse generateOkResponseForContractInMcc() {
        ServiceInfo info = new ServiceInfo();
        info.setCode("");
        info.setStatus("ok");
        info.setMessage("data found");

        ContractsInMccControllerResponse response = new ContractsInMccControllerResponse();
        response.setInfo(info);

        return response;
    }
}
