package com.santanderuk.corinthian.services.commons.mappers.anmf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.mappers.View;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LoanPartToViewMapperTest {


    @Test
    public void testIsTrackingBecauseTheProductIsFixed() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 Year Fixed (to check that we remove it)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsVariable() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("year variable");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsYearTrackerSTT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 Year Tracker(Variable)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsStandarVariableRate() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Standard VARIABLE Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsFollowOnRateFOR() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Santander's Follow-On Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsLifeTimeTrackerLTT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Lifetime Tracker(Variable)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsFlexi() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("FLEXIBLE(VARIABLE)");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsUnkown() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("NaNaNaNaNaNaNa....BATMAAAAAAAN!!!!!");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }

    @Test
    public void testIsTrackingBecauseTheProductIsWAT() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("WAT");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }


    @Test
    public void testIsTrackingBecauseTheProductIsNull() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription(null);

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_TRACKING", view.getBodyView().toString());

    }


    @Test
    public void testIsHeaderViewIsFixedForFixedProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 YEAR FIXED");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testIsHeaderViewIsFixedForFixedTrackerProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("2 YEAR TRACKER");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testIsHeaderViewIsNotFixedForSVRProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Standard Variable Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testIsHeaderViewIsNotFixedForSForProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Santander's Follow-on Rate");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testIsHeaderViewIsNotFixedForLifetimeTrackerProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Lifetime Tracker");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testIsHeaderViewIsNotFixedForFlexibleProduct() {

        OActiveLoanDetail oLoan = createLoanWithProductDescription("Flexible");

        View view = new LoanPartToViewMapper().toView(oLoan);

        assertEquals("NOT_FIXED", view.getHeaderView().toString());

    }

    @Test
    public void testWeConvertVariable_And_NonVariableDescription() {

        String productDescription = "2 YEAR FIXED";

        String result = new LoanPartToViewMapper().toAbbreviatedProductDescription(productDescription);

        assertEquals("2 Year Fixed", result);

        productDescription = "TRACKER(VARIABLE)";

        result = new LoanPartToViewMapper().toAbbreviatedProductDescription(productDescription);

        assertEquals("Tracker", result);
    }

    @Test
    public void testWeConvertVariable_And_NonVariableDescriptionWithAbbreviated() {

        String productDescription = "2 YEAR FIXED";

        String result = new LoanPartToViewMapper().toAbbreviatedProductDescription(productDescription);

        assertEquals("2 Year Fixed", result);

        productDescription = "TRACKER(VARIABLE)";

        result = new LoanPartToViewMapper().toAbbreviatedProductDescription(productDescription);

        assertEquals("Tracker", result);
    }

    private OActiveLoanDetail createLoanWithProductDescription(String productDescription) {
        OActiveLoanDetail oLoan = new OActiveLoanDetail();
        oLoan.setOProductDesc(productDescription);
        return oLoan;
    }
}
