package com.santanderuk.corinthian.services.commons.clients.cop;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.clients.cop.io.ConfirmationOfPayeeRequest;
import com.santanderuk.corinthian.services.commons.clients.cop.io.VerificationReportResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class ConfirmationOfPayeeClientTest {

    private ConfirmationOfPayeeClient service;
    private String url;

    @Mock
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        service = new ConfirmationOfPayeeClient(mockRestTemplate);
        url = "https://intra-client-api-pre.santanderuk.pre.corp/sanuk/internal/v1/cop-outbound/handle-outbound";
    }
    @Test
    public void shouldReturnVerificationReportWithNoMatchResponse() throws GeneralException, IOException {
        mockVerificationReportResponseOk("confirmationOfPayee/verification-report-response-no-match.json");
        VerificationReportResponse response = service.fetchCopRequest(url, generateCopRequest());
        assertEquals("Santander UK plc", response.getAudit().getExternalBank());
        assertEquals("99a03400-aa1e-40a6-a1fc-64263afd1db3", response.getAudit().getTrackingID());
        assertEquals("SortCodeAccountNumber", response.getAudit().getSchemeName());
        assertEquals("Personal", response.getAudit().getBusinessPersonalIndicator());
        assertEquals("97726957", response.getAudit().getAccountNumber());
        assertEquals("090127", response.getAudit().getSortCode());
        assertEquals("SUE CONNIE dsd", response.getAudit().getRequestedName());
        assertEquals("", response.getAudit().getSecondaryReference());
        assertEquals("0011", response.getAudit().getBankCode());
        assertEquals("200", response.getAudit().getStatusCodeReturned());
        assertEquals("ANNM", response.getAudit().getReasonCode());
        assertEquals("2023-11-27T11:45:17.702393Z", response.getAudit().getRequestReceivedUTC());
        assertEquals("2023-11-27T11:45:19.105324Z", response.getAudit().getResponseReturnedUTC());
        assertEquals(false, response.getAudit().getIsTimeout());
        assertEquals(false, response.getData().getVerificationReport().getMatched());
        assertEquals("ANNM", response.getData().getVerificationReport().getReasonCode());
        assertEquals("Firstname Surname", response.getData().getVerificationReport().getName());
    }

    @Test
    public void shouldReturnVerificationReportWithMatchResponse() throws GeneralException, IOException {
        mockVerificationReportResponseOk("confirmationOfPayee/verification-report-response-match.json");
        VerificationReportResponse response = service.fetchCopRequest(url, generateCopRequest());
        assertEquals("Santander UK plc", response.getAudit().getExternalBank());
        assertEquals("99a03400-aa1e-40a6-a1fc-64263afd1db3", response.getAudit().getTrackingID());
        assertEquals("SortCodeAccountNumber", response.getAudit().getSchemeName());
        assertEquals("Personal", response.getAudit().getBusinessPersonalIndicator());
        assertEquals("97726957", response.getAudit().getAccountNumber());
        assertEquals("090127", response.getAudit().getSortCode());
        assertEquals("SUE CONNIE dsd", response.getAudit().getRequestedName());
        assertEquals("", response.getAudit().getSecondaryReference());
        assertEquals("0011", response.getAudit().getBankCode());
        assertEquals("200", response.getAudit().getStatusCodeReturned());
        assertEquals("2023-11-27T11:45:17.702393Z", response.getAudit().getRequestReceivedUTC());
        assertEquals("2023-11-27T11:45:19.105324Z", response.getAudit().getResponseReturnedUTC());
        assertEquals(false, response.getAudit().getIsTimeout());
    }

    @Test
    public void shouldHandleWhenBadRequestIsReturned() {
        mockBadRequestException();
        ConnectionException ex = assertThrows(ConnectionException.class, () -> service.fetchCopRequest(url, generateCopRequest()));
        assertEquals("400 API_REQUEST_VALIDATION_EXCEPTION", ex.getCode());
        assertEquals("Error while calling Confirmation Of Payee/handle-outbound api", ex.getMessage());
    }

    @Test
    public void shouldHandleNoConnectionException() {
        mockConnectionException();
        GeneralException ex = assertThrows(GeneralException.class, () -> service.fetchCopRequest(url, generateCopRequest()));
        assertEquals("500 API_INTERNAL_SERVER_ERROR_EXCEPTION", ex.getCode());
        assertEquals("Error while calling Confirmation Of Payee/handle-outbound api", ex.getMessage());
    }

    private void mockBadRequestException() {
        when(mockRestTemplate.postForEntity(anyString(), any(), any())).thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "API_REQUEST_VALIDATION_EXCEPTION", new HttpHeaders(), null, null));
    }

    private void mockConnectionException() {
        when(mockRestTemplate.postForEntity(anyString(), any(), any())).thenThrow(HttpServerErrorException.create(HttpStatus.INTERNAL_SERVER_ERROR, "API_INTERNAL_SERVER_ERROR_EXCEPTION", new HttpHeaders(), null, null));

    }

    private ConfirmationOfPayeeRequest generateCopRequest() throws IOException {
        ConfirmationOfPayeeRequest request = FixtureReader.get("confirmationOfPayee/CopRequest.json", ConfirmationOfPayeeRequest.class);
        return request;
    }

    private void mockVerificationReportResponseOk(String path) throws IOException {
        VerificationReportResponse response = FixtureReader.get("confirmationOfPayee/verification-report-response-no-match.json",
                VerificationReportResponse.class);
        ResponseEntity<VerificationReportResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.postForEntity(anyString(), any(), eq(VerificationReportResponse.class))).thenReturn(responseEntity);
    }
}
