package com.santanderuk.corinthian.services.commons.utilities;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class InternalAccountFormatConverterTest {

    private final InternalAccountFormatConverter internalAccountFormatConverter = new InternalAccountFormatConverter();

    @Test
    void testStringToPartenonFormat() throws GeneralException {
        PartenonAccountNumber partenonAccountNumber = internalAccountFormatConverter.convertStringToPartenonAccountNumber("001542473001234567");
        assertEquals("0015", partenonAccountNumber.getCompany());
        assertEquals("4247", partenonAccountNumber.getCentre());
        assertEquals("300", partenonAccountNumber.getProduct());
        assertEquals("1234567", partenonAccountNumber.getContract());
    }

    @Test
    void testStringToLocalAccountNumber() throws GeneralException {
        LocalAccountNumber localAccountNumber = internalAccountFormatConverter.convertStringToLocalAccountNumber("09012712345678");
        assertEquals("090127", localAccountNumber.getSortcode());
        assertEquals("12345678", localAccountNumber.getAccountNumber());
    }

    @Test
    void testStringToLocalAccountNumber2() throws GeneralException {
        LocalAccountNumber localAccountNumber = internalAccountFormatConverter.convertStringToLocalAccountNumber("SAVINGX1413124WAR");
        assertEquals("SAVING", localAccountNumber.getSortcode());
        assertEquals("X1413124WAR", localAccountNumber.getAccountNumber());
    }

    @Test
    void testStringToLocalAccountNumberEcx() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertStringToLocalAccountNumber("12345"));
    }

    @Test
    void testPartenonToStringExc() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(new PartenonAccountNumber(null, "4247", "300", "1234567")));
    }

    @Test
    void testPartenonToStringExc2() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(new PartenonAccountNumber("0015", "4247", "300", "123456")));
    }

    @Test
    void testPartenonToStringExc3() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(new PartenonAccountNumber("0015", "", "300", "123456")));
    }

    @Test
    void testLocalAccountNumberToString() throws GeneralException {
        String partenonAccountNumberString = internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(new LocalAccountNumber("090127", "12345678"));
        assertEquals("09012712345678", partenonAccountNumberString
        );
    }

    @Test
    void testLocalAccountNumberToStringSavingAcc() throws GeneralException {
        String partenonAccountNumberString = internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(new LocalAccountNumber("SAVING", "X1414123WAR"));
        assertEquals("SAVINGX1414123WAR", partenonAccountNumberString
        );
    }

    @Test
    void testLocalAccountNumberToStringExc() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(new LocalAccountNumber("", "X1414123WAR")));
    }

    @Test
    void testLocalAccountNumberToStringExc2() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(new LocalAccountNumber(null, "X1414123WAR")));
    }


    @Test
    void testLocalAccountNumberToStringExc3() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(new LocalAccountNumber("12345", "X1414123WAR")));
    }

    @Test
    void testPartenonToString() throws GeneralException {
        String partenonAccountNumberString = internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(new PartenonAccountNumber("0015", "4247", "300", "1234567"));
        assertEquals("001542473001234567", partenonAccountNumberString
        );
    }

    @Test
    void testStringToPartenonFormatExc() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertStringToPartenonAccountNumber("00154247300123456"));
    }

    @Test
    void testStringToPartenonFormatExc2() {
        assertThrows(GeneralException.class, () -> internalAccountFormatConverter.convertStringToPartenonAccountNumber(null));
    }
}
