package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsInput;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsOutput;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientRedemptionsTest extends AnmfCoreClientTest {

    public static final String ANMF_REDEMPTIONS_URL = "http://localhost";


    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }


    @Test
    public void testAnmfCoreDoesNotConnect() {

        mockAnmfWhenPostDoesNotConnect();

        RedemptionsInput request = createRedemptionsInput();
        request.setUrl(ANMF_REDEMPTIONS_URL);
        request.setRequest(generateRedemptionsRequest());

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchRedemption(request));
        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    public void testCanFetchFromANMF() throws IOException, ConnectionException {

        mockAnmfWhenEverythingIsOk();

        RedemptionsInput request = createRedemptionsInput();
        request.setUrl(ANMF_REDEMPTIONS_URL);
        request.setRequest(generateRedemptionsRequest());

        ANMFRedemptionsResponse response = anmfCoreClient.fetchRedemption(request);

        RedemptionsOutput outputStruc = response.getMBSORRSTOperationResponse().getOutputStruc();
        assertEquals(new BigDecimal("225"), outputStruc.getDeedHandlingFee());
        assertEquals(new BigDecimal("3.23"), outputStruc.getDailyAmount());
        assertEquals("N", outputStruc.getElectDischarge());
        assertEquals(new BigDecimal("0"), outputStruc.getOverpayment().getCapitalBalance());
        assertEquals(new BigDecimal("0"), outputStruc.getOverpayment().getUnclearAmount());
        assertEquals("TRUE", outputStruc.getOverpayment().getValid());

        assertEquals(new BigDecimal("66748.25"), outputStruc.getRedemptionAmount());
        assertEquals(99, outputStruc.getRedemptionsSeqNumber());
        assertEquals("Y", outputStruc.getRedPrcExist());
        assertEquals("", outputStruc.getRepFeePaid());
        assertEquals("", outputStruc.getSaving().getValid());
        assertEquals(new BigDecimal("0"), outputStruc.getSaving().getUnclearAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getSaving().getUnclearAmount());
        assertEquals(new BigDecimal("63404.58"), outputStruc.getTotalCapitalBalance());
        assertEquals(new BigDecimal("3.23"), outputStruc.getTotalDailyInterestAmount());
        assertEquals(new BigDecimal("61.09"), outputStruc.getTotalInterestAmount());
        assertEquals("LOYAL MOVER CASHBACK", outputStruc.getCashbackCharges().get(0).getSundryTypeDescription());
        assertEquals(new BigDecimal("250"), outputStruc.getCashbackCharges().get(0).getFeeAmount());

        assertEquals(new BigDecimal("1279.6"), outputStruc.getLoans().get(0).getCapitalBalance());
        assertEquals(new BigDecimal("63.98"), outputStruc.getLoans().get(0).getFeeAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(0).getUnclearAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(0).getArrearsBalance());
        assertEquals(new BigDecimal("1.66"), outputStruc.getLoans().get(0).getInterestAmount());
        assertEquals(new BigDecimal("0.09"), outputStruc.getLoans().get(0).getDailyInterestAmount());
        assertEquals(new BigDecimal("2.49"), outputStruc.getLoans().get(0).getLsRate());
        assertEquals("L", outputStruc.getLoans().get(0).getLoanType());

        assertEquals(new BigDecimal("2252.91"), outputStruc.getLoans().get(1).getCapitalBalance());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(1).getFeeAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(1).getUnclearAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(1).getArrearsBalance());
        assertEquals(new BigDecimal("3.64"), outputStruc.getLoans().get(1).getInterestAmount());
        assertEquals(new BigDecimal("0.2"), outputStruc.getLoans().get(1).getDailyInterestAmount());
        assertEquals(new BigDecimal("3.25"), outputStruc.getLoans().get(1).getLsRate());
        assertEquals("L", outputStruc.getLoans().get(1).getLoanType());

        assertEquals(new BigDecimal("59872.07"), outputStruc.getLoans().get(2).getCapitalBalance());
        assertEquals(new BigDecimal("2993.6"), outputStruc.getLoans().get(2).getFeeAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(2).getUnclearAmount());
        assertEquals(new BigDecimal("0"), outputStruc.getLoans().get(2).getArrearsBalance());
        assertEquals(new BigDecimal("55.79"), outputStruc.getLoans().get(2).getInterestAmount());
        assertEquals(new BigDecimal("2.94"), outputStruc.getLoans().get(2).getDailyInterestAmount());
        assertEquals(new BigDecimal("1.79"), outputStruc.getLoans().get(2).getLsRate());
        assertEquals("L", outputStruc.getLoans().get(2).getLoanType());

    }


    private void mockAnmfWhenEverythingIsOk() throws IOException {
        ANMFRedemptionsResponse response = generateDefaultRedemptionsServiceResponse();
        ResponseEntity<ANMFRedemptionsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private ANMFRedemptionsResponse generateDefaultRedemptionsServiceResponse() throws IOException {
        return FixtureReader.get("redemption-illustration/anmf-redemptions-response.json", ANMFRedemptionsResponse.class);
    }

    private RedemptionsInput createRedemptionsInput() {
        RedemptionsInput redemptionsInput = new RedemptionsInput();
        return redemptionsInput;
    }

    private ANMFRedemptionsRequest generateRedemptionsRequest() {

        ANMFRedemptionsRequest anmfRedemptionsRequest = new ANMFRedemptionsRequest();
        anmfRedemptionsRequest.setAccountNumber("12345");
        anmfRedemptionsRequest.setCallingApplication("Application");
        anmfRedemptionsRequest.setChannelType("int");
        anmfRedemptionsRequest.setRedemptionDate("state");
        anmfRedemptionsRequest.setRequestedBy("requester");
        anmfRedemptionsRequest.setSolicitorCode("solCode");
        anmfRedemptionsRequest.setRedemptionDate("date");
        anmfRedemptionsRequest.setStatementEnq("statement");
        anmfRedemptionsRequest.setUserId("userId");

        return anmfRedemptionsRequest;
    }

}
