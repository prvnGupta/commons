package com.santanderuk.corinthian.services.commons.internalaccounts;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.Centre;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.LocalContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractDetails;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractElement;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.operativesecurity.AccountBalanceValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class InternalAccountsValidatorTest {

    private InternalAccountsValidator internalAccountsValidator;

    @Mock
    private AccountBalanceValidator accountBalanceValidator;

    @BeforeEach
    void setUp() {
        internalAccountsValidator = new InternalAccountsValidator(accountBalanceValidator);
    }

    @Test
    void testWeCallCorrectMethodsToValidateSavingAccounts() throws GeneralException {
        internalAccountsValidator.validateAccountBelongToCustomerAndHasBalance(BigDecimal.TEN, generateSavingLocalAccountNumber(), "", generateDefaultContractElements());
        verify(accountBalanceValidator, times(1)).validate(any(), any(), anyString(), anyBoolean());
    }

    @Test
    void testWeCallCorrectMethodsToValidateBankingAccounts() throws GeneralException {
        internalAccountsValidator.validateAccountBelongToCustomerAndHasBalance(BigDecimal.TEN, generateBankingLocalAccountNumber(), "", generateDefaultContractElements());
        verify(accountBalanceValidator, times(1)).validate(any(), any(), anyString(), anyBoolean());
    }

    private LocalAccountNumber generateBankingLocalAccountNumber() {
        LocalAccountNumber localAccountNumber = new LocalAccountNumber();
        localAccountNumber.setSortcode("090127");
        localAccountNumber.setAccountNumber("12345678");
        return localAccountNumber;
    }

    private LocalAccountNumber generateSavingLocalAccountNumber() {
        LocalAccountNumber localAccountNumber = new LocalAccountNumber();
        localAccountNumber.setSortcode("SAVING");
        localAccountNumber.setAccountNumber("X14308166");
        return localAccountNumber;
    }

    private List<ContractElement> generateDefaultContractElements() {
        List<ContractElement> contractElements = new ArrayList<>();
        contractElements.add(generateSavingAccount());
        contractElements.add(generateBankingAccount());
        return contractElements;
    }

    private ContractElement generateSavingAccount() {
        ContractElement contractElement = new ContractElement();
        ContractDetails contractDetails = new ContractDetails();
        PartenonContract partenonContract = generateSavingPartenonContract();
        contractDetails.setPartenonContract(partenonContract);
        contractDetails.setLocalContract(generateSavingLocalContract());
        contractElement.setContractDetails(contractDetails);
        return contractElement;
    }

    private ContractElement generateBankingAccount() {
        ContractElement contractElement = new ContractElement();
        ContractDetails contractDetails = new ContractDetails();
        PartenonContract partenonContract = generateBankingPartenonContract();
        contractDetails.setPartenonContract(partenonContract);
        contractDetails.setLocalContract(generateBankingLocalContract());
        contractElement.setContractDetails(contractDetails);
        return contractElement;
    }

    private LocalContract generateSavingLocalContract() {
        LocalContract localContract = new LocalContract();
        localContract.setLocalContractType("07");
        localContract.setLocalContractNumber("SAVINGX14308166STE");
        return localContract;
    }

    private LocalContract generateBankingLocalContract() {
        LocalContract localContract = new LocalContract();
        localContract.setLocalContractType("07");
        localContract.setLocalContractNumber("09012712345678");
        return localContract;
    }

    private PartenonContract generateSavingPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCentreCode("0015");
        centre.setCompany("4247");
        partenonContract.setProductTypeCode("301");
        partenonContract.setContractNumber("1234567");
        partenonContract.setCentre(centre);
        return partenonContract;
    }

    private PartenonContract generateBankingPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCentreCode("0015");
        centre.setCompany("4247");
        partenonContract.setProductTypeCode("300");
        partenonContract.setContractNumber("1234567");
        partenonContract.setCentre(centre);
        return partenonContract;
    }
}
