package com.santanderuk.corinthian.services.commons.clients.insurance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.clients.insurance.io.GetInstantPriceResponse;
import com.santanderuk.corinthian.services.commons.clients.insurance.io.Product;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class InsuranceClientTest {
    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    private InsuranceClient insuranceClient;

    @BeforeEach
    void setUp() {
        insuranceClient = new InsuranceClient(restTemplate, apiManagerConfig);
    }

    @Test
    void testWeReturnSuccessResponse() throws ConnectionException, IOException {

        ObjectMapper mapper = new ObjectMapper();
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(GetInstantPriceResponse.class))).thenReturn(generateGetInstantPriceResponse());
        GetInstantPriceResponse customerInformationResponse = insuranceClient.getInstantPrice("serviceUrl", "F064400965");

        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(GetInstantPriceResponse.class));

        assertEquals(mapper.readTree("{\"customerId\":{\"customerType\":\"F\",\"customerNumber\":\"064400965\"}}"), mapper.readTree(Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getBody()).toString()));

        assertEquals("F", customerInformationResponse.getCustomerId().getCustomerType());
        assertEquals("064400965", customerInformationResponse.getCustomerId().getCustomerNumber());
        assertEquals("OK", customerInformationResponse.getResponse().getResponseCode());
        assertEquals("Operation successfully", customerInformationResponse.getResponse().getResponseDesc());

        assertEquals(2, customerInformationResponse.getProducts().size());

        Product firstProduct = customerInformationResponse.getProducts().get(0);
        assertEquals(830880, firstProduct.getProductReference());
        assertEquals("315", firstProduct.getPartenonProduct());
        assertEquals("747", firstProduct.getSubProduct());
        assertEquals("10.19", firstProduct.getInstantPrice());
        assertEquals("Y", firstProduct.getIsPriceActive());
        assertEquals("0", firstProduct.getSumAssured());
        assertEquals(0, firstProduct.getTerm());
        assertEquals("S", firstProduct.getSingleJointFlag());
        assertEquals("122.33", firstProduct.getAnnualPrice());

        Product secondProduct = customerInformationResponse.getProducts().get(1);
        assertEquals(0, secondProduct.getProductReference());
        assertEquals("315", secondProduct.getPartenonProduct());
        assertEquals("746", secondProduct.getSubProduct());
        assertEquals("17.94", secondProduct.getInstantPrice());
        assertEquals("Y", secondProduct.getIsPriceActive());
        assertEquals("4800.0", secondProduct.getSumAssured());
        assertEquals(30, secondProduct.getTerm());
        assertEquals("S", secondProduct.getSingleJointFlag());
        assertEquals("215.28", secondProduct.getAnnualPrice());


    }

    @Test
    void testWeReturnSuccessResponseNoProducts() throws ConnectionException, IOException {

        ObjectMapper mapper = new ObjectMapper();
        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(GetInstantPriceResponse.class))).thenReturn(generateGetInstantPriceResponseNoProducts());

        GetInstantPriceResponse customerInformationResponse = insuranceClient.getInstantPrice("serviceUrl", "F064400966");
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(GetInstantPriceResponse.class));

        assertEquals(mapper.readTree("{\"customerId\":{\"customerType\":\"F\",\"customerNumber\":\"064400966\"}}"), mapper.readTree(Objects.requireNonNull(argumentCaptorHttpEntity.getValue().getBody()).toString()));

        assertEquals("F", customerInformationResponse.getCustomerId().getCustomerType());
        assertEquals("064400966", customerInformationResponse.getCustomerId().getCustomerNumber());
        assertEquals("OK", customerInformationResponse.getResponse().getResponseCode());
        assertEquals("Operation successfully", customerInformationResponse.getResponse().getResponseDesc());

        assertEquals(0, customerInformationResponse.getProducts().size());
    }

    @Test()
    void testWeReturnException() {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(GetInstantPriceResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> insuranceClient.getInstantPrice("serviceUrl", "F064400965"));

    }

    private ResponseEntity<GetInstantPriceResponse> generateGetInstantPriceResponse() throws IOException {
        GetInstantPriceResponse getInstantPriceResponse = TestDataCreator.generateDefaultGetInstantPriceResponse();
        return new ResponseEntity<>(getInstantPriceResponse, HttpStatus.OK);
    }

    private ResponseEntity<GetInstantPriceResponse> generateGetInstantPriceResponseNoProducts() throws IOException {
        GetInstantPriceResponse getInstantPriceResponse = TestDataCreator.generateDefaultGetInstantPriceResponseNoProducts();
        return new ResponseEntity<>(getInstantPriceResponse, HttpStatus.OK);
    }

}
