package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.ANMFPaymentArrangementResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AnmfPaymentArrangementsTest extends AnmfCoreClientTest {

    public static final String PAYMENT_ARRANGEMENTS = "http://localhost/mortgage-payment-arrangements/accounts/{account}/arrangements";
    public static final String PARAMETER_TYPE = "OP";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    void shouldFetchMortgageArrangementsCorrectly() throws IOException, ConnectionException {
        mockAnmfWhenEverythingIsOk();

        ANMFPaymentArrangementResponse response = anmfCoreClient.fetchMortgageArrangements(12345678, PAYMENT_ARRANGEMENTS, PARAMETER_TYPE, AnmfRegion.A);

        OPayArrOvpInst oPayarrOvpInst = response.getPaymentArrangementResponse().getOutputStruc().getOPayArrOvpInstList().get(0);
        Assertions.assertEquals(417.01, oPayarrOvpInst.getOPayArrAmountTotal());
        Assertions.assertEquals(2, oPayarrOvpInst.getOPayArrLoanDetails().get(0).getOPayArrLoanOrder());
        Assertions.assertEquals(5, oPayarrOvpInst.getOPayArrLoanDetails().get(1).getOPayArrLoanOrder());
        Assertions.assertEquals(1, oPayarrOvpInst.getOPayArrLoanDetails().get(2).getOPayArrLoanOrder());
    }

    @Test
    void shouldFetchFlexiMortgageArrangementsCorrectly() throws IOException, ConnectionException {
        mockFlexiAnmfPaymentArrangementWhenEverythingIsOk();

        ANMFPaymentArrangementResponse response = anmfCoreClient.fetchMortgageArrangements(12345678, PAYMENT_ARRANGEMENTS, PARAMETER_TYPE, AnmfRegion.A);

        OPayArrOvpInst oPayarrOvpFlexiInst = response.getPaymentArrangementResponse().getOutputStruc().getOPayArrFlexis().get(0);
        Assertions.assertEquals("FIXED OVERPAYMENT", oPayarrOvpFlexiInst.getOPayArrTransaction());
        Assertions.assertEquals(300, oPayarrOvpFlexiInst.getOPayArrAmountTotal());
        Assertions.assertEquals("SAVINGS POT", oPayarrOvpFlexiInst.getOPayArrDestDesc());
        Assertions.assertEquals("03/01/2024", oPayarrOvpFlexiInst.getOPayArrStartDate());
    }

    @Test
    void shouldReturnAnmfIsNotAvailable() {
        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageArrangements(1234, PAYMENT_ARRANGEMENTS, PARAMETER_TYPE, AnmfRegion.A));
        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    void shouldReturnAnmfRespondWithBadFormat() throws IOException {
        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchMortgageArrangements(1234, PAYMENT_ARRANGEMENTS, PARAMETER_TYPE, AnmfRegion.A));
        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }

    private void mockAnmfWhenEverythingIsOk() throws IOException {
        ANMFPaymentArrangementResponse response = FixtureReader.get("anmf-payment-arrangements-response.json", ANMFPaymentArrangementResponse.class);

        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(response);
    }

    private void mockFlexiAnmfPaymentArrangementWhenEverythingIsOk() throws IOException {
        ANMFPaymentArrangementResponse response = FixtureReader.get("anmf-payment-arrangements-flexi-fix-ovp-response.json", ANMFPaymentArrangementResponse.class);

        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(response);
    }
}
