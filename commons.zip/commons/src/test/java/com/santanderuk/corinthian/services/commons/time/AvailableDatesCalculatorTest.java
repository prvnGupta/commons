package com.santanderuk.corinthian.services.commons.time;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AvailableDatesCalculatorTest {


    @Test
    public void testWeReturnTheNextThreeAvailableDatesCorrectlyNoBacsCycle() {
        String initialDate = "01/12/2018";
        String redepmtionDate = "01/04/2023";
        boolean isBacsCycle = false;

        AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();

        AvailableDates availableDates = availableDatesCalculator.createAvailableDates(initialDate, redepmtionDate, isBacsCycle);

        assertEquals("01/12/2018", availableDates.getFirstAvailableDate());
        assertEquals("01/01/2019", availableDates.getSecondAvailableDate());
        assertEquals("01/02/2019", availableDates.getThirdAvailableDate());
        assertEquals("01/01/2023", availableDates.getFinalAvailableEndingDate());
    }

    @Test
    public void testWeReturnTheNextThreeAvailableDatesCorrectlyBacsCycle() {
        String initialDate = "01/12/2018";
        String redepmtionDate = "01/04/2023";
        boolean isBacsCycle = true;

        AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();

        AvailableDates availableDates = availableDatesCalculator.createAvailableDates(initialDate, redepmtionDate, isBacsCycle);

        assertEquals("01/12/2018", availableDates.getFirstAvailableDate());
        assertEquals("01/01/2019", availableDates.getSecondAvailableDate());
        assertEquals("", availableDates.getThirdAvailableDate());
        assertEquals("01/01/2023", availableDates.getFinalAvailableEndingDate());

    }

    @Test
    public void testFirstDateAfterRedemptionDate() {
        String initialDate = "01/12/2018";
        String redepmtionDate = "15/11/2018";
        boolean isBacsCycle = false;

        AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();

        AvailableDates availableDates = availableDatesCalculator.createAvailableDates(initialDate, redepmtionDate, isBacsCycle);

        assertEquals("", availableDates.getFirstAvailableDate());
        assertEquals("", availableDates.getSecondAvailableDate());
        assertEquals("", availableDates.getThirdAvailableDate());
        assertEquals("15/08/2018", availableDates.getFinalAvailableEndingDate());

    }

    @Test
    public void testRedemptionBetween1stAnd2ndAvailableDate() {
        String initialDate = "01/12/2018";
        String redepmtionDate = "15/12/2018";
        boolean isBacsCycle = false;

        AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();

        AvailableDates availableDates = availableDatesCalculator.createAvailableDates(initialDate, redepmtionDate, isBacsCycle);

        assertEquals("01/12/2018", availableDates.getFirstAvailableDate());
        assertEquals("", availableDates.getSecondAvailableDate());
        assertEquals("", availableDates.getThirdAvailableDate());
        assertEquals("15/09/2018", availableDates.getFinalAvailableEndingDate());

    }

    @Test
    public void testRedemptionBetween2ndAnd3rdAvailableDate() {
        String initialDate = "01/12/2018";
        String redepmtionDate = "15/01/2019";
        boolean isBacsCycle = false;

        AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();

        AvailableDates availableDates = availableDatesCalculator.createAvailableDates(initialDate, redepmtionDate, isBacsCycle);

        assertEquals("01/12/2018", availableDates.getFirstAvailableDate());
        assertEquals("01/01/2019", availableDates.getSecondAvailableDate());
        assertEquals("", availableDates.getThirdAvailableDate());
        assertEquals("15/10/2018", availableDates.getFinalAvailableEndingDate());

    }

}
