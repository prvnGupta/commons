package com.santanderuk.corinthian.services.commons.serviceinfo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ServiceInfoCreatorTest {


    @Test
    public void test_serviceCreatorOk() {

        ServiceInfo serviceInfo = ServiceInfoCreator.ok();

        assertEquals("ok", serviceInfo.getStatus());
        assertEquals("", serviceInfo.getCode());
        assertEquals("Data found", serviceInfo.getMessage());

    }

    @Test
    public void test_serviceCreatorKO() {

        GeneralException generalException = new GeneralException("YOUR_CODE", "YOUR_MESSAGE");

        ServiceInfo serviceInfo = ServiceInfoCreator.exception(generalException);

        assertEquals("ko", serviceInfo.getStatus());
        assertEquals("YOUR_CODE", serviceInfo.getCode());
        assertEquals("YOUR_MESSAGE", serviceInfo.getMessage());

    }

    @Test
    public void test_extendsModelBase() {
        ModelBase modelBase = new ModelBase();

        assertTrue(modelBase instanceof Serializable, "Model base does not implements Serializable");
    }

    @Test
    public void test_serviceCreatorKO_parameterIsExceptionType() {

        Exception exception = new Exception("YOUR_MESSAGE");

        ServiceInfo serviceInfo = ServiceInfoCreator.exception(exception);

        assertEquals("ko", serviceInfo.getStatus());
        assertEquals("500", serviceInfo.getCode());
        assertEquals("YOUR_MESSAGE", serviceInfo.getMessage());

    }
}
