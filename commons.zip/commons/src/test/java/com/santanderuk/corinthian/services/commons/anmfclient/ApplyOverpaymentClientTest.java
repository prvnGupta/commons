package com.santanderuk.corinthian.services.commons.anmfclient;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ApplyOverpaymentClientTest {
    ApplyOverpaymentClient applyOverpaymentClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    void setUp() {
        applyOverpaymentClient = new ApplyOverpaymentClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("clientSecret");
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {

        ArgumentCaptor<HttpEntity> argumentCaptorHttpEntity = ArgumentCaptor.forClass(HttpEntity.class);
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(generateOKResponseEntity());
        ApplyOverpaymentResponse applyOverpaymentResponse = applyOverpaymentClient.pay("/sanuk/internal/mortgage-payments/payments", new ApplyOverpaymentRequest(), "eMergeUser2");

        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), argumentCaptorHttpEntity.capture(), eq(ApplyOverpaymentResponse.class));

        assertEquals("eMergeUser2", argumentCaptorHttpEntity.getValue().getHeaders().get("Emerge-User").get(0));
        assertEquals("", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getECode());
        assertEquals("", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getEProgname());
        assertEquals("", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getEMessage());
    }

    @Test
    void testSimulationRestClientExc() {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> applyOverpaymentClient.pay("simulationUrl/{region}/simulation)", new ApplyOverpaymentRequest(), "eMergeUser"));
    }

    @Test
    void testSimulationErrorBody() throws ConnectionException, IOException {
        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(generateKoResponseEntity());
        ApplyOverpaymentResponse applyOverpaymentResponse = applyOverpaymentClient.pay("simulationUrl/{region}/simulation)", new ApplyOverpaymentRequest(), "eMergeUser");

        assertEquals("2404", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getECode());
        assertEquals("IO32129", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getEProgname());
        assertEquals("ERROR", applyOverpaymentResponse.getCreateWsPayReceivedResponse().getResponse().getEStruc().getEMessage());
    }

    private ResponseEntity<ApplyOverpaymentResponse> generateOKResponseEntity() throws IOException {
        ApplyOverpaymentResponse applyOverpaymentResponse = TestDataCreator.generateApplyOverpaymentResponseOK();
        return new ResponseEntity<>(applyOverpaymentResponse, HttpStatus.OK);
    }

    private ResponseEntity<ApplyOverpaymentResponse> generateKoResponseEntity() throws IOException {
        ApplyOverpaymentResponse applyOverpaymentResponse = TestDataCreator.generateApplyOverpaymentResponseKo();
        return new ResponseEntity<>(applyOverpaymentResponse, HttpStatus.OK);
    }
}
