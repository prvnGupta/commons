package com.santanderuk.corinthian.services.commons.serviceinfo;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ServiceInfoTest {

    @Test
    public void test_extendsModelBase() {
        ServiceInfo serviceInfo = ServiceInfoCreator.ok();

        assertTrue(ModelBase.class.isAssignableFrom(ServiceInfo.class), "ServiceInfo doesn't extend ModelBase");
        assertTrue(serviceInfo instanceof Serializable, "ServiceInfo doesn't implements Serializable");
    }

    @Test
    public void test_toString() {
        // Expected json string
        String expected = "{\"status\":\"YOUR_STATUS\",\"code\":\"YOUR_CODE\",\"message\":\"YOUR_MESSAGE\"}";
        ServiceInfo serviceInfo = new ServiceInfo("YOUR_STATUS", "YOUR_CODE", "YOUR_MESSAGE");
        assertEquals(expected, serviceInfo.toString());
    }

    @Test
    public void test_toString_bySetters() {
        // Expected json string
        String expected = "{\"status\":\"YOUR_STATUS\",\"code\":\"YOUR_CODE\",\"message\":\"YOUR_MESSAGE\"}";
        ServiceInfo serviceInfo = new ServiceInfo();

        serviceInfo.setStatus("YOUR_STATUS");
        serviceInfo.setCode("YOUR_CODE");
        serviceInfo.setMessage("YOUR_MESSAGE");


        assertEquals(expected, serviceInfo.toString());
    }


}
