package com.santanderuk.corinthian.services.commons.model;


import org.junit.jupiter.api.Test;

import java.io.Serializable;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ModelBaseTest {

    @Test
    public void test_extendsGeneralException() {
        ModelBase modelBase = new ModelBase();

        assertTrue(modelBase instanceof Serializable, "Model base does not implements Serializable");
    }

    @Test
    public void test_toString() {
        ModelBase modelBase = new ModelBase();

        // Because is the base class does not have any value
        assertEquals("{}", modelBase.toString());
    }

}
