package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.*;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientSetupRegularPaymentTest extends AnmfCoreClientTest {

    public static final String ANMF_SET_UP_REGULAR_URL = "http://localhost/hardcoded";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    public void testSetupRegOvp() throws ConnectionException {

        mockAnmfWhenEverythingIsOk();

        AnmfRegularOverpaymentCUDRequest request = generateExampleSetUpRegularRequest();

        AnmfRegularOverpaymentCUDResponse realResponse = anmfCoreClient.setupRegularPayment(request, ANMF_SET_UP_REGULAR_URL);

        assertEquals("GREAT", realResponse.getOverpaymentArrangementResponse().getOutputStruc().getOOvpInstStatus());
        assertEquals("31/05/2015", realResponse.getOverpaymentArrangementResponse().getOutputStruc().getOOvpInstStartDate());
    }


    private void mockAnmfWhenEverythingIsOk() {
        AnmfRegularOverpaymentCUDResponse setupRegularResponse = createSetupRegularPaymentResponse();
        when(mockRestTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(new ResponseEntity<>(setupRegularResponse, HttpStatus.OK));
    }


    public AnmfRegularOverpaymentCUDResponse createSetupRegularPaymentResponse() {
        RegularOverpaymentOutput outputStruc = new RegularOverpaymentOutput();
        outputStruc.setOOvpInstStatus("GREAT");
        outputStruc.setOOvpInstEndDate("22/01/2022");
        outputStruc.setOOvpInstStartDate("31/05/2015");
        outputStruc.setOOvpInstMonPay(new BigDecimal("600.00"));

        OverpaymentArrangementResponse overpaymentArrangementResponse = new OverpaymentArrangementResponse();
      overpaymentArrangementResponse.setOutputStruc(outputStruc);

        AnmfRegularOverpaymentCUDResponse accountInfoResponse = new AnmfRegularOverpaymentCUDResponse();
        accountInfoResponse.setOverpaymentArrangementResponse(overpaymentArrangementResponse);
        return accountInfoResponse;
    }


    private AnmfRegularOverpaymentCUDRequest generateExampleSetUpRegularRequest() {
        AnmfRegularOverpaymentCUDRequest request = new AnmfRegularOverpaymentCUDRequest();
        OverpaymentArrangementRequest body = new OverpaymentArrangementRequest();
        RegularOverpaymentInput inputStruct = new RegularOverpaymentInput();
        inputStruct.setIBdpNumber(123456789);
        inputStruct.setICallingAppl("OVERPAYMENTS");

        body.setInputStruc(inputStruct);
        request.setOverpaymentArrangementRequest(body);
        return request;
    }
}
