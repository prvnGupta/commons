package com.santanderuk.corinthian.services.commons.utilities;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LogMaskerTest {

    private LogMasker logMasker = new LogMasker();

    @Test
    public void maskStringNull() {
        assertEquals("NULL", logMasker.withContentStatus((String) null));
    }

    @Test
    public void maskStringEmpty() {
        assertEquals("EMPTY", logMasker.withContentStatus(""));
    }

    @Test
    public void maskStringHasSomething() {
        assertEquals("POPULATED", logMasker.withContentStatus("Hello"));
    }
}
