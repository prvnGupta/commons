package com.santanderuk.corinthian.services.commons.exceptions;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class MaintenanceExceptionTest {

    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(MaintenanceException.class));
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        MaintenanceException exc = new MaintenanceException(MaintenanceException.Type.MAINTENANCE_REGION_X);

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        MaintenanceException exc = new MaintenanceException(MaintenanceException.Type.MAINTENANCE_REGION_X, new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_MAINTENANCE_REGION_X() {

        String expectedCode = "MAINTENANCE_REGION_X";
        String expectedMessage = "Maintenance region X";


        MaintenanceException exc = new MaintenanceException(MaintenanceException.Type.MAINTENANCE_REGION_X);
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());
    }

}
