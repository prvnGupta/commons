package com.santanderuk.corinthian.services.commons.clients.lac;

import com.santanderuk.corinthian.services.commons.clients.lac.io.response.LacResponse;
import com.santanderuk.corinthian.services.commons.clients.lac.io.response.OutputList;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;

@ExtendWith(SpringExtension.class)
class LocalAccountConverterClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    private LocalAccountConverterClient localAccountConverterClient;

    @BeforeEach
    void setUp() {
        localAccountConverterClient = new LocalAccountConverterClient(restTemplate, apiManagerConfig);
    }

    @Test
    void testWeReturnSuccessResponse() throws ConnectionException {
        Mockito.when(restTemplate.exchange(anyString(), any(), any(), eq(LacResponse.class))).thenReturn(generateLacResponse());
        String partenonAccount = localAccountConverterClient.localAccountToPartenonFormat("serviceUrl", "09012712345678");
        Assertions.assertEquals("partenonAccount", partenonAccount);
    }

    @Test()
    void testWeReturnException() {
        Mockito.when(restTemplate.exchange(anyString(), any(), any(), eq(LacResponse.class))).thenThrow(RestClientException.class);
        Assertions.assertThrows(ConnectionException.class, () -> localAccountConverterClient.localAccountToPartenonFormat("serviceUrl", "09012712345678"));

    }

    private ResponseEntity<LacResponse> generateLacResponse() {
        LacResponse lacResponse = new LacResponse();
        List<OutputList> outputList = new ArrayList<>(1);
        OutputList outputListElement = new OutputList();
        outputListElement.setContractOutputId("partenonAccount");
        outputListElement.setOutputContractIdentifierType("PTN");
        outputList.add(outputListElement);
        lacResponse.setOutputList(outputList);
        return new ResponseEntity<>(lacResponse, HttpStatus.OK);
    }
}
