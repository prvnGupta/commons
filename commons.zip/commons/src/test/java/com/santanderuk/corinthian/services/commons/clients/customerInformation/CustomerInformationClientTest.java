package com.santanderuk.corinthian.services.commons.clients.customerInformation;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerBasicDataEnquire;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
class CustomerInformationClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ApiManagerConfig apiManagerConfig;

    private CustomerInformationClient customerInformationClient;

    @BeforeEach
    void setUp() {
        customerInformationClient = new CustomerInformationClient(restTemplate, apiManagerConfig);
    }

    @Test
    void testWeReturnSuccessResponse() throws ConnectionException, IOException {
        Mockito.when(restTemplate.exchange(anyString(), any(), any(), eq(CustomerInformationResponse.class))).thenReturn(generateCustomerInformationResponse());
        CustomerInformationResponse customerInformationResponse = customerInformationClient.getCustomerInformation("serviceUrl", "F123456789");
        assertEquals("F000000518", customerInformationResponse.getCustomerId());
        CustomerBasicDataEnquire customerBasicDataEnquire = customerInformationResponse.getCustomerBasicDataEnquire();
        assertEquals("MR", customerBasicDataEnquire.getTitle());
        assertEquals("KITCHENS", customerBasicDataEnquire.getFirstName());
        assertEquals("YANG", customerBasicDataEnquire.getMiddleName());
        assertEquals("HARRIS", customerBasicDataEnquire.getLastName());
        assertEquals("MR KITCHENS YANG HARRIS", customerBasicDataEnquire.getFullName());
        assertEquals("maidenName", customerBasicDataEnquire.getMaidenName());
        assertEquals("countryBirth", customerBasicDataEnquire.getCountryBirth());
        assertEquals("1950-03-03", customerBasicDataEnquire.getBirthDate());
        assertEquals("MALE", customerBasicDataEnquire.getGender());
        assertEquals("NOT DISCLOSED-CUSTOMER REFUSED", customerBasicDataEnquire.getMaritalStatus());
        assertEquals("documentType", customerBasicDataEnquire.getDocumentType());
        assertEquals("documentId", customerBasicDataEnquire.getDocumentId());
        assertEquals("GB", customerBasicDataEnquire.getCountryResidence());
        assertEquals("ES", customerBasicDataEnquire.getNationality());
        assertEquals("secondNationality", customerBasicDataEnquire.getSecondNationality());
        assertEquals("RETIRED", customerBasicDataEnquire.getEmploymentStatus());
        assertEquals("occupation", customerBasicDataEnquire.getOccupation());
        assertEquals("00999", customerBasicDataEnquire.getActivity());
        assertEquals("INDIVIDUALS AND INDIVIDUAL TRUSTS (UK RESIDENT)", customerBasicDataEnquire.getAccountingSector());
        assertEquals("companyName", customerBasicDataEnquire.getCompanyName());
        assertEquals("1992-05-13", customerBasicDataEnquire.getCustomerRegistrationDate());
        assertEquals("companyStartDate", customerBasicDataEnquire.getCompanyStartDate());
        assertEquals("companyEndDate", customerBasicDataEnquire.getCompanyEndDate());
        assertEquals("companyType", customerBasicDataEnquire.getCompanyType());
        assertEquals("companyAdditionalDetail", customerBasicDataEnquire.getCompanyAdditionalDetail());
        assertEquals("tradeName", customerBasicDataEnquire.getTradeName());
        assertEquals("countryIncorporation", customerBasicDataEnquire.getCountryIncorporation());
        assertEquals("NONE INDICATED", customerBasicDataEnquire.getEducationalLevel());
        assertEquals("NO", customerBasicDataEnquire.getStaff());
        assertEquals("9999-12-31", customerBasicDataEnquire.getDateDeceased());
        assertEquals(0, customerBasicDataEnquire.getConfidentialityLevel());
        assertEquals("CUSTOMER", customerBasicDataEnquire.getInformationSource());
        assertEquals("UK RETAIL", customerBasicDataEnquire.getCompanyCustomer());
        assertEquals("en-GB", customerBasicDataEnquire.getCustomerPreferredLanguage());
        assertEquals("SELECT", customerBasicDataEnquire.getStructuralSegment());
        assertEquals(false, customerBasicDataEnquire.getHighconfidentialityFlag());
        assertEquals("AKA GOKU", customerBasicDataEnquire.getKnowAs());
        assertEquals("suffix", customerBasicDataEnquire.getSuffix());
        assertEquals("countryFiscalResidence", customerBasicDataEnquire.getCountryFiscalResidence());
        assertEquals("2016-06-30", customerBasicDataEnquire.getLastDateUpdatedBasicData());
        assertEquals("2006-06-01", customerBasicDataEnquire.getResidentialAddress().getLastEffectiveDateUpdated());
        assertEquals("RESIDENTIAL", customerBasicDataEnquire.getResidentialAddress().getTypeUse());
        assertEquals("1992-05-13", customerBasicDataEnquire.getResidentialAddress().getEffectiveDate());
        assertEquals("CUSTOMER", customerBasicDataEnquire.getResidentialAddress().getInformationSource());
        assertEquals("PERSONAL", customerBasicDataEnquire.getResidentialAddress().getPostboxType());

        assertEquals(true, customerBasicDataEnquire.getContactDetailsEnquire().getPhoneDetailsEnquire().getPreferredContact());
        assertEquals("44-01908777555", customerBasicDataEnquire.getContactDetailsEnquire().getPhoneDetailsEnquire().getPhone());
        assertEquals("RESIDENTIAL", customerBasicDataEnquire.getContactDetailsEnquire().getPhoneDetailsEnquire().getUse());
        assertEquals("00:00:00", customerBasicDataEnquire.getContactDetailsEnquire().getPhoneDetailsEnquire().getAvailibilityPhone().getFromTimePhone());
        assertEquals("23:59:00", customerBasicDataEnquire.getContactDetailsEnquire().getPhoneDetailsEnquire().getAvailibilityPhone().getToTimePhone());

        assertEquals(false, customerBasicDataEnquire.getContactDetailsEnquire().getMobileDetailsEnquire().getPreferredContact());
        assertEquals("44-07908777555", customerBasicDataEnquire.getContactDetailsEnquire().getMobileDetailsEnquire().getMobile());
        assertEquals("MOBILE", customerBasicDataEnquire.getContactDetailsEnquire().getMobileDetailsEnquire().getUse());
        assertEquals("00:00:00", customerBasicDataEnquire.getContactDetailsEnquire().getMobileDetailsEnquire().getAvailibilityMobile().getFromTimeMobile());
        assertEquals("23:59:00", customerBasicDataEnquire.getContactDetailsEnquire().getMobileDetailsEnquire().getAvailibilityMobile().getToTimeMobile());

        assertEquals(false, customerBasicDataEnquire.getContactDetailsEnquire().getEmailDetailsEnquire().getPreferredContact());
        assertEquals("goku@gmail.com", customerBasicDataEnquire.getContactDetailsEnquire().getEmailDetailsEnquire().getAddress());
        assertEquals("EMAIL", customerBasicDataEnquire.getContactDetailsEnquire().getEmailDetailsEnquire().getUse());
        assertEquals("00:00:00", customerBasicDataEnquire.getContactDetailsEnquire().getEmailDetailsEnquire().getAvailibilityEmail().getFromTimeEmail());
        assertEquals("23:59:00", customerBasicDataEnquire.getContactDetailsEnquire().getEmailDetailsEnquire().getAvailibilityEmail().getToTimeEmail());

        assertEquals("NO MARKET RESEARCH", customerBasicDataEnquire.getRobisonList().get(0).getInclusionCause());
        assertEquals("NO TELEPHONE", customerBasicDataEnquire.getRobisonList().get(1).getInclusionCause());

    }

    @Test()
    void testWeReturnException() {
        Mockito.when(restTemplate.exchange(anyString(), any(), any(), eq(CustomerInformationResponse.class))).thenThrow(RestClientException.class);
        assertThrows(ConnectionException.class, () -> customerInformationClient.getCustomerInformation("serviceUrl", "F123456789"));

    }

    private ResponseEntity<CustomerInformationResponse> generateCustomerInformationResponse() throws IOException {
        CustomerInformationResponse customerInformationResponse = TestDataCreator.generateDefaultCustomerCustomerInformationResponseBoth();
        return new ResponseEntity<>(customerInformationResponse, HttpStatus.OK);
    }
}
