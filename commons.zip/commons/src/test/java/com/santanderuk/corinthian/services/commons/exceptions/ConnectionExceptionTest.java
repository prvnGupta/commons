package com.santanderuk.corinthian.services.commons.exceptions;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class ConnectionExceptionTest {

    @Test
    public void test_extendsGeneralException() {
        // Check that the exception extends GeneralException
        assertTrue(GeneralException.class.isAssignableFrom(ConnectionException.class));
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage() {

        ConnectionException exc = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE);

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_canBeCougthByGeneralExceptionAndStillHaveTheSameCodeAndMessage_contructorWithException() {

        ConnectionException exc = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE, new Exception());

        // Check General Exception has the same values
        try {
            throw exc;
        } catch (GeneralException generalException) {
            assertEquals(exc.getCode(), generalException.getCode());
            assertEquals(exc.getMessage(), generalException.getMessage());
        }
    }

    @Test
    public void test_ANMF_UNAVAILABLE() {

        String expectedCode = "ANMF_UNAVAILABLE";
        String expectedMessage = "ANMF did not respond correctly";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.ANMF_UNAVAILABLE, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_BKS_CONNECT() {

        String expectedCode = "BKS_CONNECT";
        String expectedMessage = "An error occurred while calling core bks connect";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";

        ConnectionException exc = new ConnectionException(ConnectionException.Type.BKS_CONNECT);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.BKS_CONNECT, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_ANMF_RESPONSE_BAD_FORMAT() {

        String expectedCode = "ANMF_RESPONSE_BAD_FORMAT";
        String expectedMessage = "Failed to convert response to required object";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.ANMF_RESPONSE_BAD_FORMAT);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.ANMF_RESPONSE_BAD_FORMAT, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_EXC_BUS_IOC() {

        String expectedCode = "EXC_BUS_IOC";
        String expectedMessage = "Failed to convert response to required object";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.EXC_BUS_IOC);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.EXC_BUS_IOC, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_HEARTBEAT_CONNECTION_ERROR() {

        String expectedCode = "HEARTBEAT_CONNECTION_ERROR";
        String expectedMessage = "An error occurred when trying to connect with heartbeat";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.HEARTBEAT_CONNECTION_ERROR);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.HEARTBEAT_CONNECTION_ERROR, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR() {

        String expectedCode = "PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR";
        String expectedMessage = "Exception while calling Catalog Product Catalog Completion Date Core Service";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());

        ConnectionException withException = new ConnectionException(ConnectionException.Type.PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR, new Exception());

        assertEquals(expected, withException.toString());
        assertEquals(expectedCode, withException.getCode());
        assertEquals(expectedMessage, withException.getMessage());
    }

    @Test
    public void test_CREATE_CASE_CONNECTION_ERROR() {

        String expectedCode = "CREATE_RETENTIONS_CASE_ERROR";
        String expectedMessage = "Exception while calling retentions case creation";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.CREATE_RETENTIONS_CASE_CONNECTION);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());
    }

    @Test
    public void test_CREATE_EXC_IOCCORE_CALL_ERROR() {

        String expectedCode = "EXC_IOCCORE_CALL";
        String expectedMessage = "An error occurred while calling ContractsInMcc service";
        String expected = "{\"code\":\"" + expectedCode + "\",\"message\":\"" + expectedMessage + "\"}";


        ConnectionException exc = new ConnectionException(ConnectionException.Type.EXC_IOC_CORE_CALL);

        assertEquals(expected, exc.toString());
        assertEquals(expectedCode, exc.getCode());
        assertEquals(expectedMessage, exc.getMessage());
    }

}
