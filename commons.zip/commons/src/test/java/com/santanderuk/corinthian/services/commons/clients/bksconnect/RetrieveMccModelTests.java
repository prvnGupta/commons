package com.santanderuk.corinthian.services.commons.clients.bksconnect;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;


public class RetrieveMccModelTests extends BksConnetCommonsBaseTest {

    @Test()
    public void retrieveMccControllerRequestToStringTest() {
        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();
        assertTrue(retrieveMccControllerRequest.toString().equalsIgnoreCase("{\"dataRequest\":{\"profile\":{\"company\":\"0015\",\"channel\":\"OFI\"},\"operation\":\"L\",\"inputChannel\":\"INT\",\"option\":\"2\",\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":null},\"productTypeCode\":null,\"contractNumber\":null},\"ldapUid\":\"78p0KPs6\"}}"));
    }

    @Test()
    public void retrieveMccControllerResponseToStringTest() {
        RetrieveMccResponse retrieveMccResponse = generateDefaultResponseRetrieveMcc();
        assertTrue(retrieveMccResponse.getDataResponse().toString().equalsIgnoreCase("{\"kcError\":{\"codError\":\"CodError\",\"descError\":\"DescError\",\"next\":\"next\",\"nextTRX\":\"nextTrx\"},\"endList\":\"S\",\"mccContract\":{\"localContract\":null,\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"iban\":null},\"ldapUid\":\"78p0KPs6\",\"currency\":\"GBP\",\"status\":\"ACT\",\"modCapta\":\"11\"}"));
    }


}
