package com.santanderuk.corinthian.services.commons.clients.productcatalog;

import com.santanderuk.corinthian.services.commons.clients.productcatalog.io.ProductData;
import com.santanderuk.corinthian.services.commons.clients.productcatalog.io.ProductsResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.util.AssertionErrors.assertTrue;

@ExtendWith(MockitoExtension.class)
public class ProductCatalogClientTest {

    @Mock
    RestTemplate mockRestTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @InjectMocks
    ProductCatalogClient productCatalogClient;

    @BeforeEach
    public void setUp() {
        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        Mockito.when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
        ReflectionTestUtils.setField(productCatalogClient, "productDataUrl", "productDataUrl");
    }


    @Test
    public void testProductsDataOk() throws ConnectionException {

        mockProductCatalogProductDataIsOK();

        ProductsResponse response = productCatalogClient.fetchProductData("BandId");

        assertEquals("Description product 0", response.getData().get(0).getProductDescription());
        assertEquals("Description product 1", response.getData().get(1).getProductDescription());

    }

    @Test
    public void testProductDataNoConnection() {

        mockProductCatalogProductDataNoConnection();

        boolean exceptionWasThrown = false;
        try {
            productCatalogClient.fetchProductData("BandId");
        } catch (ConnectionException e) {
            exceptionWasThrown = true;
            assertEquals("PRODUCT_DATA_CORE_ERROR", e.getCode());
            assertEquals("Exception while calling Catalog Product Data Core Service", e.getMessage());
        }
        // To be sure the exception has been thrown and we are not just doing try without issues
        assertTrue("No exception was thrown", exceptionWasThrown);

    }


    private void mockProductCatalogProductDataIsOK() {
        ProductsResponse response = createProductDataResponse();
        ResponseEntity<ProductsResponse> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private ProductsResponse createProductDataResponse() {
        ProductsResponse response = new ProductsResponse();
        List<ProductData> list = new ArrayList<>();
        ProductData product0 = new ProductData();
        product0.setProductDescription("Description product 0");
        ProductData product1 = new ProductData();
        product1.setProductDescription("Description product 1");
        list.add(product0);
        list.add(product1);
        response.setData(list);
        return response;
    }


    private void mockProductCatalogProductDataNoConnection() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
    }


}
