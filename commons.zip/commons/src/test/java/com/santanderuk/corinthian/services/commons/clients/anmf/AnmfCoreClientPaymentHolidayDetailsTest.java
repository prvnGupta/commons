package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.AnmfPaymentHolidayResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.OPhList;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.OutputStruc;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientPaymentHolidayDetailsTest extends AnmfCoreClientTest {

    public static final String ANMF_PAYMENT_HOLIDAY_DETAILS_URL = "https://intra-core-api-dev.santanderuk.pre.corp/sanuk/internal/mortgage-payment-arrangements/v4/{region}/account/{account}/paymentholidayarrangements";

    @Override
    @BeforeEach
    public void setUp() {
        super.setUp();
    }

    @Test
    public void testCanFetchFromANMF() throws IOException, ConnectionException {

        mockAnmfWhenEverythingIsOk();

        AnmfPaymentHolidayResponse response = anmfCoreClient.fetchPaymentHolidayDetails(123456789, ANMF_PAYMENT_HOLIDAY_DETAILS_URL, AnmfRegion.A);

        OutputStruc outputStruc = response.getPaymentHolidayResponse().getOutputStruc();
        assertEquals(3, outputStruc.getOPhTermMaxMths());
        assertEquals(1, outputStruc.getOPhTermTotGtdMths());
        assertEquals(2, outputStruc.getOPhTermExtElgMths());
        assertEquals("15/04/2020", outputStruc.getOPhSimStrtDtSet());
        assertEquals("15/06/2020", outputStruc.getOPhSimNxpyDtCan());
        assertEquals(2, outputStruc.getOPhList().size());

        OPhList firstElement = outputStruc.getOPhList().get(0);
        OPhList secondElement = outputStruc.getOPhList().get(1);
        EStruc eStruc = outputStruc.getEStruc();

        assertEquals(1, firstElement.getOPhSeq());
        assertEquals("C", firstElement.getOPhStatus());
        assertEquals("CANCELLED", firstElement.getOPhStatusDesc());
        assertEquals("statusDate", firstElement.getOPhStatusDate());
        assertEquals("event", firstElement.getOPhEvent());
        assertEquals("eventDesc", firstElement.getOPhEventDesc());
        assertEquals("eventDate", firstElement.getOPhEventDate());
        assertEquals("28/03/2020", firstElement.getOPhReqDate());
        assertEquals("08/04/2020", firstElement.getOPhAppDate());
        assertEquals("05/05/2020", firstElement.getOPhEffDate());
        assertEquals("05/08/2020", firstElement.getOPhEndDate());
        assertEquals(3, firstElement.getOPhTermReqMths());
        assertEquals(0, firstElement.getOPhTermAdjMths());
        assertEquals(2, firstElement.getOPhTermRemMths());
        assertEquals(0, firstElement.getOPhTermUsedMths());
        assertEquals("S", firstElement.getOPhSourceCode());
        assertEquals("source", firstElement.getOPhSource());
        assertEquals("mobile", firstElement.getOPhMobile());
        assertEquals("email", firstElement.getOPhEmail());
        assertEquals("o_ph_nx_paydt_nend", firstElement.getOPhNxPaydtNend());


        assertEquals(2, secondElement.getOPhSeq());
        assertEquals("A", secondElement.getOPhStatus());
        assertEquals("ACTIVE", secondElement.getOPhStatusDesc());

        assertEquals("e_code", eStruc.getECode());
        assertEquals("e_message", eStruc.getEMessage());
        assertEquals("e_progname", eStruc.getEProgname());
    }

    @Test
    public void testAnmfCoreDoesNotConnect() {

        mockAnmfWhenDoesNotConnect();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchPaymentHolidayDetails(123456789, ANMF_PAYMENT_HOLIDAY_DETAILS_URL, AnmfRegion.A));

        assertEquals("ANMF_UNAVAILABLE", e.getCode());
        assertEquals("ANMF did not respond correctly", e.getMessage());
    }

    @Test
    public void testDoesRespondWithBadFormat() throws IOException {

        mockAnmfWhenRespondWithBadFormat();

        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfCoreClient.fetchPaymentHolidayDetails(123456789, ANMF_PAYMENT_HOLIDAY_DETAILS_URL, AnmfRegion.A));

        assertEquals("ANMF_RESPONSE_BAD_FORMAT", e.getCode());
        assertEquals("Failed to convert response to required object", e.getMessage());
    }


    private void mockAnmfWhenEverythingIsOk() throws IOException {
        AnmfPaymentHolidayResponse response = generateDefaultPaymentHolidayDetailsServiceResponse();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("", HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
        when(mockObjectMapper.readValue(anyString(), any(Class.class))).thenReturn(response);
    }

    private AnmfPaymentHolidayResponse generateDefaultPaymentHolidayDetailsServiceResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-response.json", AnmfPaymentHolidayResponse.class);
    }
}
