package com.santanderuk.corinthian.services.commons.definitions;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class AccountStatusEnumTest {

    @Test
    public void testNumberOfValuesIsCorrect() {
        assertEquals(8, AccountStatusEnum.values().length);
    }

    @Test
    public void testListOfValuesIsCorrect() {
        assertEquals(AccountStatusEnum.ACTIVE, AccountStatusEnum.valueOf("ACTIVE"));
        assertEquals(AccountStatusEnum.REDEEMED, AccountStatusEnum.valueOf("REDEEMED"));
        assertEquals(AccountStatusEnum.SOLD, AccountStatusEnum.valueOf("SOLD"));
        assertEquals(AccountStatusEnum.LITIGATION, AccountStatusEnum.valueOf("LITIGATION"));
        assertEquals(AccountStatusEnum.MERGED, AccountStatusEnum.valueOf("MERGED"));
        assertEquals(AccountStatusEnum.PENDING, AccountStatusEnum.valueOf("PENDING"));
        assertEquals(AccountStatusEnum.CLOSED, AccountStatusEnum.valueOf("CLOSED"));
    }

}
