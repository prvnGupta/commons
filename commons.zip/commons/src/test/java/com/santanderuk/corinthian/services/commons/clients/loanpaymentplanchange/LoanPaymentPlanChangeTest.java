package com.santanderuk.corinthian.services.commons.clients.loanpaymentplanchange;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.EStruc;
import com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.LoanPaymentPlanChangeClient;
import com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io.*;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
public class LoanPaymentPlanChangeTest {

    @InjectMocks
    private LoanPaymentPlanChangeClient loanPaymentPlanChangeClient;
    @Mock
    RestTemplate mockRestTemplate;

    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    public void setUp() {
        Mockito.when(apiManagerConfig.getClientIdValue()).thenReturn("client-id");
        Mockito.when(apiManagerConfig.getClientSecretValue()).thenReturn("client-secret");
    }

    @Test
    public void testLoanPaymentPlanChangeDataOk() throws ConnectionException {

        ResponseEntity<LoanPaymentPlanChangeResponse> responseEntity = new ResponseEntity<>(createLoanPaymentPlanChangeResponseOK(), HttpStatus.OK);
        Mockito.when(mockRestTemplate.postForEntity(anyString(), any(), any(Class.class))).thenReturn(responseEntity);

        LoanPaymentPlanChangeRequest loanPaymentPlanChangeRequest = getDirectDebitServiceRequest();
        LoanPaymentPlanChangeResponse response = loanPaymentPlanChangeClient.fetchLoanPaymentPlan("loanPlanUrl", loanPaymentPlanChangeRequest);

        assertEquals("SLSRUM",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getOPendingAudTab().getOPendingAud().get(0).getOUserId());
        assertEquals("SANTANDER",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getOPendingAudTab().getOPendingAud().get(0).getOBankpName());
        assertEquals("09-01-26",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getOPendingAudTab().getOPendingAud().get(0).getONewSortcode());
    }

    @Test
    public void testLoanPaymentPlanChangeDataWhenAlreadyExists() throws ConnectionException {

        ResponseEntity<LoanPaymentPlanChangeResponse> responseEntity = new ResponseEntity<>(createLoanPaymentPlanChangeResponseAlreadyExists(), HttpStatus.OK);
        Mockito.when(mockRestTemplate.postForEntity(anyString(), any(), any(Class.class))).thenReturn(responseEntity);

        LoanPaymentPlanChangeRequest loanPaymentPlanChangeRequest = getDirectDebitServiceRequest();
        LoanPaymentPlanChangeResponse response = loanPaymentPlanChangeClient.fetchLoanPaymentPlan("loanPlanUrl", loanPaymentPlanChangeRequest);

        assertEquals("ERR2010",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getEStruc().getECode());
        assertEquals("AUDDIS \"21.12.2023 33265740\" already exists",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getEStruc().getEMessage());
        assertEquals("MBSSUS3C",
                response
                        .getDirectDebitServiceResponseUpd()
                        .getOutputStruc().getEStruc().getEProgname());
    }

    @Test
    public void testLoanPaymentPlanChangeDataWhenThrowsException() {


        Mockito.when(mockRestTemplate.postForEntity(anyString(), any(), any(Class.class))).thenThrow(new RestClientException(""));

        LoanPaymentPlanChangeRequest loanPaymentPlanChangeRequest = getDirectDebitServiceRequest();
        assertAll(() -> {
            ConnectionException exc = assertThrows(ConnectionException.class, () -> loanPaymentPlanChangeClient.fetchLoanPaymentPlan("loanPlanUrl", loanPaymentPlanChangeRequest));
            assertThat(exc.getCode(), equalTo("LOAN_PAYMENT_PLAN_CHANGE_SERVICE_CONNECTION_ERROR"));
            assertThat(exc.getMessage(), equalTo("Exception while calling loan payment plan change API"));
        });
    }

    private LoanPaymentPlanChangeResponse createLoanPaymentPlanChangeResponseOK() {
        LoanPaymentPlanChangeResponse loanPaymentPlanChangeResponse = new LoanPaymentPlanChangeResponse();
        DirectDebitServiceResponseUpd directDebitServiceResponseUpd = new DirectDebitServiceResponseUpd();
        OutputStruc outputStruc = new OutputStruc();
        OPendingAudTab oPendingAudTab = new OPendingAudTab();
        List<OPendingAud> oPendingAudList = new ArrayList<>();
        oPendingAudTab.setOPendingAud(oPendingAudList);
        outputStruc.setEStruc(new EStruc());
        outputStruc.setOPendingAudTab(oPendingAudTab);
        OPendingAud oPendingAud = new OPendingAud();
        oPendingAud.setOAuddisDate("20/03/2021");
        oPendingAud.setOUserId("SLSRUM");
        oPendingAud.setOInstructionBy("F");
        oPendingAud.setOInstructionByDesc("FACE TO FACE");
        oPendingAud.setOBankpName("SANTANDER");
        oPendingAud.setONewSortcode("09-01-26");
        oPendingAud.setONewAccNumber("00000049073619");
        oPendingAud.setONewAccName("RUBEN PRUEBA ULT");
        oPendingAud.setOBankpAddress("SANTANDER SAPIEN6 - SR43 4ET");
        oPendingAud.setOBankpAddress2("SANTANDER DOMESTIC PAYMENTS");
        oPendingAud.setOBankpAddress3("SUNDERLAND");
        oPendingAud.setOBankpAddress4("");
        oPendingAud.setOBankpPostcode("SR43 4ET");
        oPendingAud.setONewDdrStatus("A");
        oPendingAud.setONewDdrStatusDesc("ACTIVE");
        oPendingAud.setONewAction("");
        oPendingAud.setONewActionDesc("ACTIVE");
        oPendingAud.setONewMandate("C");
        oPendingAud.setOReasonChange("CB");
        oPendingAud.setOReasonChangeDesc("CHANGE BANKS");
        oPendingAudList.add(oPendingAud);
        directDebitServiceResponseUpd.setOutputStruc(outputStruc);
        loanPaymentPlanChangeResponse.setDirectDebitServiceResponseUpd(directDebitServiceResponseUpd);
        return loanPaymentPlanChangeResponse;
    }
    private LoanPaymentPlanChangeResponse createLoanPaymentPlanChangeResponseAlreadyExists() {
        LoanPaymentPlanChangeResponse loanPaymentPlanChangeResponse = new LoanPaymentPlanChangeResponse();
        DirectDebitServiceResponseUpd directDebitServiceResponseUpd = new DirectDebitServiceResponseUpd();
        OutputStruc outputStruc = new OutputStruc();
        OPendingAudTab oPendingAudTab = new OPendingAudTab();
        List<OPendingAud> oPendingAudList = new ArrayList<>();
        oPendingAudTab.setOPendingAud(oPendingAudList);
        EStruc eStruc = new EStruc();
        eStruc.setECode("ERR2010");
        eStruc.setEMessage("AUDDIS \"21.12.2023 33265740\" already exists");
        eStruc.setEProgname("MBSSUS3C");
        outputStruc.setEStruc(eStruc);
        outputStruc.setOPendingAudTab(oPendingAudTab);

        directDebitServiceResponseUpd.setOutputStruc(outputStruc);
        loanPaymentPlanChangeResponse.setDirectDebitServiceResponseUpd(directDebitServiceResponseUpd);
        return loanPaymentPlanChangeResponse;
    }

    public LoanPaymentPlanChangeRequest getDirectDebitServiceRequest() {
        LoanPaymentPlanChangeRequest loanPaymentPlanChangeRequest = new LoanPaymentPlanChangeRequest();
        DirectDebitServiceRequest directDebitServiceRequest = new DirectDebitServiceRequest();
        Request request = new Request();
        IStruc iStruc = new IStruc();
        iStruc.setIMortAccNo("33265740");
        iStruc.setIAction("I");
        iStruc.setIAuddisDate("22-12-2023");
        iStruc.setIBankSortcode("090126");
        iStruc.setIBankAccNo("49073619");
        iStruc.setIBankAccName("BEN INT ULT");
        iStruc.setIDdrStatus("A");
        iStruc.setIReasonChange("CB");
        iStruc.setIInstructionReceived("F");
        iStruc.setIUserId("SLSRUM");
        request.setIStruc(iStruc);
        directDebitServiceRequest.setRequest(request);
        loanPaymentPlanChangeRequest.setDirectDebitServiceRequest(directDebitServiceRequest);
        return loanPaymentPlanChangeRequest;
    }

}
