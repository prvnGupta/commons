package com.santanderuk.corinthian.services.commons.clients.bksconnect;


import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.*;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

/**
 * Created by C0229411 on 15/12/2017.
 */
@ExtendWith(SpringExtension.class)
public abstract class BksConnetCommonsBaseTest {

    public static Profile genericProfile() {
        Profile profile = new Profile();
        profile.setChannel("OFI");
        profile.setCompany("0015");
        return profile;
    }

    public static PartenonContract genericPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany("0015");
        centre.setCentreCode("0075");
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode("300");
        partenonContract.setContractNumber("1234567");
        return partenonContract;
    }

    public static PartenonContract customePartenonContract(String company, String centreStr, String product, String number) {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany(company);
        centre.setCentreCode(centreStr);
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode(product);
        partenonContract.setContractNumber(number);
        return partenonContract;
    }

    public static ServiceInfo genericServiceInfo() {
        return new ServiceInfo("Status", "Code", "Message");
    }

    public static ServiceInfo generateDefaultServiceInfo() {
        return new ServiceInfo("Status", "Code", "Message");
    }

    public static ServiceInfo generateCustomServiceInfo(String status, String code, String message) {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus(status);
        serviceInfo.setCode(code);
        serviceInfo.setMessage(message);
        return serviceInfo;
    }

    public RetrieveMccControllerRequest generateDefaultRequestRetrieveMcc() {
        RetrieveMccControllerRequest retrieveMccControllerRequest = new RetrieveMccControllerRequest();
        RetrieveMccDataRequest dataRequest = new RetrieveMccDataRequest();
        dataRequest.setProfile(genericProfile());
        dataRequest.setLdapUid("78p0KPs6");
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany("0015");
        partenonContract.setCentre(centre);
        dataRequest.setPartenonContract(partenonContract);
        dataRequest.setOption("2");
        dataRequest.setInputChannel("INT");
        dataRequest.setOperation("L");
        retrieveMccControllerRequest.setDataRequest(dataRequest);
        return retrieveMccControllerRequest;
    }


    public RetrieveMccResponse generateDefaultResponseRetrieveMcc() {
        RetrieveMccResponse retrieveMccResponse = new RetrieveMccResponse();
        ServiceInfo serviceInfo;
        serviceInfo = generateDefaultServiceInfo();
        retrieveMccResponse.setInfo(serviceInfo);
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");

        retrieveMccResponse.setDataResponse(dataResponse);
        return retrieveMccResponse;
    }

    private PartenonContract generateDefaultPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setCentre(generateDefaultCentre());
        partenonContract.setProductTypeCode("520");
        partenonContract.setContractNumber("7589273");
        return partenonContract;
    }

    private Centre generateDefaultCentre() {
        Centre centre = new Centre();
        centre.setCompany("0015");
        centre.setCentreCode("7740");
        return centre;
    }


    private BdpCustomer generateDefaultBdpCustomer() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setCustomerType("F");
        bdpCustomer.setCustomerNumber(12345678);
        return bdpCustomer;
    }


    private KcError generateDefaultKcError() {
        KcError kcError = new KcError();
        kcError.setCodError("CodError");
        kcError.setDescError("DescError");
        kcError.setNext("next");
        kcError.setNextTRX("nextTrx");
        return kcError;
    }


    public RetrieveMccResponse generate500ResponseRetrieveMcc() {
        RetrieveMccResponse retrieveMccResponse = new RetrieveMccResponse();
        retrieveMccResponse.setInfo(generateCustomServiceInfo("ko", "500", "Internal Server Error"));
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");


        retrieveMccResponse.setDataResponse(dataResponse);
        return retrieveMccResponse;
    }


    public RetrieveMccResponse generateOkResponseRetrieveMcc() {
        RetrieveMccResponse retrieveMccResponse = new RetrieveMccResponse();
        retrieveMccResponse.setInfo(generateCustomServiceInfo("ok", "", "Data found"));
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");


        retrieveMccResponse.setDataResponse(dataResponse);
        return retrieveMccResponse;
    }


}
