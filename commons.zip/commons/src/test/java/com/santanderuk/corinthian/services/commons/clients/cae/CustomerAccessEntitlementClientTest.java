package com.santanderuk.corinthian.services.commons.clients.cae;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.clients.cae.io.EntitledAccountsResponse;
import com.santanderuk.corinthian.services.commons.clients.cae.io.QueryParams;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CustomerAccessEntitlementClientTest {

    private CustomerAccessEntitlementClient service;
    private String url;

    @Mock
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        service = new CustomerAccessEntitlementClient(mockRestTemplate);
        url = "https://intra-core-api-pre.santanderuk.pre.corp/sanuk/internal/customer-access-entitlement/v5/entitled-accounts";
    }

    @Test
    void shouldReturnAccountsFoundResponse() throws GeneralException, IOException {

        mockCustomerAccessEntitlementResponseOkay("customeraccessentitlement/accounts-found.json");

        EntitledAccountsResponse response = service.entitledAccounts(url, createQueryParams());

        assertEquals("001510363000004838", response.getAccounts().get(0).getPartenonContract());
        assertEquals("ZERO CURRENT ACCOUNT", response.getAccounts().get(0).getAlias());
        assertEquals("b9e39a55-98cb-4a5a-85ce-0079b5885bff", response.getAccounts().get(0).getId());
        assertEquals("50357476", response.getAccounts().get(0).getLocalNumber());
        assertEquals("090126", response.getAccounts().get(0).getSortCode());
        assertEquals("GBP", response.getAccounts().get(0).getCurrency());

        assertEquals("001510363000005188", response.getAccounts().get(1).getPartenonContract());
        assertEquals("EVERYDAY CURRENT ACCOUNT", response.getAccounts().get(1).getAlias());
        assertEquals("1cc2cb5e-6c64-4ab1-9294-d269cfe198e2", response.getAccounts().get(1).getId());
        assertEquals("55177871", response.getAccounts().get(1).getLocalNumber());
        assertEquals("090126", response.getAccounts().get(1).getSortCode());
        assertEquals("GBP", response.getAccounts().get(1).getCurrency());
    }

    @Test
    void shouldReturnNoAccountsFoundResponse() throws GeneralException, IOException {

        mockCustomerAccessEntitlementResponseOkay("customeraccessentitlement/accounts-not-found.json");

        EntitledAccountsResponse response = service.entitledAccounts(url, createQueryParams());
        assertTrue(response.getAccounts().isEmpty());
    }

    @Test
    public void shouldHandleNoConnectionException() {
        mockCustomerAccessEntitlementConnectionException();
        GeneralException e = assertThrows(GeneralException.class, () -> service.entitledAccounts(url, createQueryParams()));
        assertEquals("CUSTOMER_ACCESS_ENTITLEMENT_EXC: 301", e.getCode());
        assertEquals("Customer-access-entitlement/entitledAccounts service did not respond correctly", e.getMessage());
    }

    @Test
    public void shouldHandleWhenBadRequestIsReturned() {
        mockCustomerAccessEntitlementBadRequestException();
        GeneralException e = assertThrows(GeneralException.class, () -> service.entitledAccounts(url, createQueryParams()));
        assertEquals("CUSTOMER_ACCESS_ENTITLEMENT_EXC: 400", e.getCode());
        assertEquals("Customer-access-entitlement/entitledAccounts service did not respond correctly", e.getMessage());
    }

    private void mockCustomerAccessEntitlementResponseOkay(String filePath) throws IOException {
        EntitledAccountsResponse responseBody = FixtureReader.get(filePath, EntitledAccountsResponse.class);
        ResponseEntity<EntitledAccountsResponse> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(responseEntity);
    }

    private void mockCustomerAccessEntitlementConnectionException() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(HttpServerErrorException.create(HttpStatus.MOVED_PERMANENTLY, "Service return 500 internal error", new HttpHeaders(), null, null));

    }

    private void mockCustomerAccessEntitlementBadRequestException() {
        when(mockRestTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(HttpClientErrorException.create(HttpStatus.BAD_REQUEST, "API_REQUEST_VALIDATION_EXCEPTION", new HttpHeaders(), null, null));
    }

    private QueryParams createQueryParams() {
        QueryParams queryParams = new QueryParams();
        queryParams.setUid("OlSia4kI");
        queryParams.setOperation("santander.sanuk.retail.olb.payments.directdebits");
        return queryParams;
    }
}
