package com.santanderuk.corinthian.services.commons.clients.anmf;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.FixtureReader;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsInput;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfCoreClientRedemptionsComplexTest {

    public static final String ANMF_REDEMPTIONS_URL = "http://localhost";

    AnmfCoreClient anmfCoreClient;

    @Mock
    RestTemplate restTemplate;

    @Spy
    ObjectMapper objectMapper;

    @Mock
    ApiManagerConfig apiManagerConfig;


    @BeforeEach
    public void setUp() {
        anmfCoreClient = new AnmfCoreClient(objectMapper, restTemplate, apiManagerConfig);
    }


    @Test
    public void testMultipleComplexReasonsBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateRedemptionsIllustrationMultipleComplexReasonsResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(7, anmfRedemptionsResponse.getErrors().size());

        assertEquals("ERR21502", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("ACCOUNT HAS RECENTLY COMPLETED/First payment has not been made on the account", anmfRedemptionsResponse.getErrors().get(0).getEMessage());

        assertEquals("ERR21504", anmfRedemptionsResponse.getErrors().get(1).getECode());
        assertEquals("ACCOUNT IN LITIGATION OR PROPERTY IN POSSESSION", anmfRedemptionsResponse.getErrors().get(1).getEMessage());

        assertEquals("ERR21507", anmfRedemptionsResponse.getErrors().get(2).getECode());
        assertEquals("ACCOUNT IS PENDING A FURTHER ADVANCE", anmfRedemptionsResponse.getErrors().get(2).getEMessage());

        assertEquals("ERR21508", anmfRedemptionsResponse.getErrors().get(3).getECode());
        assertEquals("DECEASED FLAG ON THE ACCOUNT", anmfRedemptionsResponse.getErrors().get(3).getEMessage());

        assertEquals("ERR21511", anmfRedemptionsResponse.getErrors().get(4).getECode());
        assertEquals("ACCOUNT IS BANKRUPT", anmfRedemptionsResponse.getErrors().get(4).getEMessage());

        assertEquals("ERR21512", anmfRedemptionsResponse.getErrors().get(5).getECode());
        assertEquals("SECURED PERSONAL LOAN(S)/RESTRAINT ORDER PRESENT ON ACCOUNT", anmfRedemptionsResponse.getErrors().get(5).getEMessage());

        assertEquals("ERR21513", anmfRedemptionsResponse.getErrors().get(6).getECode());
        assertEquals("RIGHTS OF CONSOLIDATION HELD ON ACCOUNT", anmfRedemptionsResponse.getErrors().get(6).getEMessage());
    }


    @Test
    public void testBereavementBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateRedemptionsIllustrationBereavementResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21508", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("DECEASED FLAG ON THE ACCOUNT", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testBankruptcyBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateBankruptcyResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21511", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("ACCOUNT IS BANKRUPT", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testFurtherAdvancePendingBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateFurtherAdvancePendingResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21507", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("ACCOUNT IS PENDING A FURTHER ADVANCE", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testFirstDDBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateRedemptionsIllustrationFirstDDResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21502", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("ACCOUNT HAS RECENTLY COMPLETED/First payment has not been made on the account", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testLitigationBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateLitigationResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21504", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("ACCOUNT IN LITIGATION OR PROPERTY IN POSSESSION", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testSPLBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateRedemptionsIllustrationSPLResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21512", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("SECURED PERSONAL LOAN(S)/RESTRAINT ORDER PRESENT ON ACCOUNT", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    @Test
    public void testROCBadFormat() throws IOException, ConnectionException {

        mockAnmfWhenPostRespondWithBadFormat(generateRightOfConsolidationResponse());

        RedemptionsInput request = createRedemptionsInput();
        request.setRequest(generateRedemptionsRequest());
        request.setUrl(ANMF_REDEMPTIONS_URL);

        ANMFRedemptionsResponse anmfRedemptionsResponse = anmfCoreClient.fetchRedemption(request);

        assertEquals(1, anmfRedemptionsResponse.getErrors().size());
        assertEquals("ERR21513", anmfRedemptionsResponse.getErrors().get(0).getECode());
        assertEquals("RIGHTS OF CONSOLIDATION HELD ON ACCOUNT", anmfRedemptionsResponse.getErrors().get(0).getEMessage());
    }

    private void mockAnmfWhenPostRespondWithBadFormat(String body) {
        HttpServerErrorException httpServerErrorException = new HttpServerErrorException(HttpStatus.BAD_REQUEST, "SOMETHING_HAPPENED", body.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);

        when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenThrow(httpServerErrorException);
    }


    private String generateRedemptionsIllustrationBereavementResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/bereavement-error.json");
    }

    private String generateRedemptionsIllustrationMultipleComplexReasonsResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/bereavement-litigation-firstDD-Bankruptcy-SPL-ROI-error.json");
    }

    private String generateRedemptionsIllustrationFirstDDResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/firstDD-error.json");
    }

    private String generateRedemptionsIllustrationSPLResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/secure-personal-loan-error.json");
    }

    private String generateRightOfConsolidationResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/right-of-consolidation-error.json");
    }

    private String generateLitigationResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/litigation-error.json");
    }

    private String generateBankruptcyResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/bankruptcy-error.json");
    }

    private String generateFurtherAdvancePendingResponse() throws IOException {
        return FixtureReader.readFileContents("redemption-illustration/further-advance-pending-error.json");
    }

    private RedemptionsInput createRedemptionsInput() {
        RedemptionsInput redemptionsInput = new RedemptionsInput();
        return redemptionsInput;
    }

    private ANMFRedemptionsRequest generateRedemptionsRequest() {

        ANMFRedemptionsRequest anmfRedemptionsRequest = new ANMFRedemptionsRequest();
        anmfRedemptionsRequest.setAccountNumber("12345");
        anmfRedemptionsRequest.setCallingApplication("Application");
        anmfRedemptionsRequest.setChannelType("int");
        anmfRedemptionsRequest.setRedemptionDate("state");
        anmfRedemptionsRequest.setRequestedBy("requester");
        anmfRedemptionsRequest.setSolicitorCode("solCode");
        anmfRedemptionsRequest.setRedemptionDate("date");
        anmfRedemptionsRequest.setStatementEnq("statement");
        anmfRedemptionsRequest.setUserId("userId");

        return anmfRedemptionsRequest;
    }

}
