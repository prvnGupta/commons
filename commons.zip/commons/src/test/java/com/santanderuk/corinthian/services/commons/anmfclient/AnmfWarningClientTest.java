package com.santanderuk.corinthian.services.commons.anmfclient;

import com.santanderuk.corinthian.services.commons.TestDataCreator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.warning.AnmfWarnResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class AnmfWarningClientTest {

    AnmfWarningClient anmfWarningClient;
    @Mock
    RestTemplate restTemplate;
    @Mock
    ApiManagerConfig apiManagerConfig;

    @BeforeEach
    void setUp() {
        anmfWarningClient = new AnmfWarningClient(restTemplate, apiManagerConfig);
        when(apiManagerConfig.getClientIdValue()).thenReturn("clientId");
        when(apiManagerConfig.getClientSecretValue()).thenReturn("clientSecret");
    }

    @Test
    void testHappyPath() throws ConnectionException, IOException {

        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenReturn(generateAccountWarningResponse());
        AnmfWarnResponse anmfWarnResponse = anmfWarningClient.getWarningDetails(11143026, "sanuk/internal/mortgage-account-warnings/accounts/{account}", AnmfRegion.A);
        assertNotNull(anmfWarnResponse.getAccountWarnResponse().getOutputStruc());
        assertNotNull(anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab());
        assertNotNull(anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr());
        assertEquals(6, anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().size());
        assertEquals("0052", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(0).getOWrnCode());
        assertEquals("Pending Simulation", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(0).getOWrnIntMsg());
        assertEquals("Pending Simulation", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(0).getOWrnExtMsg());
        assertEquals("OTHER", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(5).getOWrnCode());
        assertEquals("other", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(5).getOWrnIntMsg());
        assertEquals("other", anmfWarnResponse.getAccountWarnResponse().getOutputStruc().getOWarningProcessArrTab().getOWrnMsgArr().get(5).getOWrnExtMsg());

    }

    @Test
    void testErrorScenario() {
        when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
        ConnectionException e = assertThrows(ConnectionException.class, () -> anmfWarningClient.getWarningDetails(11143026, "sanuk/internal/mortgage-account-warnings/accounts/{account}", AnmfRegion.A));
        assertEquals("ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR", e.getCode());
        assertEquals("Exception while calling account warning service", e.getMessage());
    }

    private ResponseEntity<AnmfWarnResponse> generateAccountWarningResponse() throws IOException {
        AnmfWarnResponse anmfWarnResponse = TestDataCreator.generateAccountWarningResponse();
        return new ResponseEntity<>(anmfWarnResponse, HttpStatus.OK);
    }
}
