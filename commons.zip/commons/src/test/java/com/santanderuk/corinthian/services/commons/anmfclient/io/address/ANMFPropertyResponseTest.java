package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.santanderuk.corinthian.services.commons.FixtureReader;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class ANMFPropertyResponseTest {

    @Test
    public void testLoadingCorrectlyFromTheJson() throws IOException {

        ANMFPropertyResponse anmfPropertyResponse = FixtureReader.get("anmf-property-v7.json", ANMFPropertyResponse.class);

        OutputStructure oStruc = anmfPropertyResponse.getPropertyEnquiryResponse().getOutputStructure();

        assertEquals("36 IMPERIAXXXXXXXXXX", oStruc.getOPropertyAddr1());
        assertEquals("XXXXXXXXXX", oStruc.getOPropertyAddr2());
        assertEquals("YYYYYYYYYY", oStruc.getOPropertyAddr3());
        assertEquals("USER TEST", oStruc.getOPropertyAddr4());
        assertEquals("BS14", oStruc.getOPropertyCounty());
        assertEquals("ENGLAND & WALES", oStruc.getOPropertyCountry());
        assertEquals("UNITED KINGDOM", oStruc.getOPropertyCountryComm());
        assertEquals("RH16 2GB", oStruc.getOPropertyPostcode());
        assertEquals("2GB", oStruc.getOPropertyPC());
        assertEquals("N", oStruc.getOConsentToLet());
        assertEquals(365000, oStruc.getOPurchasePrice());
        assertEquals(0, oStruc.getOPercentOwner());
        assertEquals("OCCUPANCY", oStruc.getOOccupancyCode());
        assertEquals("OCCUPANCY-LIT", oStruc.getOOccupancyCodeLit());
        assertEquals("S", oStruc.getOPropertyType());
        assertEquals("SEMI DETACHED", oStruc.getOPropertyTypeLit());
        assertEquals(3, oStruc.getOBedrooms());
        assertEquals("F", oStruc.getOTenure());
        assertEquals("FREEHOLD", oStruc.getOTenureLit());
        assertEquals("S", oStruc.getOGarage());
        assertEquals("SINGLE GARAGE", oStruc.getOGarageLit());
        assertEquals("USE", oStruc.getOPropertyUse());
        assertEquals(77007, oStruc.getODeedsLocation());
        assertEquals("DEMAT - NO DEEDS HELD 77007", oStruc.getODeedsLocationLit());
        assertEquals("Y", oStruc.getODematCase());
        assertEquals("1", oStruc.getOCountryCode());
        assertEquals("o_property_phone", oStruc.getOPropertyPhone());
        assertEquals(218000, oStruc.getOInsuranceValue());
        assertEquals("26/04/2016", oStruc.getOInsuranceDate());
        assertEquals("STD", oStruc.getOConstruction());
        assertEquals(2, oStruc.getOFloors());
        assertEquals("o_heating", oStruc.getOHeating());
        assertEquals(0, oStruc.getOWcS());
        assertEquals(1, oStruc.getOBathroom());
        assertEquals(115, oStruc.getOSquareFootage());
        assertEquals("1935", oStruc.getOYearBuilt());
        assertEquals(0, oStruc.getOLeaseYears());
        assertEquals(new BigDecimal("0.01"), oStruc.getOGrChRent());
        assertEquals("o_freq_rent", oStruc.getOFreqRent());
        assertEquals("o_freq_rent_lit", oStruc.getOFreqRentLit());
        assertEquals(new BigDecimal("0.01"), oStruc.getOServiceCharge());
        assertEquals("o_freq_charge", oStruc.getOFreqCharge());
        assertEquals("o_freq_charge_lit", oStruc.getOFreqChargeLit());
        assertEquals("o_agent_name", oStruc.getOAgentName());
        assertEquals("o_agent_addr1", oStruc.getOAgentAddr1());
        assertEquals("o_agent_addr2", oStruc.getOAgentAddr2());
        assertEquals("o_agent_addr3", oStruc.getOAgentAddr3());
        assertEquals("o_agent_addr4", oStruc.getOAgentAddr4());
        assertEquals("o_agent_county", oStruc.getOAgentCounty());
        assertEquals("o_agent_p_c", oStruc.getOAgentPC());
        assertEquals("o_agent_phone", oStruc.getOAgentPhone());
        assertEquals("o_tenency_agrmnt", oStruc.getOTenencyAgrmnt());
        assertEquals(0, oStruc.getORentTermYears());
        assertEquals(0, oStruc.getORentTermMonths());
        assertEquals(new BigDecimal("521.21"), oStruc.getORentAmount());
        assertEquals(0, oStruc.getOMonthRemain());
        assertEquals(0, oStruc.getOKitchens());
        assertEquals("Y", oStruc.getOWater());
        assertEquals("Y", oStruc.getOGas());
        assertEquals("Y", oStruc.getOElectricity());
        assertEquals("Y", oStruc.getODrainage());
        assertEquals("o_subsidence", oStruc.getOSubsidence());
        assertEquals("o_heave", oStruc.getOHeave());
        assertEquals("o_landslip", oStruc.getOLandslip());
        assertEquals("o_flooding", oStruc.getOFlooding());
        assertEquals("Y", oStruc.getOSuitSecurity());
        assertEquals("o_septic_tank", oStruc.getOSepticTank());
        assertEquals("o_nhbc_riba", oStruc.getONhbcRiba());
        assertEquals("o_riba", oStruc.getORiba());
        assertEquals("o_cesspit", oStruc.getOCesspit());
        assertEquals("o_land_registry_no", oStruc.getOLandRegistryNo());
        assertEquals("0", oStruc.getOStartOfLease());
        assertEquals("o_special_purchase", oStruc.getOSpecialPurchase());
        assertEquals("o_special_purchase_lit", oStruc.getOSpecialPurchaseLit());
        assertEquals("o_prop_let_since", oStruc.getOPropLetSince());
        assertEquals("o_last_agreemnt_dt", oStruc.getOLastAgreemntDt());
        assertEquals("o_curr_agreemt_exp", oStruc.getOCurrAgreemtExp());
        assertEquals("o_next_fee_due", oStruc.getONextFeeDue());
        assertEquals("o_tenancy_reason", oStruc.getOTenancyReason());
        assertEquals("Y", oStruc.getORegistered());
        assertEquals("YES", oStruc.getORegisteredLit());
        assertEquals("o_bt_phone", oStruc.getOBtPhone());
        assertEquals("125", oStruc.getOLeaseStYrs());
        assertEquals("0", oStruc.getOLeaseStMths());
        assertEquals("", oStruc.getOLeaseStDays());
        assertEquals("o_mortgage_detail", oStruc.getOMortgageDetail());
        assertEquals("o_mortgage_detail_lit", oStruc.getOMortgageDetailLit());
        assertEquals("1", oStruc.getOAssetClass());
        assertEquals("o_land_registry_02", oStruc.getOLandRegistry02());
        assertEquals("o_land_registry_03", oStruc.getOLandRegistry03());
        assertEquals("o_land_registry_04", oStruc.getOLandRegistry04());
        assertEquals("o_land_registry_05", oStruc.getOLandRegistry05());
        assertEquals("o_land_registry_06", oStruc.getOLandRegistry06());
        assertEquals("o_unique_ent_rf_no", oStruc.getOUniqueEntRfNo());
        assertEquals("o_charge_date_1", oStruc.getOChargeDate1());
        assertEquals("o_uniq_prop_ref_no", oStruc.getOUniqPropRefNo());
        assertEquals("2", oStruc.getOCapitalAdequacy());
        assertEquals("GROUP 2", oStruc.getOCapitalAdequacyLit());
        assertEquals(0, oStruc.getOBorrowerType());
        assertEquals(0, oStruc.getOIndustCategory());
        assertEquals(0, oStruc.getOIndSubCat());
        assertEquals(0, oStruc.getOLoanType());

        assertEquals("22/08/2003", oStruc.getOAnmfValuationGrp().getOValuationDate());
        assertEquals(new BigDecimal("76000"), oStruc.getOAnmfValuationGrp().getOValuation());
        assertEquals(new BigDecimal("76000"), oStruc.getOAnmfValuationGrp().getOBaseValuation());
        assertEquals("", oStruc.getOAnmfValuationGrp().getOValuerFirm());
        assertEquals("ABBEY NATIONAL CHELMSFORD", oStruc.getOAnmfValuationGrp().getOValuerName());
        assertEquals("FIRST FLOOR", oStruc.getOAnmfValuationGrp().getOValuerAddr1());
        assertEquals("4 HIGH STREET", oStruc.getOAnmfValuationGrp().getOValuerAddr2());
        assertEquals("CHELMSFORD", oStruc.getOAnmfValuationGrp().getOValuerAddr3());
        assertEquals("ESSEX", oStruc.getOAnmfValuationGrp().getOValuerAddr4());
        assertEquals("CM1 1EG", oStruc.getOAnmfValuationGrp().getOValuerPostcode());
        assertEquals("01245 494621", oStruc.getOAnmfValuationGrp().getOValuerPhone());
        assertEquals(272, oStruc.getOAnmfValuationGrp().getOValuerCode());

        assertEquals("24/10/2023", oStruc.getOHpiValuationGrp().getOLastValDate());
        assertEquals(new BigDecimal("156422"), oStruc.getOHpiValuationGrp().getOLastValValuation());
        assertEquals("24/10/2023", oStruc.getOHpiValuationGrp().getOLastValCreateDate());
        assertEquals(BigDecimal.ZERO, oStruc.getOHpiValuationGrp().getOLastValInsuranceValue());
        assertEquals("B", oStruc.getOHpiValuationGrp().getOLastValUpdatedBy());
        assertEquals("BATCH (HALIFAX HPI)", oStruc.getOHpiValuationGrp().getOLastValUpdatedByLit());
        assertEquals("", oStruc.getOHpiValuationGrp().getOLastValSurveyType());
        assertEquals("", oStruc.getOHpiValuationGrp().getOLastValSurveyTypeLit());


        assertEquals("31/03/2017", oStruc.getOAvmValuationGrp().getOAvmValuationDt());
        assertEquals("20230808223116900", oStruc.getOAvmValuationGrp().getOAvmUpdTmstmp());
        assertEquals(new BigDecimal("148188"), oStruc.getOAvmValuationGrp().getOAvmValuation());
        assertEquals(new BigDecimal("6.225"), oStruc.getOAvmValuationGrp().getOAvmConfLevel());

        assertEquals(75561601, oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSubseqChrgSeq());
        assertEquals("o_lender_s_name", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSName());
        assertEquals(new BigDecimal("97999.00"), oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAmount());
        assertEquals("o_subsq_chg_stat", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSubseqChgStat());
        assertEquals("o_subsq_chg_stat_lit", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSubseqChgStatLit());
        assertEquals("o_stat_of_subqchrg", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOStatOfSubqchrg());
        assertEquals("o_stat_of_subqchrg_lit", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOStatOfSubqchrgLit());
        assertEquals("o_lender_s_addr", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSAddr());
        assertEquals("o_lender_s_addr_1", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSAddr1());
        assertEquals("o_lender_s_addr_2", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSAddr2());
        assertEquals("o_lender_s_addr_3", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSAddr3());
        assertEquals("o_lender_s_county", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSCounty());
        assertEquals("o_lender_s_p_c", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLenderSPostCode());
        assertEquals("o_account_roll_no", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAccountRollNo());
        assertEquals("o_charge_type", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOChargeType());
        assertEquals("o_charge_type_lit", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOChargeTypeLit());
        assertEquals("03/10/2041", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOStartDate());
        assertEquals("o_action_required", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOActionRequired());
        assertEquals("o_action_required_lit", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOActionRequiredLit());
        assertEquals(new BigDecimal("0.00"), oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOLiabilityAmount());
        assertEquals("12/08/2071", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOValidToDate());
        assertEquals(71785413, oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOTerm());
        assertEquals("o_account_holder", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAccountHolder());
        assertEquals("o_account_holder_1", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAccountHolder1());
        assertEquals("o_account_holder_2", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAccountHolder2());
        assertEquals("o_account_holder_3", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOAccountHolder3());
        assertEquals(new BigDecimal("234.00"), oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOMonthlyPayment());
        assertEquals("o_purpose_of_loan", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOPurposeOfLoan());
        assertEquals("04/12/2071", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOEnquiryDate());
        assertEquals("04/06/2067", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getONotifcDate());
        assertEquals(new BigDecimal("0.00"), oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOFeeReceived());
        assertEquals(24718407, oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getONumBorrAuth());
        assertEquals("o_contact_name", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOContactName());
        assertEquals("(314) 906-5356", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOTelephone());
        assertEquals("4483426449096704", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOFaxNumber());
        assertEquals("(259) 784-7305", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSendByFax());
        assertEquals("o_dx_address", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getODxAddress());
        assertEquals("o_spec_uw_reqd", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSpecUwReqd());
        assertEquals("o_spec_uw_action", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSpecUwAction());
        assertEquals("o_spec_uw_action_lit", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOSpecUwActionLit());
        assertEquals("o_in_favour_of", oStruc.getOSubseqChargeArrangementTab().getOSubseqChargeArrangements().get(0).getOInFavourOf());

        assertEquals("ERRWS001", oStruc.getEStruc().getECode());
        assertEquals("Account does not exist", oStruc.getEStruc().getEMessage());
        assertEquals("MBSOACDT", oStruc.getEStruc().getEProgname());


    }
}
