package com.santanderuk.corinthian.services.commons.internalaccounts;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectMapper;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.RetrieveInternalAccountsServiceUrls;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class RetrieveInternalAccountsTest {

    RetrieveInternalAccounts internalAccounts;

    @Mock
    BksConnectMapper mockMccMapper;

    @Mock
    BksConnectClient bksConnectClient;

    @BeforeEach
    void setUp() {
        internalAccounts = new RetrieveInternalAccounts(mockMccMapper, bksConnectClient);
    }

    @Test
    void shouldInvokeMethodsOnce() throws ConnectionException {
        internalAccounts.getAccounts("78p0KPs6", new BdpCustomer(), new RetrieveInternalAccountsServiceUrls("url1","url2"));
        verify(mockMccMapper, times(1)).getRetrieveMccRequest(anyString());
        verify(bksConnectClient, times(1)).getMcc(anyString(), any());
        verify(mockMccMapper, times(1)).getCustomerAccountsRequest(any(), any());
        verify(bksConnectClient, times(1)).getCustomerAccount(anyString(), any());
    }
}
