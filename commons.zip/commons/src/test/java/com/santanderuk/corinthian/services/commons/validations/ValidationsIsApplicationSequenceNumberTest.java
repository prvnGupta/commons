package com.santanderuk.corinthian.services.commons.validations;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.util.AssertionErrors.assertFalse;


@ExtendWith(MockitoExtension.class)
public class ValidationsIsApplicationSequenceNumberTest {

    @InjectMocks
    Validations validations;
    private int[] validValues = new int[]{
            1, 12
    };
    private int[] invalidValues = new int[]{
            -11, -1, 123, 1234, 12345, 123456, 1234567, 12345678, 123456789
    };

    @Test
    public void testValid() {
        Arrays.stream(validValues).forEach(applicationSequenceNumber ->
                assertTrue(validations.isApplicationSequenceNumber(applicationSequenceNumber), "Application sequence number: " + applicationSequenceNumber + " should be correct")
        );
    }

    @Test
    public void testInvalid() {
        Arrays.stream(invalidValues).forEach(applicationSequenceNumber ->
                assertFalse("Application sequence number: " + applicationSequenceNumber + " should not be accepted", validations.isApplicationSequenceNumber(applicationSequenceNumber))
        );
    }
}
