package com.santanderuk.corinthian.services.commons.clients.heartbeat;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.io.HeartBeatResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
public class HeartBeatClient {

    public static final MaintenanceException.Type MAINTENANCE_REGION_X = MaintenanceException.Type.MAINTENANCE_REGION_X;
    public static final ConnectionException.Type HEARTBEAT_CONNECTION_ERROR = ConnectionException.Type.HEARTBEAT_CONNECTION_ERROR;

    @Value("${heartbeat.get-region}")
    private String getRegionUrl;

    @Autowired
    private RestTemplate restTemplate;

    public HeartBeatClient() {
        // Hearbeatclinet
    }

    public AnmfRegion fetchCurrentRegion() throws MaintenanceException, ConnectionException {

        ResponseEntity<HeartBeatResponse> heartBeatResponse = callHeartBeatService(getRegionUrl);

        if (isRegionA(heartBeatResponse)) {
            return AnmfRegion.A;
        } else if (isRegionW(heartBeatResponse)) {
            return AnmfRegion.W;
        } else {
            throw new MaintenanceException(MAINTENANCE_REGION_X);
        }
    }

    private boolean isRegionW(ResponseEntity<HeartBeatResponse> heartBeatResponse) {
        return "w".equalsIgnoreCase(heartBeatResponse.getBody().getRegion());

    }

    private boolean isRegionA(ResponseEntity<HeartBeatResponse> heartBeatResponse) {
        return "a".equalsIgnoreCase(heartBeatResponse.getBody().getRegion());
    }

    private ResponseEntity<HeartBeatResponse> callHeartBeatService(String url) throws ConnectionException {
        HttpEntity entity = createHttpEntity();
        try {
            return restTemplate.exchange(url, GET, entity, HeartBeatResponse.class);
        } catch (RestClientException e) {
            throw new ConnectionException(HEARTBEAT_CONNECTION_ERROR, e);
        }
    }

    private HttpEntity createHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);

        return new HttpEntity(headers);
    }
}
