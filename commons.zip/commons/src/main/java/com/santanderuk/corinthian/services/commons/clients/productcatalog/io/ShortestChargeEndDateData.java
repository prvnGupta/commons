package com.santanderuk.corinthian.services.commons.clients.productcatalog.io;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShortestChargeEndDateData {
    private String shortestChargeEndDate;
}
