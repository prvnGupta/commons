package com.santanderuk.corinthian.services.commons.internalaccounts;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectMapper;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.RetrieveInternalAccountsServiceUrls;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.ContractsInMccRequest;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import org.springframework.stereotype.Component;

@Component
public class RetrieveInternalAccounts {

    private final BksConnectMapper bksConnectMapper;
    private final BksConnectClient bksConnectClient;

    public RetrieveInternalAccounts(BksConnectMapper bksConnectMapper, BksConnectClient bksConnectClient) {
        this.bksConnectMapper = bksConnectMapper;
        this.bksConnectClient = bksConnectClient;
    }

    public ContractsInMccControllerResponse getAccounts(String ldapUid, BdpCustomer bdpCustomer, RetrieveInternalAccountsServiceUrls retrieveInternalAccountsServiceUrls) throws ConnectionException {
        RetrieveMccControllerRequest retrieveMccControllerRequest = bksConnectMapper.getRetrieveMccRequest(ldapUid);
        RetrieveMccResponse retrieveMccResponse = bksConnectClient.getMcc(retrieveInternalAccountsServiceUrls.getRetrieveMccUrl(), retrieveMccControllerRequest);
        ContractsInMccRequest decorateMccRequest = bksConnectMapper.getCustomerAccountsRequest(retrieveMccResponse, bdpCustomerToIocBdpCustomer(bdpCustomer));
        return bksConnectClient.getCustomerAccount(retrieveInternalAccountsServiceUrls.getContractsInMccUrl(), decorateMccRequest);
    }

    private com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.BdpCustomer bdpCustomerToIocBdpCustomer(BdpCustomer bdpCustomer) {
        com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.BdpCustomer iocBdpCustomer = new com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.BdpCustomer();
        iocBdpCustomer.setBdpCustomertype(bdpCustomer.getCustomerType());
        iocBdpCustomer.setBdpCustomerCode(bdpCustomer.getCustomerNumber());
        return iocBdpCustomer;
    }
}
