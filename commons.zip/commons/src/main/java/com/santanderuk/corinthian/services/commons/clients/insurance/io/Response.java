package com.santanderuk.corinthian.services.commons.clients.insurance.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Response extends ModelBase {

    private static final long serialVersionUID = 4904225644866606378L;
    private String responseCode;
    private String responseDesc;
}
