
package com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OStruc extends ModelBase {

    @JsonProperty("o_account_title")
    public String oAccountTitle;
    @JsonProperty("o_goneaway_flag")
    public String oGoneawayFlag;
    @JsonProperty("o_goneaway_flag_desc")
    public String oGoneawayFlagDesc;
    @JsonProperty("o_customer_list")
    public List<OCustomer> oCustomerList = null;
    @JsonProperty("e_struc")
    public EStruc eStruc;

}
