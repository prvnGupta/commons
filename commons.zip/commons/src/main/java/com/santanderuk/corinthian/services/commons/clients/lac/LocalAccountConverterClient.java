package com.santanderuk.corinthian.services.commons.clients.lac;


import com.santanderuk.corinthian.services.commons.clients.lac.io.response.LacResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

@Component
@Slf4j
public class LocalAccountConverterClient {
    public static final String X_IBM_CLIENT_SECRET = "X-IBM-Client-Secret";
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";
    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public LocalAccountConverterClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public String localAccountToPartenonFormat(String lacServiceUrl, String localAccount) throws ConnectionException {

        try {
            log.debug("About to call LAC with account number: {}", localAccount);
            log.info("About to call LAC.");

            String url = addAccountToUrl(lacServiceUrl, localAccount);
            HttpEntity<Void> entity = new HttpEntity<>(buildHeaders());
            ResponseEntity<LacResponse> responseEntity = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    LacResponse.class);

            LacResponse lacResponse = responseEntity.getBody();
            log.debug("Lac call response received: {}", lacResponse);
            log.info("Lac call response received");

            return Objects.requireNonNull(lacResponse).getOutputList().get(0).getContractOutputId();

        } catch (Exception e) {
            log.warn("Exception while calling LAC API");
            throw new ConnectionException("LAC_CLIENT_EXC", "Exception while calling LAC core service: ", e);
        }
    }

    public MultiValueMap<String, String> buildHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(X_IBM_CLIENT_ID, apiManagerConfig.getClientIdValue());
        headers.add(X_IBM_CLIENT_SECRET, apiManagerConfig.getClientSecretValue());
        headers.add("Content-Type", "application/json");
        return headers;
    }

    private String addAccountToUrl(String lacUrl, String localAccount) {
        return lacUrl.replace("{localAccount}", localAccount);
    }

}
