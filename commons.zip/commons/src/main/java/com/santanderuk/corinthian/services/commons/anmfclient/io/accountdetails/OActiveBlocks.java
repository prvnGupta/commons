package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OActiveBlocks extends ModelBase {
    private final static long serialVersionUID = -6108817779633642738L;

    @JsonProperty("o_activity_code")
    private String oActivityCode;
    @JsonProperty("o_activity_desc")
    private String oActivityDesc;
    @JsonProperty("o_block_from_date")
    private String oBlockFromDate;
    @JsonProperty("o_block_to_date")
    private String oBlockToDate;

}
