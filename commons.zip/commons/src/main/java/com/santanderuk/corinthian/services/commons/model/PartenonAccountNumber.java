package com.santanderuk.corinthian.services.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"company", "centre", "product", "contract"})
@AllArgsConstructor
@NoArgsConstructor
public class PartenonAccountNumber extends ModelBase {

    private static final long serialVersionUID = 2057508733759870541L;

    @NotNull
    @Pattern(regexp = "[0-9]{4}")
    private String company;

    @NotNull
    @Pattern(regexp = "[0-9]{4}")
    private String centre;

    @NotNull
    @Pattern(regexp = "[0-9]{3}")
    private String product;

    @NotNull
    @Pattern(regexp = "[0-9]{7}")
    private String contract;
}
