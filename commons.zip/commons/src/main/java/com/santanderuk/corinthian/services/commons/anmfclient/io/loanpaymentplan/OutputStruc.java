
package com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OutputStruc extends ModelBase {

    @JsonProperty("o_payment_method")
    private String oPaymentMethod;
    @JsonProperty("o_payment_method_desc")
    private String oPaymentMethodDesc;
    @JsonProperty("o_payment_day")
    private Integer oPaymentDay;
    @JsonProperty("o_last_payment_date")
    private String oLastPaymentDate;
    @JsonProperty("o_next_payment_date")
    private String oNextPaymentDate;
    @JsonProperty("o_next_avail_payment_dt")
    private String oNextAvailPaymentDt;
    @JsonProperty("o_bacs_cycle")
    private String oBacsCycle;
    @JsonProperty("o_direct_debit_details")
    private ODirectDebitDetails oDirectDebitDetails;
    @JsonProperty("o_rv_detail")
    private List<Object> oRvDetail;
    @JsonProperty("e_struc")
    private EStruc eStruc;
}
