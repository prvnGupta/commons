package com.santanderuk.corinthian.services.commons.clients.bksconnect.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "kcError",
        "endList",
        "mccContract",
        "ldapUid",
        "currency",
        "status",
        "modCapta"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveMccDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("kcError")
    private KcError kcError;
    @JsonProperty("endList")
    private String endList;
    @JsonProperty("mccContract")
    private MccContract mccContract;
    @JsonProperty("ldapUid")
    private String ldapUid;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("status")
    private String status;
    @JsonProperty("modCapta")
    private String modCapta;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("kcError", kcError)
                .append("endList", endList)
                .append("mccContract", mccContract)
                .append("ldapUid", ldapUid)
                .append("currency", currency)
                .append("status", status)
                .append("modCapta", modCapta)
                .toString();
    }
}
