package com.santanderuk.corinthian.services.commons.clients.bksconnect;


public class BksConnectConfig {
    // RETRIEVE MCC
    public static final String RETRIEVE_MCC_PROFILE_COMPANY = "0015";
    public static final String RETRIEVE_MCC_PROFILE_CHANNEL = "OFI";
    public static final String RETRIEVE_MCC_INPUT_CHANNEL = "INT";
    public static final String RETRIEVE_MCC_OPTION = "2";

    // CONTRACTS IN MCC
    public static final String CONTRACTS_IN_MCC_SECURITY_INPUT_CHANNEL = "OFI";
    public static final String CONTRACTS_IN_MCC_INPUT_OPERATION = "L";
    public static final String CONTRACTS_IN_MCC_INPUT_CONNECTION_CHANNEL = "INT";
    public static final String CONTRACTS_IN_MCC_INPUT_PERSONALISATION_CHANNEL = "INT";
    public static final String CONTRACTS_IN_MCC_INPUT_ELECTRONIC_CHANNEL = "INT";
    public static final String CONTRACTS_IN_MCC_INPUT_COMPANY = "0015";
    public static final String CONTRACTS_IN_MCC_INPUT_SERVICE = "00000024";
}
