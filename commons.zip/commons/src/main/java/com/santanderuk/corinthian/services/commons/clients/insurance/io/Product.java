package com.santanderuk.corinthian.services.commons.clients.insurance.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Product extends ModelBase {

    private String customerType;
    private long customerNumber;
    private String uniqueIdentifierAlpha;
    private long uniqueIdentifierNumeric;
    private int productReference;
    private String partenonProduct;
    private String subProduct;
    private String standardReference;
    private String productDescription;
    private String instantPrice;
    private String deepLink;
    private String vendor;
    private String startDate;
    private String endDate;
    private String isPriceActive;
    private String recordEnriched;
    private String channel;
    private String sumAssured;
    private int term;
    private String singleJointFlag;
    private String coverType;
    private String calculationType;
    private int noOfBedrooms;
    private int noOfBathrooms;
    private String riskPostcode;
    private String propertyType;
    private int daysPropertyUnoccupied;
    private String buildingExcess;
    private int claimsFreeYears;
    private int yearPropertyBuilt;
    private int age;
    private String annualPrice;
    private String dateProcessed;
    private String product;

}
