package com.santanderuk.corinthian.services.commons.mappers;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class View extends ModelBase {
    private static final long serialVersionUID = -5276855768068967077L;

    private HeaderView headerView;
    private BodyView bodyView;
}
