package com.santanderuk.corinthian.services.commons.clients.productcatalog.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "productCode",
        "productDescription",
        "maxLTV",
        "rate",
        "chargeEndDate",
        "productFee",
        "startDate",
        "endDate",
        "earlyRepaymentCharge",
        "type",
        "term",
        "sub_TYPE",
        "apr",
        "santanderSVRRate",
        "bankOfEnglandSVRRate",
        "alRate"
})
@Getter
@Setter
public class ProductData {

    @JsonProperty("productCode")
    private String productCode;
    @JsonProperty("productDescription")
    private String productDescription;
    @JsonProperty("maxLTV")
    private Integer maxLTV;
    @JsonProperty("rate")
    private Double rate;
    @JsonProperty("chargeEndDate")
    private String chargeEndDate;
    @JsonProperty("productFee")
    private Integer productFee;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("endDate")
    private String endDate;
    @JsonProperty("earlyRepaymentCharge")
    private BigDecimal earlyRepaymentCharge;
    @JsonProperty("type")
    private String type;
    @JsonProperty("term")
    private String term;
    @JsonProperty("sub_TYPE")
    private String subTYPE;
    @JsonProperty("apr")
    private Integer apr;
    @JsonProperty("santanderSVRRate")
    private Double santanderSVRRate;
    @JsonProperty("bankOfEnglandSVRRate")
    private Double bankOfEnglandSVRRate;
    @JsonProperty("alRate")
    private Double alRate;

}
