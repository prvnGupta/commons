package com.santanderuk.corinthian.services.commons.operativesecurity;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.commons.validations.Validations;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class AnmfBelongToCustomerService {

    public static final ValidationsException.Type EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT = ValidationsException.Type.EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT;

    @Autowired
    private AnmfCoreClient anmfClient;

    @Autowired
    private Validations validations;


    public boolean anmfBelongsToCustomer(int account, String jwtAuth, final String borrowerInfoUrl, final AnmfRegion region) throws ValidationsException, ConnectionException {
        validateAccount(account);
        BdpCustomer bdpCustomer = getBdpCustomerFromToken(jwtAuth);
        return anmfBelongsToBdpCustomer(account, bdpCustomer, borrowerInfoUrl, region);
    }


    private boolean anmfBelongsToBdpCustomer(final int account, BdpCustomer bdpCustomer, final String borrowerInfoUrl, final AnmfRegion region) throws ConnectionException {
        CustomerDetailsResponse customerDetailsResponse = getMortgageCustomerDetailsResponse(account, borrowerInfoUrl, region);
        long coincidencesFound = getCoincidencesFoundForCustomerInJwtWithCustomersFromANMFCall(bdpCustomer, customerDetailsResponse);
        if (coincidencesFound == 0) {
            log.info("Operative Security KO. Customer not found in Customers response");
        } else {
            log.info("Operative Security OK. Customer found in Customers response");
        }
        return coincidencesFound != 0;
    }

    private long getCoincidencesFoundForCustomerInJwtWithCustomersFromANMFCall(BdpCustomer bdpCustomer, CustomerDetailsResponse customerDetailsResponse) {
        return customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().stream()
                .filter(customer ->
                        customer.getOCustomerId().equals(bdpCustomer.getCustomerNumber())
                                &&
                                customer.getOBdpType().equalsIgnoreCase(bdpCustomer.getCustomerType())
                )
                .count();
    }


    public CustomerDetailsResponse getMortgageCustomerDetailsResponse(final int account, final String borrowerInfoUrl, final AnmfRegion region) throws ConnectionException {
        log.info("Calling ANMF Borrower service for operative security");
        return anmfClient.fetchMortgageCustomerDetailsV4(account, borrowerInfoUrl, region);
    }

    private BdpCustomer getBdpCustomerFromToken(String jwtAuth) {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtAuth);
        log.debug("Customer on JWT token: {}", bdpCustomer);
        return bdpCustomer;
    }

    private void validateAccount(int account) throws ValidationsException {
        if (!validations.isAccountNumber(account)) {
            log.error("Invalid input account");
            throw new ValidationsException(EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT);
        }
    }
}
