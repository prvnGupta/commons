package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UkAddressEnquire extends ModelBase {

    private static final long serialVersionUID = -7550267946048300650L;

    private String premise;
    private String alternativePremise;
    private String primaryStreet;
    private String primaryDistrict;
    private String secondaryStreet;
    private String secondaryDistrict;
    private String town;
    private String postCode;

}
