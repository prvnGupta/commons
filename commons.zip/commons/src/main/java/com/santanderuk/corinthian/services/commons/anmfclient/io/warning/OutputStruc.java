package com.santanderuk.corinthian.services.commons.anmfclient.io.warning;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OutputStruc extends ModelBase {

    @JsonProperty("o_process")
    private String oProcess;

    @JsonProperty("o_process_desc")
    private String oProcessDesc;

    @JsonProperty("o_warning_process_arr_tab")
    private OWarningProcessArrTab oWarningProcessArrTab;

    @JsonProperty("e_struc")
    private EStruc eStruc;
}