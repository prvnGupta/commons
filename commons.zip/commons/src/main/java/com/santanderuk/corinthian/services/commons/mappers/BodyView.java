package com.santanderuk.corinthian.services.commons.mappers;

public enum BodyView {

    TRACKING, NOT_TRACKING
}
