
package com.santanderuk.corinthian.services.commons.clients.productdirectory.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Term extends ModelBase {

    private Long months;
    private Long years;

}
