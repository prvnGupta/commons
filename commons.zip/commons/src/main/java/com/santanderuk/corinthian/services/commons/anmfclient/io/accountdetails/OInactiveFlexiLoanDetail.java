package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class OInactiveFlexiLoanDetail extends ModelBase {

    @JsonProperty("o_loan_scheme")
    private String oLoanScheme;
    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;
    @JsonProperty("o_repayment_type")
    private String oRepaymentType;
    @JsonProperty("o_repayment_type_lit")
    private String oRepaymentTypeLit;
    @JsonProperty("o_balance")
    private BigDecimal oBalance;
    @JsonProperty("o_start_date")
    private String oStartDate;
    @JsonProperty("o_redemption_date")
    private String oRedemptionDate;
    @JsonProperty("o_product_code")
    private String oProductCode;
    @JsonProperty("o_charged_until")
    private String oChargedUntil;
    @JsonProperty("o_chrge_until_mths")
    private int oChrgeUntilMths;
    @JsonProperty("o_mort_range")
    private String oMortRange;
    @JsonProperty("o_range_name")
    private String oRangeName;
    @JsonProperty("o_interest_rate")
    private BigDecimal oInterestRate;
    @JsonProperty("o_base_rate")
    private BigDecimal oBaseRate;
    @JsonProperty("o_base_rate_diff")
    private BigDecimal oBaseRateDiff;
    @JsonProperty("o_product_type")
    private String oProductType;
    @JsonProperty("o_product_desc")
    private String oProductDesc;
    @JsonProperty("o_product_end_date")
    private String oProductEndDate;
}
