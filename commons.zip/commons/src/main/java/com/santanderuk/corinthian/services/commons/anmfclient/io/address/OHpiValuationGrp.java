package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_last_val_date",
        "o_last_val_valuation",
        "o_last_val_create_date",
        "o_last_val_insurance_value",
        "o_last_val_updated_by",
        "o_last_val_updated_by_lit",
        "o_last_val_survey_type",
        "o_last_val_survey_type_lit"
})
public class OHpiValuationGrp extends ModelBase {

    private static final long serialVersionUID = 1L;

    @JsonProperty("o_last_val_date")
    public String oLastValDate;
    @JsonProperty("o_last_val_valuation")
    public BigDecimal oLastValValuation;
    @JsonProperty("o_last_val_create_date")
    public String oLastValCreateDate;
    @JsonProperty("o_last_val_insurance_value")
    public BigDecimal oLastValInsuranceValue;
    @JsonProperty("o_last_val_updated_by")
    public String oLastValUpdatedBy;
    @JsonProperty("o_last_val_updated_by_lit")
    public String oLastValUpdatedByLit;
    @JsonProperty("o_last_val_survey_type")
    public String oLastValSurveyType;
    @JsonProperty("o_last_val_survey_type_lit")
    public String oLastValSurveyTypeLit;
}
