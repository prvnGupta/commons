package com.santanderuk.corinthian.services.commons.exceptions;

/*
    This exception is for propagating to the frontend the messages coming in the e_struc in the answer from ANMF.
    Those messages are there only if there is an error and we will be sending them to the frontend
 */
public class ReportedException extends GeneralException {

    public ReportedException(String code, String message) {
        super(code, message);
    }

    public ReportedException(String code, String message, Exception e) {
        super(code, message, e);
    }

}
