package com.santanderuk.corinthian.services.commons.anmfclient;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.address.ANMFPropertyResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.ANMFPaymentArrangementResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.AnmfPaymentHolidayAmendCancelRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response.AnmfPaymentHolidayAmendCancelResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.AnmfPaymentHolidayResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.ANMFRedemptionsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionIllustrationErrorResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions.RedemptionsInput;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;


@Slf4j
@Component
public class AnmfCoreClient {

    public static final ConnectionException.Type ANMF_UNAVAILABLE = ConnectionException.Type.ANMF_UNAVAILABLE;
    public static final ConnectionException.Type ANMF_RESPONSE_BAD_FORMAT = ConnectionException.Type.ANMF_RESPONSE_BAD_FORMAT;
    public static final String LONG_LIFE_CACHE = "cacheManagerLongLife";
    public static final String SHORT_LIFE_CACHE = "cacheManagerShortLife";

    //Do not delete these CONSTANTS. They are used even if it does not look like.
    public static final String KEY_MORTGAGE_ACCOUNT_DETAILS_V5 = "fetch-anmf-mortgage-account-details-v5-";
    public static final String KEY_LOAN_PAYMENT_PLAN = "fetch-anmf-loan-payment-plan-";
    public static final String KEY_ADDRESS_INFO = "fetch-anmf-propertyV7-info-";
    public static final String KEY_OVERPAYMENT_ARRANGEMENTS = "fetch-anmf-ov-arrangements-";
    public static final String KEY_CUSTOMER_SERVICE_V4 = "fetch-anmf-mortgage-customer-details-v4-";
    public static final String KEY_REDEMPTIONS = "fetch-anmf-redemptions-";

    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public AnmfCoreClient(ObjectMapper objectMapper, RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.objectMapper = objectMapper;
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    /**
     * 26-May-2021: I have reverted the changes of below commit URLs.As of now we only need to pass REGION as a header in Collateral and setup/edit/cancel endpoint
     * https://uk-gitlab.almuk.santanderuk.corp/corinthian/services/commons/-/commit/12554c23980d5764ccd3aeb5b2c9cb75a05a1716 [Changes on 20-May-2021]
     * https://uk-gitlab.almuk.santanderuk.corp/corinthian/services/commons/-/commit/d4ad3643771fba73bb95b1d33b9b10c79b1444f7 [Changes on 25-May-2021]
     * Please remove this comment once we migrate all apis with Region as header
     */

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-anmf-loan-payment-plan",
            value = "fetch-anmf-loan-payment-plan",
            key = "#root.target.KEY_LOAN_PAYMENT_PLAN + #accountNumber")
    public AnmfLoanPaymentPlanResponse fetchLoanPaymentPlan(final int accountNumber, final String url, final AnmfRegion region) throws ConnectionException {

        final String parameterisedUrl = parameterisedUrl(url, accountNumber, region);
        final String responseBody = fetchResponseBody(parameterisedUrl);

        return convertResponseToObject(responseBody, AnmfLoanPaymentPlanResponse.class);
    }

    @Cacheable(cacheManager = SHORT_LIFE_CACHE,
      cacheNames = "fetch-anmf-mortgage-account-details-v5",
      value = "fetch-anmf-mortgage-account-details-v5",
      key = "#root.target.KEY_MORTGAGE_ACCOUNT_DETAILS_V5 + #accountNumber")
    public AnmfAccountServiceResponse fetchMortgageAccountDetailsV5(final int accountNumber, final String url, final AnmfRegion region) throws ConnectionException {

      final String parameterisedUrl = parameterisedUrl(url, accountNumber);
      final String responseBody = fetchResponseBody(parameterisedUrl, region);

      return convertResponseToObject(responseBody, AnmfAccountServiceResponse.class);
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-anmf-mortgage-customer-details-v4",
            value = "fetch-anmf-mortgage-customer-details-v4",
            key = "#root.target.KEY_CUSTOMER_SERVICE_V4 + #accountNumber")
    public CustomerDetailsResponse fetchMortgageCustomerDetailsV4(final int accountNumber, final String url, final AnmfRegion region) throws ConnectionException {

        final String parameterisedUrl = parameterisedUrl(url, accountNumber);
        final String responseBody = fetchResponseBody(parameterisedUrl, region);

        return convertResponseToObject(responseBody, CustomerDetailsResponse.class);
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-anmf-propertyV7-info",
            value = "fetch-anmf-propertyV7-info",
            key = "#root.target.KEY_ADDRESS_INFO + #accountNumber")
    public ANMFPropertyResponse fetchAddress(final int accountNumber, final String url, final AnmfRegion region) throws ConnectionException {

        final String parameterisedUrl = parameterisedUrl(url, accountNumber);
        final String responseBody = fetchResponseBody(parameterisedUrl, region);

        return convertResponseToObject(responseBody, ANMFPropertyResponse.class);
    }

    @Cacheable(cacheManager = SHORT_LIFE_CACHE,
            cacheNames = "fetch-anmf-ov-arrangements",
            value = "fetch-anmf-ov-arrangements",
            key = "#root.target.KEY_OVERPAYMENT_ARRANGEMENTS + #accountNumber")
    public ANMFPaymentArrangementResponse fetchMortgageArrangements(final int accountNumber, final String url, final String transactionType, final AnmfRegion region) throws ConnectionException {

        final String parameterisedUrl = parameterizeRegularOverpaymentsEnquiryUrl(url, accountNumber, transactionType);
        final String responseBody = fetchResponseBody(parameterisedUrl, region);

        return convertResponseToObject(responseBody, ANMFPaymentArrangementResponse.class);
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-anmf-redemptions",
            value = "fetch-anmf-redemptions",
            key = "#root.target.KEY_REDEMPTIONS + #redemptionsInput.request.accountNumber + #redemptionsInput.request.redemptionDate")
    public ANMFRedemptionsResponse fetchRedemption(RedemptionsInput redemptionsInput) throws ConnectionException {
        String url = redemptionsInput.getUrl();
        ANMFRedemptionsRequest request = redemptionsInput.getRequest();

        MultiValueMap<String, String> headers = generateHttpHeaders();

        HttpEntity<ANMFRedemptionsRequest> httpEntity = new HttpEntity<>(request, headers);

        ResponseEntity<ANMFRedemptionsResponse> responseEntity;

        try {
            log.info("postFetchRedemption - > Calling ANMF Redemptions microservice: {}", url);
            log.debug("headers: {}", headers);
            log.debug("postFetchRedemption - > Sending object: {}", request);
            responseEntity = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    ANMFRedemptionsResponse.class
            );
            log.debug("JSON Response -> {}", responseEntity.getBody());

        } catch (HttpStatusCodeException httpStatusEx) {
            log.warn(String.format("HttpStatusCodeException while calling redemption illustration core service: %s", httpStatusEx.getMessage()), httpStatusEx);
            return getComplexErrors(httpStatusEx);
        } catch (RestClientException e) {
            log.error("postFetchRedemption -> error while connecting to ANMF Redemptions microservice");
            throw new ConnectionException(ANMF_UNAVAILABLE, e);
        }

        return responseEntity.getBody();
    }

    public AnmfRegularOverpaymentCUDResponse setupRegularPayment(AnmfRegularOverpaymentCUDRequest request, final String url) throws ConnectionException {
        return fetchResponseBodyFromSetUpRegular(url, request);
    }

    public AnmfRegularOverpaymentCUDResponse editRegularPayment(AnmfRegularOverpaymentCUDRequest request, final String url) throws ConnectionException {
        return fetchResponseBodyFromSetUpRegular(url, request);
    }

    public AnmfRegularOverpaymentCUDResponse deleteRegularPayment(AnmfRegularOverpaymentCUDRequest request, final String url) throws ConnectionException {
        return fetchResponseBodyFromSetUpRegular(url, request);
    }


    private AnmfRegularOverpaymentCUDResponse fetchResponseBodyFromSetUpRegular(final String url, final AnmfRegularOverpaymentCUDRequest request) throws ConnectionException {
        log.info("Calling ANMF with URL : {}", url.replaceAll("[\r\n]", ""));

        log.info("fetchResponseBodyFromSetUpRegular - > Adding JWT token to request headers");
        MultiValueMap<String, String> headers = generateHttpHeaders();

        HttpEntity<AnmfRegularOverpaymentCUDRequest> httpEntity = new HttpEntity<>(request, headers);
        log.debug("headers: {}", headers);
        log.info("hub-anmf - > Calling ANMF Simulation Microservice");

        ResponseEntity<AnmfRegularOverpaymentCUDResponse> responseEntity;

        try {
            log.info("fetchResponseBodyFromSetUpRegular - > Calling ANMF Simulation microservice: {}", url);
            log.debug("fetchResponseBodyFromSetUpRegular - > Sending object: {}", request);
            responseEntity = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    AnmfRegularOverpaymentCUDResponse.class
            );
            log.debug("JSON Response -> {}", responseEntity.getBody());
        } catch (RestClientException e) {
            log.error("fetchResponseBodyFromSetUpRegular -> error while connecting to ANMF Set-up regular microservice");
            throw new ConnectionException(ANMF_UNAVAILABLE, e);
        }
        return responseEntity.getBody();
    }

    public AnmfPaymentHolidayResponse fetchPaymentHolidayDetails(int accountNumber, final String url, final AnmfRegion region) throws ConnectionException {
        final String parameterisedUrl = parameterisedUrl(url, accountNumber, region);
        final String responseBody = fetchResponseBody(parameterisedUrl);

        return convertResponseToObject(responseBody, AnmfPaymentHolidayResponse.class);
    }

    public AnmfPaymentHolidayAmendCancelResponse amendCancelPaymentHoliday(AnmfPaymentHolidayAmendCancelRequest request, final String url, final AnmfRegion region) throws ConnectionException {
        final String regionUrl = parameterisedUrl(url, region);
        return postAmendCancelPaymentHoliday(regionUrl, request);
    }

    private AnmfPaymentHolidayAmendCancelResponse postAmendCancelPaymentHoliday(final String url, final AnmfPaymentHolidayAmendCancelRequest request) throws ConnectionException {
        log.info("Calling ANMF with URL : {}", url.replaceAll("[\r\n]", ""));

        log.info("postAmendCancelPaymentHoliday - > Adding JWT token to request headers");
        MultiValueMap<String, String> headers = generateHttpHeaders();

        HttpEntity<AnmfPaymentHolidayAmendCancelRequest> httpEntity = new HttpEntity<>(request, headers);
        log.debug("headers: {}", headers);
        log.info("hub-anmf - > Calling ANMF Amend Cancel Payment Holiday Microservice");

        ResponseEntity<AnmfPaymentHolidayAmendCancelResponse> responseEntity;

        try {
            log.info("postAmendCancelPaymentHoliday - > Calling ANMF Amend Cancel Payment Holiday microservice: {}", url);
            log.debug("postAmendCancelPaymentHoliday - > Sending object: {}", request);
            responseEntity = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    AnmfPaymentHolidayAmendCancelResponse.class
            );
            log.debug("JSON Response -> {}", responseEntity.getBody());
        } catch (RestClientException e) {
            log.error("postAmendCancelPaymentHoliday -> error while connecting to ANMF Amend Cancel Payment Holiday microservice");
            throw new ConnectionException(ANMF_UNAVAILABLE, e);
        }
        return responseEntity.getBody();
    }



    private ANMFRedemptionsResponse getComplexErrors(HttpStatusCodeException httpStatusEx) throws ConnectionException {
        ANMFRedemptionsResponse anmfRedemptionsResponse = new ANMFRedemptionsResponse();
        RedemptionIllustrationErrorResponse redemptionIllustrationErrorResponse = convertResponseToObject(httpStatusEx.getResponseBodyAsString(), RedemptionIllustrationErrorResponse.class);
        anmfRedemptionsResponse.setErrors(redemptionIllustrationErrorResponse.getErrors());
        return anmfRedemptionsResponse;
    }



    private String fetchResponseBody(final String url) throws ConnectionException {
        try {
            log.info("Calling ANMF with URL : {}", url.replaceAll("[\r\n]", ""));

            final ResponseEntity<String> anmfCoreResponse = restTemplate.exchange(url, GET, createHttpEntity(), String.class);

            log.info("Have response back from ANMF");
            log.debug("Have response back from ANMF : {}", anmfCoreResponse.getBody());

            return anmfCoreResponse.getBody();
        } catch (RestClientException rce) {
            log.error("Error while connecting to ANMF. Error:", rce);
            throw new ConnectionException(ANMF_UNAVAILABLE, rce);
        }
    }

    private String fetchResponseBody(final String url, AnmfRegion anmfRegion) throws ConnectionException {
        try {
            log.info("Calling ANMF with URL : {}", url.replaceAll("[\r\n]", ""));

            final ResponseEntity<String> anmfCoreResponse = restTemplate.exchange(url, GET, createHttpEntity(anmfRegion), String.class);

            log.info("Have response back from ANMF");
            log.debug("Have response back from ANMF : {}", anmfCoreResponse.getBody());

            return anmfCoreResponse.getBody();
        } catch (RestClientException rce) {
            log.error("Error while connecting to ANMF. Error:", rce);
            throw new ConnectionException(ANMF_UNAVAILABLE, rce);
        }
    }

    private HttpEntity createHttpEntity() {
        final HttpHeaders headers = generateHttpHeaders();
        return new HttpEntity(headers);
    }

    private HttpEntity createHttpEntity(AnmfRegion anmfRegion) {
        final HttpHeaders headers = generateHttpHeaders();
        headers.add("Region", anmfRegion.toString());
        return new HttpEntity(headers);
    }

    private HttpHeaders generateHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }

    private String parameterisedUrl(final String url, final int idAccount, final AnmfRegion region) {
        return url
                .replace("{account}", Integer.toString(idAccount))
                .replace("{region}", region.toString().toLowerCase());
    }

    private String parameterisedUrl(final String url, final AnmfRegion region) {
        return url
                .replace("{region}", region.toString().toLowerCase());
    }

    private String parameterisedUrl(final String url, final int idAccount) {
        return url
                .replace("{account}", Integer.toString(idAccount));
    }

    private String parameterizeRegularOverpaymentsEnquiryUrl(final String url, final int accountNumber, final String transactionType) {
        String urlWithAccountNumber = url.replace("{account}", Integer.toString(accountNumber));
        return urlWithAccountNumber.replace("{transaction-type}", transactionType);
    }

    private <T> T convertResponseToObject(final String responseBody, final Class<T> cls) throws ConnectionException {
        try {
            return objectMapper.readValue(responseBody, cls);
        } catch (IOException e) {
            final String className = cls.getSimpleName();
            log.error("Failed to convert response to {}", className, e);
            throw new ConnectionException(ANMF_RESPONSE_BAD_FORMAT, e);
        }
    }

}
