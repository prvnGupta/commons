
package com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OIncome extends ModelBase {

    @JsonProperty("o_income_type")
    public String oIncomeType;
    @JsonProperty("o_income_amount")
    public Integer oIncomeAmount;

}
