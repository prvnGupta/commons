
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OActiveLoan extends ModelBase {

    @JsonProperty("o_loan_id")
    private int oLoanId;
    @JsonProperty("o_loan_sch")
    private String oLoanSch;
    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;

}
