package com.santanderuk.corinthian.services.commons.clients.heartbeat;

public enum AnmfRegion {
    A, W, X
}
