package com.santanderuk.corinthian.services.commons.clients.productdirectory.io;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Conditions extends ModelBase {

    private List<String> applicationType;
    private Long aprc;
    private List<String> band;
    private BigDecimal collarRate;
    private String completionDeadline;
    private String contingency;
    private Erc erc;
    private String feeCapitalisation;
    private BigDecimal interestRate;
    private String lendingType;
    private Long maxLtvPercentage;
    private Long maximumLoanAmount;
    private Long minimumLoanAmount;
    private BigDecimal productBaseRate;
    private BigDecimal productBaseRateDifferential;
    private BigDecimal reversionRate;
    private BigDecimal reversionBaseRate;
    private BigDecimal reversionBaseRateDifferential;
    private String reversionaryDescription;
    private BigDecimal productFee;
    private String productType;
    private String rangeType;
    private List<RateStep> rateSteps;
    private List<String> salesChannel;
    private String staffExclusive;
    private Term term;


}
