package com.santanderuk.corinthian.services.commons.clients.cae.io;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class EntitledAccountsResponse extends ModelBase {

    private List<Account> accounts;
    private List<Account> cards;
    private List<Account> loans;
    private List<Account> mortgages;
    private List<Account> investments;
    private List<Account> insurances;
    private List<Account> bonds;
    private Map<String, String> mapApiErrorByCode;

}
