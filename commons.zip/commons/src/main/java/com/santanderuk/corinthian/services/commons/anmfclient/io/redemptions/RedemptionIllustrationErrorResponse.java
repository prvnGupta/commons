package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class RedemptionIllustrationErrorResponse extends ModelBase {

    @JsonProperty("error")
    private List<RedeptionIllustrationError> errors = new ArrayList<>();
}
