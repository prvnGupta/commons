
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OCurrentDetailsBeforeBatch extends ModelBase {

    @JsonProperty("o_interest_rate")
    private BigDecimal oInterestRate;
    @JsonProperty("o_monthly_payment")
    private BigDecimal oMonthlyPayment;
    @JsonProperty("o_prod_erc")
    private OProdErc oProdErc;

}
