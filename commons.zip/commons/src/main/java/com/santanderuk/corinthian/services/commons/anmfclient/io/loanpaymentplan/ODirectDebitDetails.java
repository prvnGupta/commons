
package com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ODirectDebitDetails extends ModelBase {

    @JsonProperty("o_ddr_status")
    private String oDdrStatus;
    @JsonProperty("o_ddr_status_desc")
    private String oDdrStatusDesc;
    @JsonProperty("o_bank_account_name")
    private String oBankAccountName;
    @JsonProperty("o_bank_sort_code")
    private String oBankSortCode;
    @JsonProperty("o_bank_account")
    private Integer oBankAccount;
    @JsonProperty("o_bank_name")
    private String oBankName;
    @JsonProperty("o_bank_address")
    private String oBankAddress;
    @JsonProperty("o_bank_address_2")
    private String oBankAddress2;
    @JsonProperty("o_bank_address_3")
    private String oBankAddress3;
    @JsonProperty("o_bank_address_4")
    private String oBankAddress4;
    @JsonProperty("o_bank_postcode")
    private String oBankPostcode;
    @JsonProperty("o_date_changed")
    private String oDateChanged;
    @JsonProperty("o_bacs_auth_code")
    private Integer oBacsAuthCode;
    @JsonProperty("o_pending_changes")
    private Integer oPendingChanges;
    @JsonProperty("o_pending_aud")
    private List<OPendingAud> oPendingAud;
}
