package com.santanderuk.corinthian.services.commons.utilities;

import java.util.Optional;

public class LogMasker {

    public String withContentStatus(final String str) {

        return Optional.ofNullable(str)
                .map(s -> isEmpty(s) ? "EMPTY" : "POPULATED")
                .orElse("NULL");
    }

    private boolean isEmpty(final String str) {
        return null != str && str.length() == 0;
    }
}
