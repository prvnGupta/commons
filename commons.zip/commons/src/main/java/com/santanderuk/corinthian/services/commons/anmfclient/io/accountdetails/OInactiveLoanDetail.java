package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class OInactiveLoanDetail extends ModelBase {

    @JsonProperty("o_loan_scheme")
    private String oLoanScheme;
    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;
    @JsonProperty("o_repayment_type")
    private String oRepaymentType;
    @JsonProperty("o_repayment_type_lit")
    private String oRepaymentTypeLit;
    @JsonProperty("o_capital_balance")
    private BigDecimal oCapitalBalance;
    @JsonProperty("o_arrears_balance")
    private BigDecimal oArrearsBalance;
    @JsonProperty("o_rec_balance")
    private BigDecimal oRecBalance;
    @JsonProperty("o_drawdown_left")
    private BigDecimal oDrawdownLeft;
    @JsonProperty("o_outstanding_balance")
    private BigDecimal oOutstandingBalance;
    @JsonProperty("o_property_valuation_ret_amount")
    private BigDecimal oPropertyValuationRetamount;
    @JsonProperty("o_borrower_amount")
    private BigDecimal oBorrowerAmount;
    @JsonProperty("o_rdm_stm_erc")
    private BigDecimal oRdmStmErc;
    @JsonProperty("o_loan_purpose")
    private String oLoanPurpose;
    @JsonProperty("o_loan_purpose_lit")
    private String oLoanPurposeLit;
    @JsonProperty("o_monthly_pay")
    private BigDecimal oMonthlyPay;
    @JsonProperty("o_start_date")
    private String oStartDate;
    @JsonProperty("o_redemption_date")
    private String oRedemptionDate;
    @JsonProperty("o_remaining_instlm")
    private int oRemainingInstlm;
    @JsonProperty("o_rem_term_years")
    private int oRemTermYears;
    @JsonProperty("o_rem_term_months")
    private int oRemTermMonths;
    @JsonProperty("o_pend_redemption_date")
    private String oPendRedemptionDate;
    @JsonProperty("o_pend_remaining_instlm")
    private int oPendRemainingInstlm;
    @JsonProperty("o_product_code")
    private String oProductCode;
    @JsonProperty("o_product_catergory")
    private String oProductCatergory;
    @JsonProperty("o_product_catergory_desc")
    private String oProductCatergoryDesc;
    @JsonProperty("o_iom_tef")
    private String oIomTef;
    @JsonProperty("o_prod_erc")
    private OProdErc oProdErc;
    @JsonProperty("o_loan_erc")
    private OLoanErc oLoanErc;
    @JsonProperty("o_erc_appl_flag")
    private String oErcApplFlag;
    @JsonProperty("o_erc_allow_perc")
    private String oErcAllowPerc;
    @JsonProperty("o_charged_until")
    private String oChargedUntil;
    @JsonProperty("o_chrge_until_mths")
    private int oChrgeUntilMths;
    @JsonProperty("o_mort_range")
    private String oMortRange;
    @JsonProperty("o_range_name")
    private String oRangeName;
    @JsonProperty("o_interest_rate")
    private BigDecimal oInterestRate;
    @JsonProperty("o_cap_rate_used")
    private String oCapRateUsed;
    @JsonProperty("o_collar_rate_used")
    private String oCollarRateUsed;
    @JsonProperty("o_base_rate")
    private BigDecimal oBaseRate;
    @JsonProperty("o_base_rate_diff")
    private BigDecimal oBaseRateDiff;
    @JsonProperty("o_product_type")
    private String oProductType;
    @JsonProperty("o_product_desc")
    private String oProductDesc;
    @JsonProperty("o_staff_product")
    private String oStaffProduct;
    @JsonProperty("o_product_end_date")
    private String oProductEndDate;
    @JsonProperty("o_revi_period")
    private String oReviPeriod;
    @JsonProperty("o_revisionary_details")
    private ORevisionaryDetails oRevisionaryDetails;
}
