package com.santanderuk.corinthian.services.commons.clients.accountbalance.io;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountBalancesResponse implements Serializable {

    private static final long serialVersionUID = 6653710169464356678L;

    @JsonProperty("AccountsBalances")
    private List<AccountBalance> accountBalances;

    @JsonProperty("AdditionalInfo")
    private List<AdditionalInfo> additionalInfo;


    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}
