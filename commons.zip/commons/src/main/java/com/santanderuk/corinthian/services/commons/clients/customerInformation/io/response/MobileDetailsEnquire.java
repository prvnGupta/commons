package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MobileDetailsEnquire extends ModelBase {

    private static final long serialVersionUID = 935546914734178063L;

    private Boolean preferredContact;
    private String use;
    private String mobile;
    private AvailibilityMobile availibilityMobile;
}
