package com.santanderuk.corinthian.services.commons.clients.productdirectory;

import com.santanderuk.corinthian.services.commons.clients.productdirectory.io.ProductDetailsResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class ProductDirectoryClient {

    public static final String KEY_PRODUCT_DETAILS_PRODUCT_DIRECTORY = "fetch-product-details-product-directory-";
    public static final String KEY_PRODUCT_DIRECTORY_CONDITIONS = "fetch-product-directory-conditions-";
    public static final String LONG_LIFE_CACHE = "cacheManagerLongLife";
    public static final String SHORT_LIFE_CACHE = "cacheManagerShortLife";
    private final RestTemplate restTemplate;
    @Value("${apimanager.client-id-value}")
    private String clientId;

    public ProductDirectoryClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-product-details-product-directory",
            value = "fetch-product-details-product-directory",
            key = "#root.target.KEY_PRODUCT_DETAILS_PRODUCT_DIRECTORY + #productCode")
    public ProductDetailsResponse fetchProductDetailsFromDirectoryData(String productCode, String url) throws ConnectionException {

        String finalURL = url.replace("{productCode}", productCode);
        log.info("Calling product product-directory with URL : {}", finalURL.replaceAll("[\r\n]", ""));
        final ResponseEntity<ProductDetailsResponse> responseEntity;
        try {
            responseEntity = restTemplate.exchange(finalURL, GET, createHttpHeaders(), ProductDetailsResponse.class);
            log.info("Have response back from product product-directory");
            log.debug("Have response back from product product-directory : {}", responseEntity.getBody());
        } catch (Exception ex) {
            log.error("Product-directory core service did not respond correctly : ", ex);
            throw new ConnectionException(ex.getMessage(), "Product-directory core service did not respond correctly", ex);
        }
        return responseEntity.getBody();

    }

    @Cacheable(cacheManager = SHORT_LIFE_CACHE,
            cacheNames = "fetch-product-directory-conditions",
            value = "fetch-product-directory-conditions",
            key = "#root.target.KEY_PRODUCT_DIRECTORY_CONDITIONS + #queryParams.resultFilter + #queryParams.applicationType + #queryParams.rangeType")
    public ProductDirectoryResponse fetchProductDirectoryData(String url, QueryParams queryParams) throws ConnectionException {

        final String fullUrl = createUrl(url, queryParams);
        log.info("Calling product-directory with URL : {}", fullUrl.replaceAll("[\r\n]", ""));
        final ResponseEntity<ProductDirectoryResponse> responseEntity;
        try {
            responseEntity = restTemplate.exchange(fullUrl, GET, createHttpHeaders(), ProductDirectoryResponse.class);
            log.info("Have response back from product-directory");
            log.debug("Have response back from product-directory : {}", responseEntity.getBody());
        } catch (Exception ex) {
            log.error("Product-directory core service did not respond correctly : ", ex);
            throw new ConnectionException(ex.getMessage(), "Product-directory core service did not respond correctly", ex);
        }
        return responseEntity.getBody();
    }

    private String createUrl(String url, QueryParams queryParams) {
        return UriComponentsBuilder.fromUriString(url)
                .queryParam("result_filter", queryParams.getResultFilter())
                .queryParam("application_type", queryParams.getApplicationType())
                .queryParam("range_type", queryParams.getRangeType())
                .toUriString();
    }

    private HttpEntity<HttpHeaders> createHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", clientId);
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}
