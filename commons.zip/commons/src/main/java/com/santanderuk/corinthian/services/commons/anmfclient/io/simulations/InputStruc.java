package com.santanderuk.corinthian.services.commons.anmfclient.io.simulations;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class InputStruc extends ModelBase {

    @JsonProperty("i_simulation_id")
    private int iSimulationId;

    @JsonProperty("i_mort_acc_no")
    private int iMortAccNo;

    @JsonProperty("i_ovp_date")
    private String iOvpDate;

    @JsonProperty("i_tot_ovp_amount")
    private BigDecimal iTotOvpAmount;

    @JsonProperty("i_original_simulation_id")
    private int iOriginalSimulationId;

    @JsonProperty("i_erc_coll_opt")
    private String iErcCollOpt;

    @JsonProperty("i_chan_type_cd")
    private String iChanTypeCd;

    @JsonProperty("i_sim_version")
    private int iSimVersion;

    @JsonProperty("i_bdp_type")
    private String iBdpType;

    @JsonProperty("i_bdp_number")
    private int iBdpNumber;

    @JsonProperty("i_staff_id")
    private String iStaffId;

    @JsonProperty("i_calling_appl")
    private String iCallingAppl;

    @JsonProperty("i_distri_type")
    private String iDistriType;

    @JsonProperty("i_erc_allow_imp")
    private String iErcAllowImp;

    @JsonProperty("i_kfi_ref_no")
    private String iKfiRefNo;

    @JsonProperty("i_payment_data")
    private IPaymentData iPaymentData;

    @JsonProperty("i_user_id")
    private String iUserId;

    @JsonProperty("i_loan_data")
    private List<ILoanData> iLoanData = null;

}
