package com.santanderuk.corinthian.services.commons.clients.cae;

import com.santanderuk.corinthian.services.commons.clients.cae.io.EntitledAccountsResponse;
import com.santanderuk.corinthian.services.commons.clients.cae.io.QueryParams;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Component
public class CustomerAccessEntitlementClient {

    public static final String KEY_CUSTOMER_ACCESS_ENTITLEMENT = "fetch-customer-access-entitlement-";
    public static final String LONG_LIFE_CACHE = "cacheManagerLongLife";
    private final RestTemplate restTemplate;

    @Value("${apimanager.client-id-value}")
    private String clientId;

    public CustomerAccessEntitlementClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "fetch-customer-access-entitlement",
            value = "fetch-customer-access-entitlement",
            key = "#root.target.KEY_CUSTOMER_ACCESS_ENTITLEMENT + #queryParams.uid + #queryParams.operation")
    public EntitledAccountsResponse entitledAccounts(String url, QueryParams queryParams) throws GeneralException {
        String finalUrl = createFinalUrl(url, queryParams);
        log.info("Calling customer-access-entitlement/entitledAccounts with URL: {}", finalUrl);

        final ResponseEntity<EntitledAccountsResponse> response;
        try {
            response = restTemplate.exchange(finalUrl, HttpMethod.GET, createHttpHeaders(), EntitledAccountsResponse.class);
            log.info("Have response back from customer-access-entitlement/entitledAccounts");
            log.debug("Have response back from customer-access-entitlement/entitledAccounts: {}", response);
            return response.getBody();
        } catch (RestClientResponseException rcre) {
            log.error("RestClientResponseException: Customer-access-entitlement/entitledAccounts service did not respond correctly: " + rcre.getResponseBodyAsString(), rcre);
            throw new GeneralException("CUSTOMER_ACCESS_ENTITLEMENT_EXC: " + rcre.getRawStatusCode(), "Customer-access-entitlement/entitledAccounts service did not respond correctly", rcre);
        } catch (Exception ex) {
            log.error("Customer-access-entitlement/entitledAccounts service did not respond correctly: " + ex.getMessage(), ex);
            throw new ConnectionException("CUSTOMER_ACCESS_ENTITLEMENT_EXC", "Error while calling customer-access-entitlement/entitledAccounts api", ex);
        }
    }

    private HttpEntity<HttpHeaders> createHttpHeaders() {
        final HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("x-ibm-client-id", clientId);
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON_VALUE);
        httpHeaders.add(HttpHeaders.ACCEPT, APPLICATION_JSON_VALUE);
        return new HttpEntity<>(httpHeaders);
    }

    private String createFinalUrl(String url, QueryParams queryParams) {
        return UriComponentsBuilder
                .fromUriString(url)
                .queryParam("uid", queryParams.getUid())
                .queryParam("operation", queryParams.getOperation())
                .build().toUriString();
    }
}
