package com.santanderuk.corinthian.services.commons.time;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AvailableDates {

    private String firstAvailableDate;
    private String secondAvailableDate;
    private String thirdAvailableDate;
    private String finalAvailableEndingDate;
}
