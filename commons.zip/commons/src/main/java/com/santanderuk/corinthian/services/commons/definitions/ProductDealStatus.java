package com.santanderuk.corinthian.services.commons.definitions;

public enum ProductDealStatus {

    ENDING_SOON,
    ENDING_TODAY,
    RECENTLY_SWITCHED,
    NONE,
    CAN_CHANGE,
    PRODUCT_ENDED_ACCOUNT_PAST_TERM,
    PENDING_PRODUCT_CHANGE

}
