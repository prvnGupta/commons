
package com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class IO32129 extends ModelBase {

    @JsonProperty("I_ACCOUNT_NO")
    private Integer iAccountNo;
    @JsonProperty("I_PMT_TYPE_IN")
    private String iPmtTypeIn;
    @JsonProperty("I_SIM_PMT_METH")
    private String iSimPmtMeth;
    @JsonProperty("I_SIMULATOR_ID")
    private int iSimulatorId;
    @JsonProperty("I_SIM_VAL_DATE")
    private String iSimValDate;
    @JsonProperty("I_IGN_BACS_NTCE")
    private String iIgnBacsNotice;
    @JsonProperty("I_AMOUNT")
    private BigDecimal iAmount;
    @JsonProperty("I_BANK_SORT_CODE_1")
    private int iBankSortCode1;
    @JsonProperty("I_BANK_SORT_CODE_2")
    private int iBankSortCode2;
    @JsonProperty("I_BANK_SORT_CODE_3")
    private int iBankSortCode3;
    @JsonProperty("I_BANK_ACCOUNT")
    private Integer iBankAccount;
    @JsonProperty("I_CHEQUE_NUMBER")
    private String iChequeNumber;
    @JsonProperty("I_CHAPS_NO_1")
    private String iChapsNo1;
    @JsonProperty("I_CHAPS_NO_2")
    private String iChapsNo2;
    @JsonProperty("I_CHAPS_NO_3")
    private String iChapsNo3;
    @JsonProperty("I_TRIG_CPLX_RUL")
    private String iTrigCplxRul;
    @JsonProperty("I_UPR")
    private String iUpr;
}
