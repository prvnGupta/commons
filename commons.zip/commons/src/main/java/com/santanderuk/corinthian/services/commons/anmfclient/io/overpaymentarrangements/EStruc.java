
package com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EStruc extends ModelBase {

    @JsonProperty("e_code")
    private String eCode;
    @JsonProperty("e_message")
    private String eMessage;
    @JsonProperty("e_progname")
    private String eProgname;

}
