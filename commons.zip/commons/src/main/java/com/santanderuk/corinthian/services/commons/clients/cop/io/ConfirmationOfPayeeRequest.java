package com.santanderuk.corinthian.services.commons.clients.cop.io;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConfirmationOfPayeeRequest extends ModelBase {
    @JsonProperty("AccountType")
    private String accountType;
    @JsonProperty("Identification")
    private String identification;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("SecondaryIdentification")
    private String secondaryIdentification;
    @JsonProperty("CustomerActivity")
    private String customerActivity;
    @JsonProperty("SecondaryReference")
    private String secondaryReference;
    @JsonProperty("ChannelType")
    private String channelType;
    @JsonProperty("CustomerNumber")
    private String customerNumber;
}
