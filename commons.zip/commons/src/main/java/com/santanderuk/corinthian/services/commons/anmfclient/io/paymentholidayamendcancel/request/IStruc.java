package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "i_mort_acc_no",
        "i_seq_number",
        "i_action",
        "i_new_period",
        "i_mobile",
        "i_email",
        "i_channel_code",
        "i_user_id"
})
public class IStruc extends ModelBase {

    private static final long serialVersionUID = 4112373347110568658L;

    @JsonProperty("i_mort_acc_no")
    private String iMortAccNo;
    @JsonProperty("i_seq_number")
    private int iSeqNumber;
    @JsonProperty("i_action")
    private String iAction;
    @JsonProperty("i_new_period")
    private String iNewPeriod;
    @JsonProperty("i_mobile")
    private String iMobile;
    @JsonProperty("i_email")
    private String iEmail;
    @JsonProperty("i_channel_code")
    private String iChannelCode;
    @JsonProperty("i_user_id")
    private String iUserId;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @JsonProperty("i_mort_acc_no")
    public String getiMortAccNo() {
        return iMortAccNo;
    }

    @JsonProperty("i_mort_acc_no")
    public void setIMortAccNo(String iMortAccNo) {
        this.iMortAccNo = iMortAccNo;
    }

    @JsonProperty("i_seq_number")
    public int getISeqNumber() {
        return iSeqNumber;
    }

    @JsonProperty("i_seq_number")
    public void setISeqNumber(int iSeqNumber) {
        this.iSeqNumber = iSeqNumber;
    }

    @JsonProperty("i_action")
    public String getIAction() {
        return iAction;
    }

    @JsonProperty("i_action")
    public void setIAction(String iAction) {
        this.iAction = iAction;
    }

    @JsonProperty("i_new_period")
    public String getINewPeriod() {
        return iNewPeriod;
    }

    @JsonProperty("i_new_period")
    public void setINewPeriod(String iNewPeriod) {
        this.iNewPeriod = iNewPeriod;
    }

    @JsonProperty("i_mobile")
    public String getIMobile() {
        return iMobile;
    }

    @JsonProperty("i_mobile")
    public void setIMobile(String iMobile) {
        this.iMobile = iMobile;
    }

    @JsonProperty("i_email")
    public String getIEmail() {
        return iEmail;
    }

    @JsonProperty("i_email")
    public void setIEmail(String iEmail) {
        this.iEmail = iEmail;
    }

    @JsonProperty("i_channel_code")
    public String getIChannelCode() {
        return iChannelCode;
    }

    @JsonProperty("i_channel_code")
    public void setIChannelCode(String iChannelCode) {
        this.iChannelCode = iChannelCode;
    }

    @JsonProperty("i_user_id")
    public String getIUserId() {
        return iUserId;
    }

    @JsonProperty("i_user_id")
    public void setIUserId(String iUserId) {
        this.iUserId = iUserId;
    }
}
