package com.santanderuk.corinthian.services.commons.clients.bksconnect;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.ContractsInMccRequest;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static com.santanderuk.corinthian.services.commons.exceptions.ConnectionException.Type.EXC_IOC_CORE_CALL;

@Component
@Slf4j
public class BksConnectClient {
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";
    private static final String CARRIAGE_RETURN = "[\r\n]";
    private static final String STR_EMPTY = "";

    private final ApiManagerConfig apiManagerConfig;
    private final RestTemplate restTemplate;
    private final BksConnectMapper bksConnectMapper;

    @Autowired
    public BksConnectClient(ApiManagerConfig apiManagerConfig, RestTemplate restTemplate, BksConnectMapper bksConnectMapper) {
        this.apiManagerConfig = apiManagerConfig;
        this.restTemplate = restTemplate;
        this.bksConnectMapper = bksConnectMapper;
    }

    public RetrieveMccResponse getMcc(String retrieveMccUrl, RetrieveMccControllerRequest retrieveMccControllerRequest) throws ConnectionException {
        ResponseEntity<RetrieveMccResponse> responseEntity;
        try {
            log.info("retrieveMcc - > Calling RetrieveMcc microservice");
            log.debug("Calling endpoint: {}", retrieveMccUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug("JSON Request: {}", retrieveMccControllerRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            final HttpEntity<RetrieveMccControllerRequest> httpEntity = getRetrieveMccHttpEntity(retrieveMccControllerRequest);
            responseEntity = restTemplate.postForEntity(
                    retrieveMccUrl,
                    httpEntity,
                    RetrieveMccResponse.class
            );
            log.debug("JSON Response -> {}", Objects.requireNonNull(responseEntity.getBody()).toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.info("retrieveMcc - > RetrieveMcc microservice: Response received");
        } catch (Exception e) {
            log.error("retrieveMcc - > Exception while connecting to  RetrieveMcc microservice", e);
            throw new ConnectionException(ConnectionException.Type.BKS_CONNECT, e);
        }
        checkResponseHttpStatus(responseEntity);
        return responseEntity.getBody();
    }

    public RetrieveMccResponse getMccFromLdapUid(String retrieveMccUrl, String ldapUid) throws ConnectionException {
        RetrieveMccControllerRequest retrieveMccRequest = bksConnectMapper.getRetrieveMccRequest(ldapUid);
        return getMcc(retrieveMccUrl, retrieveMccRequest);
    }

    private void checkResponseHttpStatus(final ResponseEntity<RetrieveMccResponse> responseEntity) throws ConnectionException {
        final HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus != HttpStatus.OK) {
            log.error("IOC retrieveMcc microservice response KO.  Response Status: {}", httpStatus);
            throw new ConnectionException(ConnectionException.Type.EXC_BUS_IOC);
        }
    }

    public ContractsInMccControllerResponse getCustomerAccount(String serviceUrl, ContractsInMccRequest contractsInMccRequest) throws ConnectionException {

        HttpEntity<ContractsInMccRequest> httpEntity = getContractInMccHttpEntity(contractsInMccRequest);

        ResponseEntity<ContractsInMccControllerResponse> responseEntity;
        try {
            log.info("ContractsInMcc -> Calling ContractsInMcc microservice");
            log.debug("Calling endpoint: {}", serviceUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug("ContractsInMcc Request: {}", contractsInMccRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            responseEntity = restTemplate.postForEntity(serviceUrl, httpEntity, ContractsInMccControllerResponse.class);
            log.info("ContractsInMcc -> ContractsInMcc response received ");
            log.debug("ContractsInMcc Response -> {}", Objects.requireNonNull(responseEntity.getBody()).toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        } catch (RestClientException ex) {
            log.error("ContractsInMcc -> Exception while connecting to ContractsInMcc microservice");
            throw new ConnectionException(EXC_IOC_CORE_CALL, ex);
        }
        return responseEntity.getBody();
    }


    private HttpEntity<RetrieveMccControllerRequest> getRetrieveMccHttpEntity(final RetrieveMccControllerRequest retrieveMccControllerRequest) {
        final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", "application/json");
        headers.add(X_IBM_CLIENT_ID, apiManagerConfig.getClientIdValue());
        return new HttpEntity<>(retrieveMccControllerRequest, headers);
    }

    private HttpEntity<ContractsInMccRequest> getContractInMccHttpEntity(final ContractsInMccRequest contractsInMccRequest) {
        final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", "application/json");
        headers.add(X_IBM_CLIENT_ID, apiManagerConfig.getClientIdValue());
        return new HttpEntity<>(contractsInMccRequest, headers);
    }
}
