package com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class IStruc extends ModelBase {
    @JsonProperty("i_mort_acc_no")
    private String iMortAccNo;
    @JsonProperty("i_action")
    private String iAction;
    @JsonProperty("i_auddis_date")
    private String iAuddisDate;
    @JsonProperty("i_bank_sortcode")
    private String iBankSortcode;
    @JsonProperty("i_bank_acc_no")
    private String iBankAccNo;
    @JsonProperty("i_bank_acc_name")
    private String iBankAccName;
    @JsonProperty("i_ddr_status")
    private String iDdrStatus;
    @JsonProperty("i_reason_change")
    private String iReasonChange;
    @JsonProperty("i_instruction_received")
    private String iInstructionReceived;
    @JsonProperty("i_user_id")
    private String iUserId;

}
