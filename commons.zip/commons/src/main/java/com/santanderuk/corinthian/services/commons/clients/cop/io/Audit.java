package com.santanderuk.corinthian.services.commons.clients.cop.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Audit extends ModelBase {

    private String externalBank;
    private String trackingID;
    private String schemeName;
    private String businessPersonalIndicator;
    private String accountNumber;
    private String sortCode;
    private String requestedName;
    private String secondaryReference;
    private String channelType;
    private String bankCode;
    private String statusCodeReturned;
    private String reasonCode;
    private String requestReceivedUTC;
    private String responseReturnedUTC;
    private String acctNamePassedBack;
    private String timeTakenMS;
    private Boolean isTimeout;
}
