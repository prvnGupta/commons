package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "i_struc"
})
public class Request extends ModelBase {

    private static final long serialVersionUID = -3831876332498023449L;

    @JsonProperty("i_struc")
    private IStruc iStruc;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @JsonProperty("i_struc")
    public IStruc getIStruc() {
        return iStruc;
    }

    @JsonProperty("i_struc")
    public void setIStruc(IStruc iStruc) {
        this.iStruc = iStruc;
    }

}
