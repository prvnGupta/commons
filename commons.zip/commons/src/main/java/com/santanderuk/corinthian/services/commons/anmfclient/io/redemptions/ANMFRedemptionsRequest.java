package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ANMFRedemptionsRequest extends ModelBase {

      private static final long serialVersionUID = -5188015406189283475L;
      @JsonProperty("accountNumber")
      private String accountNumber;
      @JsonProperty("redemptionDate")
      private String redemptionDate;
      @JsonProperty("requestedBy")
      private String requestedBy;
      @JsonProperty("solicitorCode")
      private String solicitorCode;
      @JsonProperty("callingApplication")
      private String callingApplication;
      @JsonProperty("channelType")
      private String channelType;
      @JsonProperty("userId")
      private String userId;
      @JsonProperty("statementEnq")
      private String statementEnq;
}
