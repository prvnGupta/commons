package com.santanderuk.corinthian.services.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;


@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
public class LocalAccountNumber extends ModelBase {

    private static final long serialVersionUID = -5611337440124732020L;

    @NotNull
    private String sortcode;

    @NotNull
    private String accountNumber;
}
