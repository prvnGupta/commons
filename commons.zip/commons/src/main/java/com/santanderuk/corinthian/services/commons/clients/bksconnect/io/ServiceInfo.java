package com.santanderuk.corinthian.services.commons.clients.bksconnect.io;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.sql.Timestamp;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "status",
        "code",
        "message",
        "timestamp"
})
@Getter
@Setter
public class ServiceInfo extends ModelBase implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    @JsonProperty("timestamp")
    public Timestamp timestamp;
    @JsonProperty("status")
    private String status;
    @JsonProperty("code")
    private String code;
    @JsonProperty("message")
    private String message;

    public ServiceInfo() {
    }

    public ServiceInfo(String status, String code, String message) {
        this.status = status;
        this.code = code;
        this.message = message;
        this.timestamp = new Timestamp(System.currentTimeMillis());
    }

    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("status", status)
                .append("code", code)
                .append("message", message)
                .append("timestamp", timestamp)
                .toString();
    }
}
