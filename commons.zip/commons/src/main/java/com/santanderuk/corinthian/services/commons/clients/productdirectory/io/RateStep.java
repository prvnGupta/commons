
package com.santanderuk.corinthian.services.commons.clients.productdirectory.io;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RateStep extends ModelBase {

    private Long stepNumber;
    private BigDecimal stepRate;
    private BigDecimal stepRateDifferential;
    private Term stepMaturityTerm;

}
