package com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.xml.datatype.XMLGregorianCalendar;

import static com.fasterxml.jackson.annotation.JsonInclude.Include;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ContractElement extends ModelBase {

    private XMLGregorianCalendar endDate;
    private String alias;
    private String cardPan;
    private Cesta outCesta;
    private ProductSubtype productSubtype;
    private ContractDetails contractDetails;
    private String intervinientInd;
    private String relationInd;
    private String statusIndicator;
    private Integer presOrder;
    private String interventionType;
    private String intervinientQuality;
    private Integer cardCaducity;
    private PcasConcept pcasConcept;
    private String subTypeName;
    private String interventionForm;
}
