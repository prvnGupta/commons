package com.santanderuk.corinthian.services.commons.anmfclient.io.simulations;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OLoanData extends ModelBase {

    @JsonProperty("o_loan_sch")
    private String oLoanSch;

    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;

    @JsonProperty("o_ln_erc")
    private BigDecimal oLnErc;

    @JsonProperty("o_ln_curr_mon_pay")
    private BigDecimal oLnCurrMonPay;

    @JsonProperty("o_ln_sim_mon_pay")
    private BigDecimal oLnSimMonPay;

    @JsonProperty("o_ln_curr_mat_dt")
    private String oLnCurrMatDt;

    @JsonProperty("o_ln_sim_mat_dt")
    private String oLnSimMatDt;

    @JsonProperty("o_ln_int_bef_sim")
    private BigDecimal oLnIntBefSim;

    @JsonProperty("o_ln_int_aft_sim")
    private BigDecimal oLnIntAftSim;

    @JsonProperty("o_fir_cappay_aft_sim")
    private BigDecimal oFirCappayAftSim;

    @JsonProperty("o_fir_int_aft_sim")
    private BigDecimal oFirIntAftSim;

    @JsonProperty("o_sec_cappay_aft_sim")
    private BigDecimal oSecCappayAftSim;

    @JsonProperty("o_sec_int_aft_sim")
    private BigDecimal oSecIntAftSim;

    @JsonProperty("o_erc_waiver")
    private String oErcWaiver;

    @JsonProperty("o_erc_waiver_rsn")
    private String oErcWaiverRsn;

    @JsonProperty("o_erc_waiver_desc")
    private String oErcWaiverDesc;

    @JsonProperty("o_mar_saving")
    private BigDecimal oMarSaving;

    @JsonProperty("o_term_saving")
    private BigDecimal oTermSaving;

    @JsonProperty("o_int_saving")
    private BigDecimal oIntSaving;

    @JsonProperty("o_est_final_pay")
    private BigDecimal oEstFinalPay;

    @JsonProperty("o_next_mon_pay")
    private BigDecimal oNextMonPay;

    @JsonProperty("o_second_mon_pay")
    private BigDecimal oSecondMonPay;

}
