package com.santanderuk.corinthian.services.commons.definitions;

public enum ProductTypes {
    FIXED,
    VARIABLE,
    STT,
    SVR,
    FOR,
    UNKNOWN,
    LTT,
    FLEXI
}
