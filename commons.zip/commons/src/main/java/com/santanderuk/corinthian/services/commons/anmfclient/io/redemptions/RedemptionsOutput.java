package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class RedemptionsOutput extends ModelBase {

    private static final long serialVersionUID = 6998505842746315626L;
    @JsonProperty("o_redemption_seq_no")
    private int redemptionsSeqNumber;
    @JsonProperty("o_elect_discharge")
    private String electDischarge;
    @JsonProperty("o_daily_amount")
    private BigDecimal dailyAmount;
    @JsonProperty("o_deed_hndlng_fee")
    private BigDecimal deedHandlingFee;
    @JsonProperty("o_rep_fee_paid")
    private String repFeePaid;
    @JsonProperty("o_redemp_amount")
    private BigDecimal redemptionAmount;
    @JsonProperty("o_red_prc_exist")
    private String redPrcExist;
    @JsonProperty("o_totalInterestAmount")
    private BigDecimal totalInterestAmount;
    @JsonProperty("o_totalCapitalBalance")
    private BigDecimal totalCapitalBalance;
    @JsonProperty("o_totalDailyInterestAmount")
    private BigDecimal totalDailyInterestAmount;
    @JsonProperty("o_cash_backcharge")
    private List<CashbackCharge> cashbackCharges;
    @JsonProperty("o_sundry")
    private Sundry sundry;
    @JsonProperty("o_saving")
    private Balance saving;
    @JsonProperty("o_overpayment")
    private Balance overpayment;
    @JsonProperty("o_avail_funds")
    private AvailableFunds availableFunds;
    @JsonProperty("o_loans")
    private List<Loans> loans;
}
