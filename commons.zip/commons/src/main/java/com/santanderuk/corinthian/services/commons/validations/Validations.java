package com.santanderuk.corinthian.services.commons.validations;

import org.springframework.stereotype.Component;

@Component
public class Validations {

    private static final int ACCOUNT_NUMBER_MAX_LENGTH = 9;
    private static final int ACCOUNT_NUMBER_MIN_VALUE = 1;
    private static final int APPLICATION_SEQUENCE_MAX_LENGTH = 2;
    private static final int APPLICATION_SEQUENCE_MIN_VALUE = 0;

    public Validations() {
        // Constructor
    }

    public boolean isAccountNumber(final int accountNumber) {
        return Integer.toString(accountNumber).length() <= ACCOUNT_NUMBER_MAX_LENGTH
                && accountNumber >= ACCOUNT_NUMBER_MIN_VALUE;
    }

    public boolean isLoanScheme(final String loanScheme) {
        return loanScheme != null && loanScheme.matches("^[a-zA-Z0-9]{2}$");
    }

    public boolean isApplicationSequenceNumber(int applicationSequenceNumber) {
        return Integer.toString(applicationSequenceNumber).length() <= APPLICATION_SEQUENCE_MAX_LENGTH
                && applicationSequenceNumber >= APPLICATION_SEQUENCE_MIN_VALUE;
    }
}
