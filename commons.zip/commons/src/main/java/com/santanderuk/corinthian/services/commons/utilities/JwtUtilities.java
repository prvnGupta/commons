package com.santanderuk.corinthian.services.commons.utilities;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.JsonParseException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;


/**
 * Created by C0229411 on 04/10/2017.
 **/
public class JwtUtilities {

    private static final Logger log = LoggerFactory.getLogger(JwtUtilities.class);
    private static final String COULD_NOT_RETRIEVE_CUSTOMER_FROM_JWT = "Could not retrieve customer from JWT token. Creating a dummy BdpCustomer with number 999999999";


    private JwtUtilities() {
    }

    public static BdpCustomer getBdpCustomerFromJWT(String jwtToken) {
        BdpCustomer bdpCustomer = new BdpCustomer("F", 999999999);

        log.info("extracting BDP customer from JWT token");
        try {
            String[] splitJwt = jwtToken.split("[.]");
            String jwtInfoDecoded = new String(Base64.getDecoder().decode(splitJwt[1]), StandardCharsets.UTF_8);
            JSONObject jsonPayload = new JSONObject(jwtInfoDecoded);
            String mis = (String) jsonPayload.get("mis");
            if (mis != null && mis.length() > 0) {
                int beginSquareBracket = mis.indexOf('[');
                if (beginSquareBracket != -1) {
                    int endSquareBracket = mis.lastIndexOf(']');
                    mis = mis.substring(0, beginSquareBracket) + mis.substring(endSquareBracket + 1);
                }
                String[] splitMis = mis.split("[:]");
                if (splitMis.length > 3) {
                    String bdpNumber = splitMis[2];
                    log.info("Customer found on JWT token");
                    log.debug("Customer found on JWT token {}", bdpNumber);
                    bdpCustomer = new BdpCustomer(Character.toString(bdpNumber.charAt(0)), Integer.parseInt(bdpNumber.substring(1)));
                } else {
                    log.error(COULD_NOT_RETRIEVE_CUSTOMER_FROM_JWT);
                }
            } else {
                log.error(COULD_NOT_RETRIEVE_CUSTOMER_FROM_JWT);
            }
        } catch (Exception e) {
            //TODO: This need to be removed to go to PRE OR PRO
//            log.error("Could not retrieve Customer from JWT token");
//            throw new GeneralException("Invalid JWT", "Could not retrieve Customer from JWT");
            log.error(COULD_NOT_RETRIEVE_CUSTOMER_FROM_JWT);
            bdpCustomer = new BdpCustomer("F", 999999999);
        }
        return bdpCustomer;
    }

    public static String getLdapUidFromJWT(String jwtToken) throws GeneralException {
        String ldapUid;
        try {
            String[] splitJwt = jwtToken.split("[.]");
            String jwtInfoDecoded = new String(Base64.getDecoder().decode(splitJwt[1]), StandardCharsets.UTF_8);
            JSONObject jsonPayload = new JSONObject(jwtInfoDecoded);
            ldapUid = (String) jsonPayload.get("sub");

        } catch (JSONException e) {
            log.error("Could not retrieve Ldap Uid from JWT token", e);
            throw new JsonParseException("EXC_TECH_INVALID_JWT", "Could not retrieve Ldap Uid from JWT token", e);
        }

        return ldapUid;
    }
}
