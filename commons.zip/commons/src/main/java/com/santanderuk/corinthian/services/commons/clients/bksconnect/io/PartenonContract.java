package com.santanderuk.corinthian.services.commons.clients.bksconnect.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "centre",
        "productTypeCode",
        "contractNumber"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PartenonContract implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("centre")
    private Centre centre;
    @JsonProperty("productTypeCode")
    private String productTypeCode;
    @JsonProperty("contractNumber")
    private String contractNumber;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("centre", centre)
                .append("productTypeCode", productTypeCode)
                .append("contractNumber", contractNumber)
                .toString();
    }
}
