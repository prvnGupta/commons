package com.santanderuk.corinthian.services.commons.anmfclient.io;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ErStruc extends ModelBase {

    private static final long serialVersionUID = 791400282196340636L;

    @JsonProperty("er_code")
    private String erCode;
    @JsonProperty("er_message")
    private String erMessage;
    @JsonProperty("er_progname")
    private String erProgname;

}
