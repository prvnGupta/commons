package com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan;

import com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io.LoanPaymentPlanChangeRequest;
import com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io.LoanPaymentPlanChangeResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static com.santanderuk.corinthian.services.commons.exceptions.ConnectionException.Type.LOAN_PAYMENT_PLAN_CHANGE_SERVICE_CONNECTION_ERROR;
import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Component
@Getter
@Setter
public class LoanPaymentPlanChangeClient {

    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public LoanPaymentPlanChangeClient( RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public LoanPaymentPlanChangeResponse fetchLoanPaymentPlan(String loanPaymentChangeUrl, LoanPaymentPlanChangeRequest loanPaymentPlanChangeRequest) throws ConnectionException {
        MultiValueMap<String, String> headers = generateHttpHeaders();
        HttpEntity<LoanPaymentPlanChangeRequest> httpEntity = new HttpEntity<>(loanPaymentPlanChangeRequest, headers);
        ResponseEntity<LoanPaymentPlanChangeResponse> responseEntity;
        try {
            log.info("LoanPaymentPlanChangeClient - > Calling LoanPaymentPlanChange microservice: {}", loanPaymentChangeUrl);
            log.debug("LoanPaymentPlanChangeClient - > Sending object: {}", loanPaymentPlanChangeRequest);

            responseEntity = restTemplate.postForEntity(loanPaymentChangeUrl, httpEntity, LoanPaymentPlanChangeResponse.class);

            log.info("LoanPaymentPlanChangeClient - > Call to LoanPaymentPlanChange microservice was successful");
        } catch (RestClientException e) {
                log.error("LoanPaymentPlanChangeClient -> error while connecting to LoanPaymentPlanChange microservice");
                throw new ConnectionException(LOAN_PAYMENT_PLAN_CHANGE_SERVICE_CONNECTION_ERROR, e);
            }
        log.info("LoanPaymentPlanChangeResponse - > Response from microservice: {}", responseEntity.getBody());
        return responseEntity.getBody();
    }

    private HttpHeaders generateHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }
}
