package com.santanderuk.corinthian.services.commons.exceptions;


public class AnmfCoreException extends GeneralException {

    public AnmfCoreException(String code, String message) {
        super(code, message);
    }

    public AnmfCoreException(String code, String message, Exception e) {
        super(code, message, e);
    }

}
