
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OPersonnalDrawdownGrp extends ModelBase {

    @JsonProperty("o_personnal_drawdown_appl")
    private String oPersonnalDrawdownAppl;
    @JsonProperty("o_personnal_drawdown_amount")
    private BigDecimal oPersonnalDrawdownAmount;

}
