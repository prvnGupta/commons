
package com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OPendingAud extends ModelBase {

    @JsonProperty("o_auddis_date")
    private String oAuddisDate;
    @JsonProperty("o_user_id")
    private String oUserId;
    @JsonProperty("o_instruction_by")
    private String oInstructionBy;
    @JsonProperty("o_instruction_by_desc")
    private String oInstructionByDesc;
    @JsonProperty("o_bankp_name")
    private String oBankpName;
    @JsonProperty("o_new_sortcode")
    private String oNewSortcode;
    @JsonProperty("o_new_acc_number")
    private String oNewAccNumber;
    @JsonProperty("o_new_acc_name")
    private String oNewAccName;
    @JsonProperty("o_bankp_address")
    private String oBankpAddress;
    @JsonProperty("o_bankp_address_2")
    private String oBankpAddress2;
    @JsonProperty("o_bankp_address_3")
    private String oBankpAddress3;
    @JsonProperty("o_bankp_address_4")
    private String oBankpAddress4;
    @JsonProperty("o_bankp_postcode")
    private String oBankpPostcode;
    @JsonProperty("o_new_ddr_status")
    private String oNewDdrStatus;
    @JsonProperty("o_new_ddr_status_desc")
    private String oNewDdrStatusDesc;
    @JsonProperty("o_new_action")
    private String oNewAction;
    @JsonProperty("o_new_action_desc")
    private String oNewActionDesc;
    @JsonProperty("o_new_mandate")
    private String oNewMandate;
    @JsonProperty("o_reason_change")
    private String oReasonChange;
    @JsonProperty("o_reason_change_desc")
    private String oReasonChangeDesc;
}
