package com.santanderuk.corinthian.services.commons.anmfclient.io.warning;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OWarningProcessArrTab extends ModelBase {

    @JsonProperty("o_wrn_msg_arr")
    private List<OWrnMsgArr> OWrnMsgArr;
}
