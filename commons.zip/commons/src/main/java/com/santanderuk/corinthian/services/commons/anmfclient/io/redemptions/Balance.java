package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Balance extends ModelBase {

    private static final long serialVersionUID = -7991321475846115108L;
    @JsonProperty("o_valid")
    private String valid;
    @JsonProperty("o_capital_balance")
    private BigDecimal capitalBalance;
    @JsonProperty("o_unclear_amount")
    private BigDecimal unclearAmount;
}
