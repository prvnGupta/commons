package com.santanderuk.corinthian.services.commons.clients.anmfregion;

import com.santanderuk.corinthian.services.commons.clients.anmfregion.io.AnmfRegionResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpMethod.GET;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

public class AnmfRegionClient {

    private final RestTemplate restTemplate;

    public static final MaintenanceException.Type MAINTENANCE_REGION_X = MaintenanceException.Type.MAINTENANCE_REGION_X;
    public static final ConnectionException.Type ANMF_REGION_CONNECTION_ERROR = ConnectionException.Type.ANMF_REGION_CONNECTION_ERROR;

    @Value("${anmf-region.url}")
    private String anmfRegionUrl;
    @Value("${apimanager.client-id-value}")
    private String clientId;
    @Value("${apimanager.client-secret-value}")
    private String clientSecret;

    public AnmfRegionClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public AnmfRegion fetchCurrentRegion() throws MaintenanceException, ConnectionException {

        AnmfRegionResponse anmfRegionResponse = callAnmfRegionService(anmfRegionUrl);

        if (isRegionA(anmfRegionResponse.getRegion())) {
            return AnmfRegion.A;
        } else if (isRegionW(anmfRegionResponse.getRegion())) {
            return AnmfRegion.W;
        } else {
            throw new MaintenanceException(MAINTENANCE_REGION_X);
        }
    }

    private boolean isRegionW(String anmfRegion) {
        return anmfRegion.equalsIgnoreCase("w");
    }

    private boolean isRegionA(String anmfRegion) {
        return anmfRegion.equalsIgnoreCase("a");
    }

    private AnmfRegionResponse callAnmfRegionService(String url) throws ConnectionException {
        HttpEntity<HttpHeaders> entity = createHttpEntity();
        try {
            ResponseEntity<AnmfRegionResponse> responseEntity = restTemplate.exchange(url, GET, entity, AnmfRegionResponse.class);
            return responseEntity.getBody();
        } catch (Exception e) {
            throw new ConnectionException(ANMF_REGION_CONNECTION_ERROR, e);
        }
    }

    private HttpEntity<HttpHeaders> createHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", clientId);
        headers.add("x-ibm-client-secret", clientSecret);
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        return new HttpEntity<>(headers);
    }
}
