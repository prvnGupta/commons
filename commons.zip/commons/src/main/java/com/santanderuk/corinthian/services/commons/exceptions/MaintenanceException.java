package com.santanderuk.corinthian.services.commons.exceptions;


public class MaintenanceException extends GeneralException {

    public MaintenanceException(final Type type) {
        super(type.getCode(), type.getMessage());
    }

    public MaintenanceException(final Type type, final Exception exception) {
        super(type.getCode(), type.getMessage(), exception);
    }

    public enum Type {
        MAINTENANCE_REGION_X("MAINTENANCE_REGION_X", "Maintenance region X");

        private String code;
        private String message;

        Type(String code, String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

    }
}
