
package com.santanderuk.corinthian.services.commons.clients.productdirectory.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Erc extends ModelBase {

    private String applicable;

}
