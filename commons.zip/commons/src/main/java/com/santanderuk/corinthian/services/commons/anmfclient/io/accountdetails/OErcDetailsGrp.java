package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class OErcDetailsGrp extends ModelBase {

    @JsonProperty("o_erc_appl_flag")
    private String oErcApplFlag;
    @JsonProperty("o_rdm_stm_erc")
    private BigDecimal oRdmStmErc;
    @JsonProperty("o_erc_prod_type")
    private String oErcProdType;
    @JsonProperty("o_erc_current_step_seq")
    private int oErcCurrentStepSeq;
    @JsonProperty("o_erc_final_step_seq")
    private int oErcFinalStepSeq;
    @JsonProperty("o_erc_step_details_tab")
    private OErcStepDetailsTab oErcStepDetailsTab;
    @JsonProperty("o_erc_allow_perc")
    private String oErcAllowPerc;
    @JsonProperty("o_prod_erc")
    private OProdErc oProdErc;
    @JsonProperty("o_loan_erc")
    private OLoanErc oLoanErc;

}
