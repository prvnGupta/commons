package com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_ph_term_max_mths",
        "o_ph_term_tot_gtd_mths",
        "o_ph_term_rem_elg_mths",
        "o_ph_list",
        "e_struc"
})
@Getter
@Setter
@NoArgsConstructor
public class OutputStruc extends ModelBase {

    private static final long serialVersionUID = -5062451311403304931L;

    @JsonProperty("o_ph_term_max_mths")
    private int oPhTermMaxMths;
    @JsonProperty("o_ph_term_tot_gtd_mths")
    private int oPhTermTotGtdMths;
    @JsonProperty("o_ph_term_ext_elg_mths")
    private int oPhTermExtElgMths;
    @JsonProperty("o_ph_sim_strt_dt_set")
    private String oPhSimStrtDtSet;
    @JsonProperty("o_ph_sim_nxpy_dt_can")
    private String oPhSimNxpyDtCan;
    @JsonProperty("o_ph_ntce_prd")
    private String oPhNtcePrd;
    @JsonProperty("o_ph_list")
    private List<OPhList> oPhList = null;
    @JsonProperty("e_struc")
    private EStruc eStruc;
}
