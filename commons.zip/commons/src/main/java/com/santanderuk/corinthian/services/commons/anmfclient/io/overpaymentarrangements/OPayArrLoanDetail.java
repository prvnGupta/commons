
package com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OPayArrLoanDetail extends ModelBase {

    @JsonProperty("o_payarr_loan_sch")
    private String oPayArrLoanSch;
    @JsonProperty("o_payarr_appl_seq_no")
    private int oPayArrApplSeqNo;
    @JsonProperty("o_payarr_loan_order")
    private int oPayArrLoanOrder;
    @JsonProperty("o_payarr_stop_erc")
    private String oPayArrStopErc;
    @JsonProperty("o_payarr_impact")
    private String oPayArrImpact;
    @JsonProperty("o_payarr_impact_des")
    private String oPayArrImpactDes;

}
