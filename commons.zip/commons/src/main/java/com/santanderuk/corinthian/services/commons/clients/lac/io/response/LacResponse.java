package com.santanderuk.corinthian.services.commons.clients.lac.io.response;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class LacResponse extends ModelBase {

    private String contractInputId;
    private String inputContractIdentifierType;
    private List<OutputList> outputList;
    private String _first;
    private String _prev;
    private String _next;
    private String _last;

}
