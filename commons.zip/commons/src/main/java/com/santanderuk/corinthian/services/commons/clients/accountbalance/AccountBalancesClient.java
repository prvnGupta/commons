package com.santanderuk.corinthian.services.commons.clients.accountbalance;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

import static com.santanderuk.corinthian.services.commons.exceptions.ConnectionException.Type.ACCOUNT_BALANCES_UNAVAILABLE;
import static com.santanderuk.corinthian.services.commons.exceptions.ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT;

@Slf4j
@Component
public class AccountBalancesClient {

    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    public AccountBalancesClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public AccountBalancesResponse fetchBalances(String baseUrl, List<String> partenonContractIds) throws ConnectionException, ValidationsException {
        HttpEntity<Void> httpEntity = generateHttpEntity();
        String uri = generateURI(baseUrl, partenonContractIds);
        try {
            log.debug("Calling endpoint: {}", uri);
            ResponseEntity<AccountBalancesResponse> serviceResponse = restTemplate.exchange(uri, HttpMethod.GET, httpEntity, AccountBalancesResponse.class);
            log.debug("Response from service: {}", serviceResponse);
            return serviceResponse.getBody();
        } catch (RestClientException e) {
            log.error("Exception caught when calling account balances API");
            throw new ConnectionException(ACCOUNT_BALANCES_UNAVAILABLE, e);
        }
    }

    private HttpEntity<Void> generateHttpEntity() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("Content-Type", "application/json");
        return new HttpEntity<>(headers);
    }

    private String generateURI(String baseUrl, List<String> partenonContractIds) throws ValidationsException {
        if (partenonContractIds.size() > 0) {
            String commaSeparatedIds = partenonContractIds.toString()
                    .replace("[", "")
                    .replace("]", "")
                    .replaceAll(" ", "");
            return UriComponentsBuilder
                    .fromUriString(baseUrl)
                    .queryParam("partenoncontractid", commaSeparatedIds)
                    .build().toUriString();
        } else {
            throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT);
        }
    }
}
