
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OAvailableFundsGrp extends ModelBase {

    @JsonProperty("o_available_funds_appl")
    private String oAvailableFundsAppl;
    @JsonProperty("o_available_funds")
    private BigDecimal oAvailableFunds;

}
