
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OPendingProdSwitchDetails extends ModelBase {

    @JsonProperty("o_product_switch_date")
    private String oProductSwitchDate;
    @JsonProperty("o_new_prod_code")
    private String oNewProdCode;
    @JsonProperty("o_new_product_desc")
    private String oNewProductDesc;

}
