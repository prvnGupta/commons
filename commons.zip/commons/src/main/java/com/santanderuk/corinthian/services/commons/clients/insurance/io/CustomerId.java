package com.santanderuk.corinthian.services.commons.clients.insurance.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class CustomerId extends ModelBase {
    private static final long serialVersionUID = 723981824387912244L;
    private String customerType;
    private String customerNumber;
}
