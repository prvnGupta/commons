package com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.*;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonInclude(NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class LoanPaymentPlanChangeResponse extends ModelBase {
    @JsonProperty("DirectDebitServiceResponse_upd")
    private DirectDebitServiceResponseUpd directDebitServiceResponseUpd;
}
