package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RegularOverpaymentOutput extends ModelBase {

    private static final long serialVersionUID = 5740906519273078269L;

    @JsonProperty("o_ovp_inst_seq")
    private Integer oOvpInstSeq;
    @JsonProperty("o_ovp_inst_type")
    private String oOvpInstType;
    @JsonProperty("o_ovp_inst_type_desc")
    private String oOvpInstTypeDesc;
    @JsonProperty("o_ovp_inst_status")
    private String oOvpInstStatus;
    @JsonProperty("o_ovp_inst_status_desc")
    private String oOvpInstStatusDesc;
    @JsonProperty("o_ovp_inst_start_date")
    private String oOvpInstStartDate;
    @JsonProperty("o_ovp_inst_end_date")
    private String oOvpInstEndDate;
    @JsonProperty("o_ovp_inst_no_end_date")
    private String oOvpInstNoEndDate;
    @JsonProperty("o_ovp_inst_mon_pay")
    private BigDecimal oOvpInstMonPay;
    @JsonProperty("o_ovp_inst_ovp_pay_grp")
    private OOvpInstOvpPayGrp oOvpInstOvpPayGrp;
    @JsonProperty("o_ovp_inst_impact")
    private String oOvpInstImpact;
    @JsonProperty("o_ovp_inst_impact_desc")
    private String oOvpInstImpactDesc;
    @JsonProperty("o_ovp_inst_num_pays")
    private Integer oOvpInstNumPays;
    @JsonProperty("o_ovp_inst_to_use")
    private String oOvpInstToUse;
    @JsonProperty("o_ovp_inst_to_use_desc")
    private String oOvpInstToUseDesc;
    @JsonProperty("o_ovp_inst_cancel_reason")
    private String oOvpInstCancelReason;
    @JsonProperty("o_ovp_inst_cancel_reason_desc")
    private String oOvpInstCancelReasonDesc;
    @JsonProperty("o_channel_type")
    private String oChannelType;
    @JsonProperty("o_channel_type_desc")
    private String oChannelTypeDesc;
    @JsonProperty("o_loan_dtls")
    private List<OLoanData> oLoanDtls = Collections.emptyList();
    @JsonProperty("o_message")
    private String oMessage;
    @JsonProperty("o_warning")
    private String oWarning;
    @JsonProperty("e_struc")
    private EStruc eStruc;

}
