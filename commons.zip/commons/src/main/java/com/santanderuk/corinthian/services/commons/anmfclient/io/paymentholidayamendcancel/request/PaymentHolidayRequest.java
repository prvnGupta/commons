package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "request"
})
@Getter
@Setter
public class PaymentHolidayRequest extends ModelBase {

    private static final long serialVersionUID = -1334966888961530700L;

    @JsonProperty("request")
    private Request request;

    @JsonProperty("request")
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @JsonProperty("request")
    public Request getRequest() {
        return request;
    }

    public void setRequest(Request request) {
        this.request = request;
    }
}
