package com.santanderuk.corinthian.services.commons.clients.flexi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class DataOutTableFlexiAccount extends ModelBase {

    @JsonProperty("pay_date")
    private String payDate;
    @JsonProperty("normal_payment")
    private BigDecimal normalPayment;
    @JsonProperty("chosen_payment")
    private BigDecimal chosenPayment;
    @JsonProperty("proj_mtg_due")
    private BigDecimal projMtgDue;
    @JsonProperty("proj_avl_due")
    private BigDecimal projAvlDue;
    @JsonProperty("charge_amt")
    private BigDecimal chargeAmt;

}
