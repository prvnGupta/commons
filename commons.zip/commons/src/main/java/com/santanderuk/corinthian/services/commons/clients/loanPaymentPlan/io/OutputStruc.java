package com.santanderuk.corinthian.services.commons.clients.loanPaymentPlan.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.*;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonInclude(NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OutputStruc extends ModelBase {
    @JsonProperty("o_pending_aud_tab")
    private OPendingAudTab oPendingAudTab;

    @JsonProperty("e_struc")
    private EStruc eStruc;
}
