package com.santanderuk.corinthian.services.commons.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"customerType", "customerNumber"})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BdpCustomer extends ModelBase {

    private static final long serialVersionUID = -7837527442685297048L;

    private String customerType;
    private int customerNumber;

}
