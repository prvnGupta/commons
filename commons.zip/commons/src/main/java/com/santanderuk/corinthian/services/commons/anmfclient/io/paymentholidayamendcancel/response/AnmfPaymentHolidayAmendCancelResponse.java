package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@Getter
@Setter
@NoArgsConstructor
public class AnmfPaymentHolidayAmendCancelResponse extends ModelBase {

    private static final long serialVersionUID = -3935688321981633153L;

    @JsonProperty("PaymentHolidayResponse")
    private PaymentHolidayResponse paymentHolidayResponse;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }


}
