package com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OPayArrOvpInst extends ModelBase {

    private static final long serialVersionUID = -5313200281791086027L;

    @JsonProperty("o_payarr_occurrence")
    private String oPayArrOccurrence;
    @JsonProperty("o_payarr_transaction")
    private String oPayArrTransaction;
    @JsonProperty("o_payarr_amount_type")
    private String oPayArrAmountType;
    @JsonProperty("o_payarr_frequency")
    private String oPayArrFrequency;
    @JsonProperty("o_payarr_seq")
    private int oPayArrSeq;
    @JsonProperty("o_payarr_type")
    private String oPayArrType;
    @JsonProperty("o_payarr_type_desc")
    private String oPayArrTypeDesc;
    @JsonProperty("o_payarr_to_use")
    private String oPayArrToUse;
    @JsonProperty("o_payarr_to_use_desc")
    private String oPayArrToUseDesc;
    @JsonProperty("o_payarr_source")
    private String oPayArrSource;
    @JsonProperty("o_payarr_source_acc_no")
    private String oPayArrSourceAccNo;
    @JsonProperty("o_payarr_dest_desc")
    private String oPayArrDestDesc;
    @JsonProperty("o_payarr_status")
    private String oPayArrStatus;
    @JsonProperty("o_payarr_status_desc")
    private String oPayArrStatusDesc;
    @JsonProperty("o_payarr_req_by")
    private String oPayArrReqBy;
    @JsonProperty("o_payarr_req_bdp")
    private String oPayArrReqBDP;
    @JsonProperty("o_payarr_start_date")
    private String oPayArrStartDate;
    @JsonProperty("o_payarr_end_date")
    private String oPayArrEndDate;
    @JsonProperty("o_payarr_no_end_date")
    private String oPayArrNoEndDate;
    @JsonProperty("o_payarr_months_req")
    private String oPayArrMonthsReq;
    @JsonProperty("o_payarr_months_left")
    private String oPayArrMonthsLeft;
    @JsonProperty("o_payarr_mon_pay")
    private double oPayArrMonPay;
    @JsonProperty("o_payarr_amount_diff")
    private double oPayArrAmountDiff;
    @JsonProperty("o_payarr_amount_this_month_appl_grp")
    private OPayArrAmountThisMonthApplnGrp oPayArrAmountThisMonthApplnGrp;
    @JsonProperty("o_payarr_amount_total")
    private double oPayArrAmountTotal;
    @JsonProperty("o_payarr_trxn_progress")
    private String oPayArrTrxnProgress;
    @JsonProperty("o_payarr_impact")
    private String oPayArrImpact;
    @JsonProperty("o_payarr_impact_desc")
    private String oPayArrImpactDesc;
    @JsonProperty("o_payarr_channel")
    private String oPayArrChannel;
    @JsonProperty("o_payarr_channel_desc")
    private String oPayArrChannelDesc;
    @JsonProperty("o_payarr_cust_ucr")
    private String oPayArrCustUcr;
    @JsonProperty("o_payarr_suspend_payment")
    private String oPayArrSuspendPayment;
    @JsonProperty("o_payarr_loan_details")
    private List<OPayArrLoanDetail> oPayArrLoanDetails;
}
