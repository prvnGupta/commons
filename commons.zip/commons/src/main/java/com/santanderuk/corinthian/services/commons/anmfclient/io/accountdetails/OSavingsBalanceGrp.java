
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OSavingsBalanceGrp extends ModelBase {

    @JsonProperty("o_savings_balance_appl")
    private String oSavingsBalanceAppl;
    @JsonProperty("o_savings_balance")
    private BigDecimal oSavingsBalance;

}
