package com.santanderuk.corinthian.services.commons.serviceinfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
public class ServiceInfo extends ModelBase {

    private static final long serialVersionUID = -7216186144835750168L;

    @JsonProperty("status")
    private String status;

    @JsonProperty("code")
    private String code;

    @JsonProperty("message")
    private String message;

    @JsonProperty("timestamp")
    private long timestamp;

    public ServiceInfo() {
        this.timestamp = System.currentTimeMillis();
    }

    public ServiceInfo(String status, String code, String message) {
        this.status = status;
        this.code = code;
        this.message = message;
        this.timestamp = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("status", status)
                .append("code", code)
                .append("message", message)
                .toString();
    }
}
