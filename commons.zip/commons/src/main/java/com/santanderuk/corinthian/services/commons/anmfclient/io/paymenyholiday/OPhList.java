package com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_ph_seq",
        "o_ph_status",
        "o_ph_status_desc",
        "o_ph_status_date",
        "o_ph_event",
        "o_ph_event_desc",
        "o_ph_event_date",
        "o_ph_req_date",
        "o_ph_app_date",
        "o_ph_eff_date",
        "o_ph_end_date",
        "o_ph_term_req_mths",
        "o_ph_term_adj_mths",
        "o_ph_term_rem_mths",
        "o_ph_term_used_mths",
        "o_ph_source_code",
        "o_ph_source",
        "o_ph_mobile",
        "o_ph_email",
        "o_ph_nx_paydt_nend",
        "o_ph_nx_paydt_can"
})
@Getter
@Setter
@NoArgsConstructor
public class OPhList extends ModelBase {
    private static final long serialVersionUID = -3261352561879649873L;

    @JsonProperty("o_ph_seq")
    private int oPhSeq;
    @JsonProperty("o_ph_status")
    private String oPhStatus;
    @JsonProperty("o_ph_status_desc")
    private String oPhStatusDesc;
    @JsonProperty("o_ph_status_date")
    private String oPhStatusDate;
    @JsonProperty("o_ph_event")
    private String oPhEvent;
    @JsonProperty("o_ph_event_desc")
    private String oPhEventDesc;
    @JsonProperty("o_ph_event_date")
    private String oPhEventDate;
    @JsonProperty("o_ph_req_date")
    private String oPhReqDate;
    @JsonProperty("o_ph_app_date")
    private String oPhAppDate;
    @JsonProperty("o_ph_eff_date")
    private String oPhEffDate;
    @JsonProperty("o_ph_end_date")
    private String oPhEndDate;
    @JsonProperty("o_ph_term_req_mths")
    private int oPhTermReqMths;
    @JsonProperty("o_ph_term_adj_mths")
    private int oPhTermAdjMths;
    @JsonProperty("o_ph_term_rem_mths")
    private int oPhTermRemMths;
    @JsonProperty("o_ph_term_used_mths")
    private int oPhTermUsedMths;
    @JsonProperty("o_ph_source_code")
    private String oPhSourceCode;
    @JsonProperty("o_ph_source")
    private String oPhSource;
    @JsonProperty("o_ph_mobile")
    private String oPhMobile;
    @JsonProperty("o_ph_email")
    private String oPhEmail;
    @JsonProperty("o_ph_nx_paydt_nend")
    private String oPhNxPaydtNend;
}
