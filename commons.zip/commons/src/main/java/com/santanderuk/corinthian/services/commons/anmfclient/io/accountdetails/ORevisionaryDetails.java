
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ORevisionaryDetails extends ModelBase {

    @JsonProperty("o_revi_prod_desc")
    private String oReviProdDesc;
    @JsonProperty("o_revi_start_date")
    private String oReviStartDate;
    @JsonProperty("o_revi_interest_rate")
    private BigDecimal oReviInterestRate;
    @JsonProperty("o_revi_base_rate")
    private BigDecimal oReviBaseRate;
    @JsonProperty("o_revi_base_diff")
    private BigDecimal oReviBaseDiff;

}
