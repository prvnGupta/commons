package com.santanderuk.corinthian.services.commons.clients.cop.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VerificationReportResponse extends ModelBase {

    @JsonProperty("Data")
    private Data data;
    @JsonProperty("Links")
    private Links links;
    @JsonProperty("Meta")
    private Meta meta;
    @JsonProperty("Audit")
    private Audit audit;
}
