package com.santanderuk.corinthian.services.commons.exceptions;


public class ValidationsException extends GeneralException {

    public ValidationsException(final Type type) {
        super(type.getCode(), type.getMessage());
    }

    public ValidationsException(final Type type, final Exception exception) {
        super(type.getCode(), type.getMessage(), exception);
    }

    public ValidationsException(String code, String description) {
        super(code, description);
    }

    public enum Type {
        // Format
        EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT("EXC_FORMAT_VALIDATION_NOT_VALID_ACCOUNT", "The input account format is not valid"),
        EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", "The loan selected is not valid"),
        EXC_FUNCTIONAL_VALIDATION_ENDING_DATE_NOT_VALID("EXC_FUNCTIONAL_VALIDATION_ENDING_DATE_NOT_VALID", "The selected ending date is after the final available date"),
        EXC_FUNCTIONAL_VALIDATION_STARTING_DATE_NOT_VALID("EXC_FUNCTIONAL_VALIDATION_STARTING_DATE_NOT_VALID", "The starting date is not one of the available dates"),
        EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS", "The amount requested is more than the total balance minus 3 monthly payments"),
        EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE", "The amount requested is more than the ERC Allowance"),
        EXC_FUNCTIONAL_VALIDATION_AMOUNT_LESS_THAN_HIGHEST_OF_NEXT_3_PAYMENTS("EXC_FUNCTIONAL_VALIDATION_AMOUNT_LESS_THAN_HIGHEST_OF_NEXT_3_PAYMENTS", "The amount requested is less than the highest of next 3 payments"),
        EXC_FUNCTIONAL_VALIDATION_PRODUCT_CODE_NOT_VALID("EXC_FUNCTIONAL_VALIDATION_PRODUCT_CODE_NOT_VALID", "The product code is not available for the customer"),
        EXC_FUNCTIONAL_VALIDATION_ACCOUNT_UNAUTHORISED("EXC_FUNCTIONAL_VALIDATION_ACCOUNT_UNAUTHORISED", "The account is not allowed to access this resource"),
        EXC_FORMAT_VALIDATION_EMAIL_NOT_VALID("EXC_FORMAT_VALIDATION_EMAIL_NOT_VALID", "The email address is not valid"),
        EXC_FORMAT_VALIDATION_MOBILE_NOT_VALID("EXC_FORMAT_VALIDATION_MOBILE_NOT_VALID", "The mobile number is not valid"),
        BAD_REQUEST("BAD REQUEST", "Invalid Request"),
        EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT("EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT", "The list of accounts to retrieve balances for is empty"),
        EXC_ACCOUNT_NOT_MATCHING("EXC_ACCOUNT_NOT_MATCHING", "The account attempting to use does not belong to customer"),
        EXC_ACCOUNT_INSUFFICIENT_BALANCE("EXC_ACCOUNT_INSUFFICIENT_BALANCE", "The account selected does not have enough balance to make payment"),
        EXC_ACCOUNT_BALANCES_NOT_FOUND("EXC_ACCOUNT_BALANCES_NOT_FOUND", "No balances found for selected account");
        private String code;
        private String message;

        Type(final String code, final String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

    }
}
