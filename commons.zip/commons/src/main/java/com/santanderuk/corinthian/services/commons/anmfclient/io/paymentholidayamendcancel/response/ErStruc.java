package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
@NoArgsConstructor
public class ErStruc extends ModelBase {

    private static final long serialVersionUID = -4811378803241486970L;

    @JsonProperty("er_progname")
    private String erProgname;

    @JsonProperty("er_code")
    private String erCode;

    @JsonProperty("er_message")
    private String erMessage;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}
