package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigInteger;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OLinkedAccount extends ModelBase {
    private final static long serialVersionUID = 3524486598439940233L;

    @JsonProperty("o_leg_sys_ac_no")
    private BigInteger oLegSysAcNo;
    @JsonProperty("o_link_type")
    private String oLinkType;
    @JsonProperty("o_link_status")
    private String oLinkStatus;

}
