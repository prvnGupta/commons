package com.santanderuk.corinthian.services.commons.exceptions;


public class ConnectionException extends GeneralException {

    public ConnectionException(final Type type) {
        super(type.getCode(), type.getMessage());
    }

    public ConnectionException(final Type type, final Exception exception) {
        super(type.getCode(), type.getMessage(), exception);
    }

    public ConnectionException(String code, String msg, final Exception exception) {
        super(code, msg, exception);
    }

    public enum Type {
        // ANMF
        ANMF_UNAVAILABLE("ANMF_UNAVAILABLE", "ANMF did not respond correctly"),
        ANMF_RESPONSE_BAD_FORMAT("ANMF_RESPONSE_BAD_FORMAT", "Failed to convert response to required object"),

        // BKS
        BKS_CONNECT("BKS_CONNECT", "An error occurred while calling core bks connect"),
        EXC_BUS_IOC("EXC_BUS_IOC", "Failed to convert response to required object"),

        // HEARTBEAT
        HEARTBEAT_CONNECTION_ERROR("HEARTBEAT_CONNECTION_ERROR", "An error occurred when trying to connect with heartbeat"),
        ANMF_REGION_CONNECTION_ERROR("ANMF_REGION_CONNECTION_ERROR", "An error occurred when trying to connect with anmf region api"),

        // PRODUCT CATALOG
        PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR("PRODUCT_CATALOG_COMPLETION_DATE_CORE_ERROR", "Exception while calling Catalog Product Catalog Completion Date Core Service"),
        PRODUCT_CATALOG_SHORTEST_CHARGE_END_DATE_CORE_ERROR("PRODUCT_CATALOG_SHORTEST_CHARGE_END_DATE_CORE_ERROR", "Exception while calling Catalog Product Catalog shortest charge end date Core Service"),
        PRODUCT_DATA_CORE_ERROR("PRODUCT_DATA_CORE_ERROR", "Exception while calling Catalog Product Data Core Service"),

        // ODM CORE SERVICE
        ELIGIBILITY_CORE_ERROR("ELIGIBILITY_CORE_ERROR", "Exception while calling Eligibility Core Service"),

        //CREATE RETENTIONS CASE SERVICE
        CREATE_RETENTIONS_CASE_CONNECTION("CREATE_RETENTIONS_CASE_ERROR", "Exception while calling retentions case creation"),
        CORE_RETENTIONS_GENERATE_OFFER_CONNECTION("CORE_RETENTIONS_GENERATE_OFFER_ERROR", "Exception while calling retentions generate offer"),

        //CASE WORKFLOW SERVICE
        CASE_WORKFLOW_CONNECTION("CASE_WORKFLOW_CONNECTION_ERROR", "Exception while calling retentions case workflow"),

        //PRODUCT SWITCH SERVICE
        PRODUCT_SWITCH_CONNECTION("PRODUCT_SWITCH_CONNECTION_ERROR", "Exception while calling product switch service"),

        //ESIS SERVICE
        ESIS_CONNECTION("ESIS_CONNECTION_ERROR", "Exception while calling Esis service"),

        //RISK AND VALUATION CORE SERVICE,
        RISK_CORE_ERROR("RISK_CORE_ERROR", "Exception while calling Risk valuation core"),
        RISK_CORE_CONNECTION("RISK_CORE_CONNECTION", "Exception while calling Risk Valuation Core Service"),
        RISK_CORE_NOT_FOUND("RISK_CORE_NOT_FOUND", "Risk valuation core returned empty or zero valuation"),

        PAF_ID_UNAVAILABLE("PAF_ID_UNAVAILABLE", "PAF did not respond correctly"),
        PAF_DETAILS_UNAVAILABLE("PAF_DETAILS_UNAVAILABLE", "PAF did not respond correctly"),

        ACCOUNT_BALANCES_UNAVAILABLE("ACCOUNT_BALANCES_UNAVAILABLE", "Exception while calling Account Balances API"),
        EXC_IOC_CORE_CALL("EXC_IOCCORE_CALL", "An error occurred while calling ContractsInMcc service"),
        ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR("ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR", "Exception while calling account warning service"),

        LOAN_PAYMENT_PLAN_CHANGE_SERVICE_CONNECTION_ERROR("LOAN_PAYMENT_PLAN_CHANGE_SERVICE_CONNECTION_ERROR", "Exception while calling loan payment plan change API");

        private final String code;
        private final String message;

        Type(final String code, final String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

    }
}
