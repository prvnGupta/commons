package com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "output_struc"
})
@Getter
@Setter
@NoArgsConstructor
public class PaymentHolidayResponse extends ModelBase {
    private static final long serialVersionUID = 1784232905626954559L;

    @JsonProperty("output_struc")
    private OutputStruc outputStruc;
}
