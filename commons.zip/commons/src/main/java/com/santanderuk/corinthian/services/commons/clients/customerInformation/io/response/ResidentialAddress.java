package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResidentialAddress extends ModelBase {

    private static final long serialVersionUID = -2056242651565114545L;

    private String lastEffectiveDateUpdated;
    private String typeUse;
    private String effectiveDate;
    private String informationSource;
    private String postboxType;
}
