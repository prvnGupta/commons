package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class RegularOverpaymentInput {

    @JsonProperty("i_mort_acc_no")
    private Integer iMortAccNo;
    @JsonProperty("i_ovp_inst_seq")
    private int iOvpInstSeq;
    @JsonProperty("i_ovp_inst_action")
    private String iOvpInstAction;
    @JsonProperty("i_bdp_number")
    private Integer iBdpNumber;
    @JsonProperty("i_bdp_type")
    private String iBdpType;
    @JsonProperty("i_payarr_type")
    private String iPayarrType;
    @JsonProperty("i_ovp_inst_to_use")
    private String iOvpInstToUse;
    @JsonProperty("i_ovp_inst_start_date")
    private String iOvpInstStartDate;
    @JsonProperty("i_ovp_inst_end_date")
    private String iOvpInstEndDate;
    @JsonProperty("i_ovp_inst_no_end_date")
    private String iOvpInstNoEndDate;
    @JsonProperty("i_ovp_inst_tot_mon_pay")
    private BigDecimal iOvpInstTotMonPay;
    @JsonProperty("i_ovp_inst_impact")
    private String iOvpInstImpact;
    @JsonProperty("i_ovp_inst_cancel_reason")
    private String iOvpInstCancelReason;
    @JsonProperty("i_channel_type")
    private String iChannelType;
    @JsonProperty("i_source_appl")
    private String iSourceAppl;
    @JsonProperty("i_calling_appl")
    private String iCallingAppl;
    @JsonProperty("i_user_id")
    private String iUserId;
    @JsonProperty("i_loan_data")
    private List<ILoanData> iLoanDatas = Collections.emptyList();
}
