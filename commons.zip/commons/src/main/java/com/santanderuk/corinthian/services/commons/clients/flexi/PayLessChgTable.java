package com.santanderuk.corinthian.services.commons.clients.flexi;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)

@ToString
public class PayLessChgTable extends ModelBase {

    @JsonProperty("pay_less_chg")
    private List<BigDecimal> payLessChg = Collections.emptyList();

    public List<BigDecimal> getPayLessChg() {
        return Collections.unmodifiableList(payLessChg);
    }

    public void setPayLessChg(List<BigDecimal> payLessChg) {
        this.payLessChg = Collections.unmodifiableList(payLessChg);
    }
}
