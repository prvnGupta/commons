package com.santanderuk.corinthian.services.commons.clients.flexi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutputStructureFlexiAccount extends ModelBase {


    @JsonProperty("account_status")
    private String accountStatus;
    @JsonProperty("account_opened")
    private String accountOpened;
    @JsonProperty("next_statement_dt")
    private String nextStatementDt;
    @JsonProperty("borrower_count")
    private int borrowerCount;
    @JsonProperty("esto_flag")
    private String estoFlag;
    @JsonProperty("dd_sort_code_1")
    private int ddSortCode1;
    @JsonProperty("dd_sort_code_2")
    private int ddSortCode2;
    @JsonProperty("dd_sort_code_3")
    private int ddSortCode3;
    @JsonProperty("dd_account_no")
    private int ddAccountNo;
    @JsonProperty("mort_loan_bal")
    private BigDecimal mortLoanBal;
    @JsonProperty("mort_ovp_funds")
    private BigDecimal mortOvpFunds;
    @JsonProperty("mort_int_rate")
    private BigDecimal mortIntRate;
    @JsonProperty("avail_funds_bal")
    private BigDecimal availFundsBal;
    @JsonProperty("avail_funds_left")
    private BigDecimal availFundsLeft;
    @JsonProperty("avail_funds_rate")
    private BigDecimal availFundsRate;
    @JsonProperty("mort_arrs_bal")
    private BigDecimal mortArrsBal;
    @JsonProperty("sund_arrs_bal")
    private BigDecimal sundArrsBal;
    @JsonProperty("avail_funds_arrs")
    private BigDecimal availFundsArrs;
    @JsonProperty("arrs_3_mths")
    private BigDecimal arrs3Mths;
    @JsonProperty("next_payment_dt")
    private String nextPaymentDt;
    @JsonProperty("next_avail_arr_dt")
    private String nextAvailArrDt;
    @JsonProperty("pay_less_chg_table")
    private PayLessChgTable payLessChgTable;
    @JsonProperty("pay_hol_chg_table")
    private PayHolChgTable payHolChgTable;
    @JsonProperty("lump_sum_an_dt")
    private String lumpSumAnDt;
    @JsonProperty("lump_sum_dd_dt")
    private String lumpSumDdDt;
    @JsonProperty("drawdown_an_dt")
    private String drawdownAnDt;
    @JsonProperty("drawdown_dd_dt")
    private String drawdownDdDt;
    @JsonProperty("drawdown_chg")
    private BigDecimal drawdownChg;
    @JsonProperty("statement_chg")
    private BigDecimal statementChg;
    @JsonProperty("overall_cred_lim")
    private BigDecimal overallCredLim;
    @JsonProperty("repayment_method")
    private int repaymentMethod;
    @JsonProperty("o_mort_loan_bal")
    private BigDecimal oMortLoanBal;
    @JsonProperty("o_avail_funds_bal")
    private BigDecimal oAvailFundsBal;
    @JsonProperty("o_next_normal_pay")
    private BigDecimal oNextNormalPay;
    @JsonProperty("o_next_chosen_pay")
    private BigDecimal oNextChosenPay;
    @JsonProperty("data_out_table")
    private List<DataOutTableFlexiAccount> dataOutTableFlexiAccount = Collections.emptyList();

}
