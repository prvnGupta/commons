package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
@NoArgsConstructor
public class PaymentHolidayResponse extends ModelBase {

    private static final long serialVersionUID = 6951594169215745905L;

    @JsonProperty("o_payment_holiday_tab")
    private OPaymentHolidayTab oPaymentHolidayTab;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}
