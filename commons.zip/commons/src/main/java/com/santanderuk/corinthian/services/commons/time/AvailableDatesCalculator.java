package com.santanderuk.corinthian.services.commons.time;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class AvailableDatesCalculator {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public AvailableDates createAvailableDates(String initialDate, String redepmtionDate, boolean isBacsCycle) {
        LocalDate first = LocalDate.parse(initialDate, FORMATTER);
        LocalDate second = first.plusMonths(1);

        AvailableDates availableDates = new AvailableDates();

        LocalDate third = null;
        if (isBacsCycle) {
            availableDates.setThirdAvailableDate("");
        } else {
            third = first.plusMonths(2);
            availableDates.setThirdAvailableDate(third.format(FORMATTER));
        }

        availableDates.setSecondAvailableDate(second.format(FORMATTER));
        availableDates.setFirstAvailableDate(first.format(FORMATTER));

        filterAvailableDatesBasedInRedemptionDate(availableDates, redepmtionDate);

        createFinalAvailableDate(availableDates, redepmtionDate);

        return availableDates;
    }

    private void createFinalAvailableDate(AvailableDates availableDates, String redepmtionDate) {
        LocalDate redemptionDate = LocalDate.parse(redepmtionDate, FORMATTER);
        LocalDate finalAvailable = redemptionDate.minusMonths(3);
        availableDates.setFinalAvailableEndingDate(finalAvailable.format(FORMATTER));
    }

    private void filterAvailableDatesBasedInRedemptionDate(AvailableDates availableDates, String redepmtionDate) {

        LocalDate redemptionDate = LocalDate.parse(redepmtionDate, FORMATTER);
        LocalDate first = LocalDate.parse(availableDates.getFirstAvailableDate(), FORMATTER);
        LocalDate second = LocalDate.parse(availableDates.getSecondAvailableDate(), FORMATTER);


        if (redemptionDate.isBefore(first)) {
            emptyAllAvailableDates(availableDates);
        } else if (redemptionDate.isBefore(second)) {
            empty1stAnd2ndAvailableDate(availableDates);
        } else if (!availableDates.getThirdAvailableDate().equalsIgnoreCase("")) {
            LocalDate third = LocalDate.parse(availableDates.getThirdAvailableDate(), FORMATTER);
            if (redemptionDate.isBefore(third)) {
                availableDates.setThirdAvailableDate("");
            }
        }

    }

    private void empty1stAnd2ndAvailableDate(AvailableDates availableDates) {
        availableDates.setSecondAvailableDate("");
        availableDates.setThirdAvailableDate("");
    }

    private void emptyAllAvailableDates(AvailableDates availableDates) {
        availableDates.setFirstAvailableDate("");
        availableDates.setSecondAvailableDate("");
        availableDates.setThirdAvailableDate("");
    }
}
