package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class OPaymentHolidayTab extends ModelBase {

    private static final long serialVersionUID = 2264130941896330660L;

    @JsonProperty("er_struc")
    private ErStruc erStruc;

    @JsonProperty("o_payment_holiday")
    private List<OPaymentHoliday> oPaymentHoliday;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}
