package com.santanderuk.corinthian.services.commons.clients.productcatalog;

import com.santanderuk.corinthian.services.commons.clients.productcatalog.io.ProductsResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Component
@Slf4j
public class ProductCatalogClient {
    public static final ConnectionException.Type PRODUCT_DATA_CORE_ERROR = ConnectionException.Type.PRODUCT_DATA_CORE_ERROR;
    private static final String REGEX_BAND = "\\{band}";

    @Value("${service.core.productData}")
    private String productDataUrl;

    private final ApiManagerConfig apiManagerConfig;
    private final RestTemplate restTemplate;

    @Autowired
    public ProductCatalogClient(ApiManagerConfig apiManagerConfig, RestTemplate restTemplate) {
        this.apiManagerConfig = apiManagerConfig;
        this.restTemplate = restTemplate;
    }


    public ProductsResponse fetchProductData(String bandId) throws ConnectionException {

        try {
            HttpEntity requestEntity = new HttpEntity(null, generateHttpHeaders());
            String url = replaceBandInUrl(productDataUrl, bandId);

            log.debug("Request for product data: {}", url);
            ResponseEntity<ProductsResponse> response = restTemplate.exchange(url, HttpMethod.GET, requestEntity, ProductsResponse.class);
            log.debug("response body from product data {}", response.getBody());
            log.info("ProductCatalogClient - > product data request received");
            return response.getBody();
        } catch (RestClientException e) {
            log.error("Error while calling Catalog Product Data Core Service", e);
            throw new ConnectionException(PRODUCT_DATA_CORE_ERROR, e);
        }
    }

    private String replaceBandInUrl(String productDataUrl, String bandId) {
        return productDataUrl.replaceAll(REGEX_BAND, bandId);
    }

    private HttpHeaders generateHttpHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }

}
