package com.santanderuk.corinthian.services.commons.clients.productdirectory;


import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ProductDirectoryResponse extends ModelBase {

    private String farthestCompletionDate;
    private String nearestChargeEndDate;
}
