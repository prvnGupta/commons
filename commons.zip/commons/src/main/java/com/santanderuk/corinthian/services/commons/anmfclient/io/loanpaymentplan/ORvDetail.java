
package com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ORvDetail extends ModelBase {

    @JsonProperty("o_rv_type")
    private String oRvType;
    @JsonProperty("o_rv_type_desc")
    private String oRvTypeDesc;
    @JsonProperty("o_mon_prem")
    private String oMonPrem;
    @JsonProperty("o_rv_mat_dt")
    private String oRvMatDt;
    @JsonProperty("o_curr_rv_bal")
    private String oCurrRvBal;
    @JsonProperty("o_proj_mat_val")
    private String oProjMatVal;
}
