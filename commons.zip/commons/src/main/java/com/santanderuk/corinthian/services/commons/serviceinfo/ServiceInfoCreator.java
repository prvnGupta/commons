package com.santanderuk.corinthian.services.commons.serviceinfo;


import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

/**
 * Created by C0232937 on 17/01/2017.
 */
public class ServiceInfoCreator {

    private ServiceInfoCreator() {
    }

    public static ServiceInfo ok() {
        return new ServiceInfo("ok", "", "Data found");
    }

    public static ServiceInfo exception(GeneralException e) {
        return new ServiceInfo("ko", e.getCode(), e.getMessage());
    }

    public static ServiceInfo exception(Exception e) {
        return new ServiceInfo("ko", "500", e.getMessage());
    }
}
