package com.santanderuk.corinthian.services.commons.clients.flexi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
@ToString
public class BaseDataOperationResponse extends ModelBase {

    @JsonProperty("response")
    private ResponseFlexiAccount responseFlexiAccount;
}
