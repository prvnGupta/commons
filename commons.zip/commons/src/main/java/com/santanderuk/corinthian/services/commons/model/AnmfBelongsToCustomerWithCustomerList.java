package com.santanderuk.corinthian.services.commons.model;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AnmfBelongsToCustomerWithCustomerList {
    private Boolean anmfBelongsToCustomer;
    private CustomerDetailsResponse customerDetailsResponse;
    private BdpCustomer bdpCustomer;
}
