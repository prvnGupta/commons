package com.santanderuk.corinthian.services.commons.clients.heartbeat.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HeartBeatResponse extends ModelBase {

    private static final long serialVersionUID = 9032710580643276065L;

    private String code;
    private String message;
    private String region;
}
