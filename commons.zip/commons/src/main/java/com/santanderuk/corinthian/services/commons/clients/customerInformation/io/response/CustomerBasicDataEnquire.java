
package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerBasicDataEnquire extends ModelBase {

    private static final long serialVersionUID = -4414876643520184187L;

    private String title;
    private String firstName;
    private String middleName;
    private String lastName;
    private String fullName;
    private String maidenName;
    private String countryBirth;
    private String birthDate;
    private String gender;
    private String maritalStatus;
    private String documentType;
    private String documentId;
    private String countryResidence;
    private String nationality;
    private String secondNationality;
    private String employmentStatus;
    private String occupation;
    private String activity;
    private String accountingSector;
    private String companyName;
    private String customerRegistrationDate;
    private String companyStartDate;
    private String companyEndDate;
    private String companyType;
    private String companyAdditionalDetail;
    private String tradeName;
    private String countryIncorporation;
    private String educationalLevel;
    private String staff;
    private String dateDeceased;
    private Integer confidentialityLevel;
    private String informationSource;
    private String companyCustomer;
    private String customerPreferredLanguage;
    private String structuralSegment;
    private Boolean highconfidentialityFlag;
    private String knowAs;
    private String suffix;
    private String countryFiscalResidence;
    private String lastDateUpdatedBasicData;
    private ResidentialAddress residentialAddress;
    private UkAddressEnquire ukAddressEnquire;
    private ForeignAddress foreignAddress;
    private BfpoAddress bfpoAddress;
    private List<RobisonList> robisonList = null;
    private ContactDetailsEnquire contactDetailsEnquire;

}
