package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AvailableFunds extends ModelBase {

    private static final long serialVersionUID = 7440057254520379537L;
    @JsonProperty("o_valid")
    private String valid;
    @JsonProperty("o_capital_balance")
    private BigDecimal capitalBalance;
    @JsonProperty("o_arrears_balance")
    private BigDecimal arrearsBalance;
    @JsonProperty("o_unclear_amount")
    private BigDecimal unclearAmount;
    @JsonProperty("o_interest_amount")
    private BigDecimal interestAmount;
    @JsonProperty("o_fee_amt")
    private BigDecimal feeAmount;
    @JsonProperty("o_daily_int_amt")
    private BigDecimal dailyAmount;
}
