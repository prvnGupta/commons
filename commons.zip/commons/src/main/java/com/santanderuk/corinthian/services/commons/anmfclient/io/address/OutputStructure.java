package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_let_agent_name",
        "o_let_agent_addr1",
        "o_let_agent_addr2",
        "o_let_agent_addr3",
        "o_let_agent_addr4",
        "o_let_agent_post_code",
        "o_let_agent_phone",
        "o_consumer_btl_ind",
        "o_elect_discharge",
        "o_elect_discharge_lit",
        "o_property_addr1",
        "o_property_addr2",
        "o_property_addr3",
        "o_property_addr4",
        "o_property_country",
        "o_property_country_comm",
        "o_property_postcode",
        "o_property_county",
        "o_property_p_c",
        "o_consent_to_let",
        "o_purchase_price",
        "o_percent_owner",
        "o_occupancy_code",
        "o_occupancy_code_lit",
        "o_property_type",
        "o_property_type_lit",
        "o_bedrooms",
        "o_tenure",
        "o_tenure_lit",
        "o_garage",
        "o_garage_lit",
        "o_property_use",
        "o_deeds_location",
        "o_deeds_location_lit",
        "o_demat_case",
        "o_country_code",
        "o_property_phone",
        "o_insurance_value",
        "o_insurance_date",
        "o_construction",
        "o_floors",
        "o_heating",
        "o_wc_s",
        "o_bathroom",
        "o_square_footage",
        "o_year_built",
        "o_lease_years",
        "o_gr_ch_rent",
        "o_freq_rent",
        "o_freq_rent_lit",
        "o_service_charge",
        "o_freq_charge",
        "o_freq_charge_lit",
        "o_agent_name",
        "o_agent_addr1",
        "o_agent_addr2",
        "o_agent_addr3",
        "o_agent_addr4",
        "o_agent_county",
        "o_agent_p_c",
        "o_agent_phone",
        "o_tenency_agrmnt",
        "o_rent_term_years",
        "o_rent_term_months",
        "o_rent_amount",
        "o_month_remain",
        "o_kitchens",
        "o_water",
        "o_gas",
        "o_electricity",
        "o_drainage",
        "o_subsidence",
        "o_heave",
        "o_landslip",
        "o_flooding",
        "o_suit_security",
        "o_septic_tank",
        "o_nhbc_riba",
        "o_riba",
        "o_cesspit",
        "o_land_registry_no",
        "o_start_of_lease",
        "o_special_purchase",
        "o_special_purchase_lit",
        "o_prop_let_since",
        "o_last_agreemnt_dt",
        "o_curr_agreemt_exp",
        "o_next_fee_due",
        "o_tenancy_reason",
        "o_registered",
        "o_registered_lit",
        "o_bt_phone",
        "o_lease_st_yrs",
        "o_lease_st_mths",
        "o_lease_st_days",
        "o_mortgage_detail",
        "o_mortgage_detail_lit",
        "o_asset_class",
        "o_land_registry_02",
        "o_land_registry_03",
        "o_land_registry_04",
        "o_land_registry_05",
        "o_land_registry_06",
        "o_unique_ent_rf_no",
        "o_charge_date_1",
        "o_uniq_prop_ref_no",
        "o_capital_adequacy",
        "o_capital_adequacy_lit",
        "o_borrower_type",
        "o_indust_category",
        "o_ind_sub_cat",
        "o_loan_type",
        "o_anmf_valuation_grp",
        "o_hpi_valuation_grp",
        "o_avm_valuation_grp",
        "o_subseq_charge_arr_tab",
        "e_struc"
})
public class OutputStructure extends ModelBase {

    private static final long serialVersionUID = 8691865099745362419L;

    @JsonProperty("o_let_agent_name")
    private String oLetAgentName;
    @JsonProperty("o_let_agent_addr1")
    private String oLetAgentAddr1;
    @JsonProperty("o_let_agent_addr2")
    private String oLetAgentAddr2;
    @JsonProperty("o_let_agent_addr3")
    private String oLetAgentAddr3;
    @JsonProperty("o_let_agent_addr4")
    private String oLetAgentAddr4;
    @JsonProperty("o_let_agent_post_code")
    private String oLetAgentPostCode;
    @JsonProperty("o_let_agent_phone")
    private String oLetAgentPhone;
    @JsonProperty("o_consumer_btl_ind")
    private String oConsumerBtlInd;
    @JsonProperty("o_elect_discharge")
    private String oElectDischarge;
    @JsonProperty("o_elect_discharge_lit")
    private String oElectDischargeLit;
    @JsonProperty("o_property_addr1")
    private String oPropertyAddr1;
    @JsonProperty("o_property_addr2")
    private String oPropertyAddr2;
    @JsonProperty("o_property_addr3")
    private String oPropertyAddr3;
    @JsonProperty("o_property_addr4")
    private String oPropertyAddr4;
    @JsonProperty("o_property_country")
    private String oPropertyCountry;
    @JsonProperty("o_property_country_comm")
    private String oPropertyCountryComm;
    @JsonProperty("o_property_postcode")
    private String oPropertyPostcode;
    @JsonProperty("o_property_county")
    private String oPropertyCounty;
    @JsonProperty("o_property_p_c")
    private String oPropertyPC;
    @JsonProperty("o_consent_to_let")
    private String oConsentToLet;
    @JsonProperty("o_purchase_price")
    private int oPurchasePrice;
    @JsonProperty("o_percent_owner")
    private int oPercentOwner;
    @JsonProperty("o_occupancy_code")
    private String oOccupancyCode;
    @JsonProperty("o_occupancy_code_lit")
    private String oOccupancyCodeLit;
    @JsonProperty("o_property_type")
    private String oPropertyType;
    @JsonProperty("o_property_type_lit")
    private String oPropertyTypeLit;
    @JsonProperty("o_bedrooms")
    private int oBedrooms;
    @JsonProperty("o_tenure")
    private String oTenure;
    @JsonProperty("o_tenure_lit")
    private String oTenureLit;
    @JsonProperty("o_garage")
    private String oGarage;
    @JsonProperty("o_garage_lit")
    private String oGarageLit;
    @JsonProperty("o_property_use")
    private String oPropertyUse;
    @JsonProperty("o_deeds_location")
    private int oDeedsLocation;
    @JsonProperty("o_deeds_location_lit")
    private String oDeedsLocationLit;
    @JsonProperty("o_demat_case")
    private String oDematCase;
    @JsonProperty("o_country_code")
    private String oCountryCode;
    @JsonProperty("o_property_phone")
    private String oPropertyPhone;
    @JsonProperty("o_insurance_value")
    private int oInsuranceValue;
    @JsonProperty("o_insurance_date")
    private String oInsuranceDate;
    @JsonProperty("o_construction")
    private String oConstruction;
    @JsonProperty("o_floors")
    private int oFloors;
    @JsonProperty("o_heating")
    private String oHeating;
    @JsonProperty("o_wc_s")
    private int oWcS;
    @JsonProperty("o_bathroom")
    private int oBathroom;
    @JsonProperty("o_square_footage")
    private int oSquareFootage;
    @JsonProperty("o_year_built")
    private String oYearBuilt;
    @JsonProperty("o_lease_years")
    private int oLeaseYears;
    @JsonProperty("o_gr_ch_rent")
    private BigDecimal oGrChRent;
    @JsonProperty("o_freq_rent")
    private String oFreqRent;
    @JsonProperty("o_freq_rent_lit")
    private String oFreqRentLit;
    @JsonProperty("o_service_charge")
    private BigDecimal oServiceCharge;
    @JsonProperty("o_freq_charge")
    private String oFreqCharge;
    @JsonProperty("o_freq_charge_lit")
    private String oFreqChargeLit;
    @JsonProperty("o_agent_name")
    private String oAgentName;
    @JsonProperty("o_agent_addr1")
    private String oAgentAddr1;
    @JsonProperty("o_agent_addr2")
    private String oAgentAddr2;
    @JsonProperty("o_agent_addr3")
    private String oAgentAddr3;
    @JsonProperty("o_agent_addr4")
    private String oAgentAddr4;
    @JsonProperty("o_agent_county")
    private String oAgentCounty;
    @JsonProperty("o_agent_p_c")
    private String oAgentPC;
    @JsonProperty("o_agent_phone")
    private String oAgentPhone;
    @JsonProperty("o_tenency_agrmnt")
    private String oTenencyAgrmnt;
    @JsonProperty("o_rent_term_years")
    private int oRentTermYears;
    @JsonProperty("o_rent_term_months")
    private int oRentTermMonths;
    @JsonProperty("o_rent_amount")
    private BigDecimal oRentAmount;
    @JsonProperty("o_month_remain")
    private int oMonthRemain;
    @JsonProperty("o_kitchens")
    private int oKitchens;
    @JsonProperty("o_water")
    private String oWater;
    @JsonProperty("o_gas")
    private String oGas;
    @JsonProperty("o_electricity")
    private String oElectricity;
    @JsonProperty("o_drainage")
    private String oDrainage;
    @JsonProperty("o_subsidence")
    private String oSubsidence;
    @JsonProperty("o_heave")
    private String oHeave;
    @JsonProperty("o_landslip")
    private String oLandslip;
    @JsonProperty("o_flooding")
    private String oFlooding;
    @JsonProperty("o_suit_security")
    private String oSuitSecurity;
    @JsonProperty("o_septic_tank")
    private String oSepticTank;
    @JsonProperty("o_nhbc_riba")
    private String oNhbcRiba;
    @JsonProperty("o_riba")
    private String oRiba;
    @JsonProperty("o_cesspit")
    private String oCesspit;
    @JsonProperty("o_land_registry_no")
    private String oLandRegistryNo;
    @JsonProperty("o_start_of_lease")
    private String oStartOfLease;
    @JsonProperty("o_special_purchase")
    private String oSpecialPurchase;
    @JsonProperty("o_special_purchase_lit")
    private String oSpecialPurchaseLit;
    @JsonProperty("o_prop_let_since")
    private String oPropLetSince;
    @JsonProperty("o_last_agreemnt_dt")
    private String oLastAgreemntDt;
    @JsonProperty("o_curr_agreemt_exp")
    private String oCurrAgreemtExp;
    @JsonProperty("o_next_fee_due")
    private String oNextFeeDue;
    @JsonProperty("o_tenancy_reason")
    private String oTenancyReason;
    @JsonProperty("o_registered")
    private String oRegistered;
    @JsonProperty("o_registered_lit")
    private String oRegisteredLit;
    @JsonProperty("o_bt_phone")
    private String oBtPhone;
    @JsonProperty("o_lease_st_yrs")
    private String oLeaseStYrs;
    @JsonProperty("o_lease_st_mths")
    private String oLeaseStMths;
    @JsonProperty("o_lease_st_days")
    private String oLeaseStDays;
    @JsonProperty("o_mortgage_detail")
    private String oMortgageDetail;
    @JsonProperty("o_mortgage_detail_lit")
    private String oMortgageDetailLit;
    @JsonProperty("o_asset_class")
    private String oAssetClass;
    @JsonProperty("o_land_registry_02")
    private String oLandRegistry02;
    @JsonProperty("o_land_registry_03")
    private String oLandRegistry03;
    @JsonProperty("o_land_registry_04")
    private String oLandRegistry04;
    @JsonProperty("o_land_registry_05")
    private String oLandRegistry05;
    @JsonProperty("o_land_registry_06")
    private String oLandRegistry06;
    @JsonProperty("o_unique_ent_rf_no")
    private String oUniqueEntRfNo;
    @JsonProperty("o_charge_date_1")
    private String oChargeDate1;
    @JsonProperty("o_uniq_prop_ref_no")
    private String oUniqPropRefNo;
    @JsonProperty("o_capital_adequacy")
    private String oCapitalAdequacy;
    @JsonProperty("o_capital_adequacy_lit")
    private String oCapitalAdequacyLit;
    @JsonProperty("o_borrower_type")
    private int oBorrowerType;
    @JsonProperty("o_indust_category")
    private int oIndustCategory;
    @JsonProperty("o_ind_sub_cat")
    private int oIndSubCat;
    @JsonProperty("o_loan_type")
    private int oLoanType;
    @JsonProperty("o_anmf_valuation_grp")
    private OAnmfValuationGrp oAnmfValuationGrp;
    @JsonProperty("o_hpi_valuation_grp")
    private OHpiValuationGrp oHpiValuationGrp;
    @JsonProperty("o_avm_valuation_grp")
    private OAvmValuationGrp oAvmValuationGrp;
    @JsonProperty("o_subseq_charge_arr_tab")
    private OSubseqChargeArrangementTab oSubseqChargeArrangementTab;
    @JsonProperty("e_struc")
    private EStruc eStruc;
}
