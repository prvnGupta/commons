package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PhoneDetailsEnquire extends ModelBase {

    private static final long serialVersionUID = -8207367577710771132L;

    private Boolean preferredContact;
    private String phone;
    private String use;
    private AvailibilityPhone availibilityPhone;

}
