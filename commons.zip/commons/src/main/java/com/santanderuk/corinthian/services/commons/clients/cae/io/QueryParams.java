package com.santanderuk.corinthian.services.commons.clients.cae.io;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QueryParams {
    private String uid;
    private String operation;
}
