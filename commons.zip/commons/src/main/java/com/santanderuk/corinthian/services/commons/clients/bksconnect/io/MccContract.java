package com.santanderuk.corinthian.services.commons.clients.bksconnect.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "localContract",
        "partenonContract",
        "iban"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MccContract implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("localContract")
    private LocalContract localContract;
    @JsonProperty("partenonContract")
    private PartenonContract partenonContract;
    @JsonProperty("iban")
    private Iban iban;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("localContract", localContract)
                .append("partenonContract", partenonContract)
                .append("iban", iban)
                .toString();
    }
}
