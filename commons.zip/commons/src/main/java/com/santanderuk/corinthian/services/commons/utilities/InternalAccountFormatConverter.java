package com.santanderuk.corinthian.services.commons.utilities;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class InternalAccountFormatConverter {

    public PartenonAccountNumber convertStringToPartenonAccountNumber(String partenonAccountNumberStringFormat) throws GeneralException {
        try {
            return new PartenonAccountNumber(
                    partenonAccountNumberStringFormat.substring(0, 4),
                    partenonAccountNumberStringFormat.substring(4, 8),
                    partenonAccountNumberStringFormat.substring(8, 11),
                    partenonAccountNumberStringFormat.substring(11, 18)
            );
        } catch (Exception e) {
            log.warn("Error while converting string to PartenonAccountNumber format");
            throw new GeneralException("LAC_MAPPER_EXC", "Error while converting string to PartenonAccountNumber format", e);
        }
    }

    public LocalAccountNumber convertStringToLocalAccountNumber(String localAccountNumberStringFormat) throws GeneralException {
        try {
            return new LocalAccountNumber(
                    localAccountNumberStringFormat.substring(0, 6),
                    localAccountNumberStringFormat.substring(6)
            );
        } catch (Exception e) {
            log.warn("Error while converting string to LocalAccountNumber format");
            throw new GeneralException("LAC_MAPPER_EXC", "Error while converting string to LocalAccountNumber format", e);
        }
    }

    public String convertPartenonAccountNumberToStringFormat(PartenonAccountNumber partenonAccountNumber) throws GeneralException {
        try {
            return String.format("%s%s%s%s", partenonAccountNumber.getCompany().substring(0, 4), partenonAccountNumber.getCentre().substring(0, 4), partenonAccountNumber.getProduct().substring(0, 3), partenonAccountNumber.getContract().substring(0, 7));
        } catch (Exception e) {
            log.warn("Error while converting to PartenonAccountNumber to String format");
            throw new GeneralException("LAC_MAPPER_EXC", "Error while converting to PartenonAccountNumber to String format", e);
        }
    }

    public String convertLocalAccountNumberToStringFormat(LocalAccountNumber localAccountNumber) throws GeneralException {
        try {
            return String.format("%s%s", localAccountNumber.getSortcode().substring(0, 6), localAccountNumber.getAccountNumber());
        } catch (Exception e) {
            log.warn("Error while converting LocalAccountNumber to String format");
            throw new GeneralException("LAC_MAPPER_EXC", "Error while converting LocalAccountNumber to String format", e);
        }
    }
}
