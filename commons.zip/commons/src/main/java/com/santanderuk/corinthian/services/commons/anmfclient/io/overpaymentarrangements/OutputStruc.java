package com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Collections;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutputStruc extends ModelBase {

    private static final long serialVersionUID = 7250869390238012179L;

    @JsonProperty("o_payarr_list_ovp")
    private List<OPayArrOvpInst> oPayArrOvpInstList;
    @JsonProperty("o_payarr_list_flexi")
    private List<OPayArrOvpInst> oPayArrFlexis = Collections.emptyList();
    @JsonProperty("o_payarr_list_arrears")
    private List<OPayArrOvpInst> oPayArrArrears = Collections.emptyList();
    @JsonProperty("o_payarr_list_oneoff")
    private List<OPayArrOvpInst> oPayArrOneoff = Collections.emptyList();
    @JsonProperty("o_payarr_list_dwp")
    private List<OPayArrOvpInst> oPayArrDwp = Collections.emptyList();
    @JsonProperty("o_payarr_list_ph")
    private List<OPayArrOvpInst> oPayArrPh = Collections.emptyList();
    @JsonProperty("e_struc")
    private EStruc eStruc;

}
