package com.santanderuk.corinthian.services.commons.clients.insurance;


import com.santanderuk.corinthian.services.commons.clients.insurance.io.CustomerId;
import com.santanderuk.corinthian.services.commons.clients.insurance.io.CustomerIdWrapper;
import com.santanderuk.corinthian.services.commons.clients.insurance.io.GetInstantPriceResponse;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class InsuranceClient {
    private static final String X_IBM_CLIENT_SECRET = "X-IBM-Client-Secret";
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";
    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public InsuranceClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public GetInstantPriceResponse getInstantPrice(String getInstantPriceUrl, String customerId) throws ConnectionException {

        try {
            log.debug("About to call Get Instant Price core api - customerInformation for customerId: {}", customerId);
            log.info("About to call Get Instant Price core api");

            CustomerIdWrapper request = generateCustomerId(customerId);
            HttpEntity<CustomerIdWrapper> entity = new HttpEntity<>(request, buildHeaders());
            ResponseEntity<GetInstantPriceResponse> responseEntity = restTemplate.postForEntity(
                    getInstantPriceUrl,
                    entity,
                    GetInstantPriceResponse.class);

            GetInstantPriceResponse getInstantPriceResponse = responseEntity.getBody();
            log.debug("Get Instant Price core api response received: {}", getInstantPriceResponse);
            log.info("Get Instant Price core api response received");

            return getInstantPriceResponse;

        } catch (Exception e) {
            log.warn("Exception while calling getInstantPrice");
            throw new ConnectionException("GET_INSTANT_PRICE_EXC", "Exception while calling getInstantPrice core service: ", e);
        }
    }

    private CustomerIdWrapper generateCustomerId(String customerIdString) {
        CustomerIdWrapper customerIdWrapper = new CustomerIdWrapper();
        CustomerId customerId = new CustomerId();
        customerId.setCustomerType(customerIdString.substring(0, 1));
        customerId.setCustomerNumber(customerIdString.substring(1));
        customerIdWrapper.setCustomerId(customerId);
        return customerIdWrapper;
    }

    private MultiValueMap<String, String> buildHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(X_IBM_CLIENT_ID, apiManagerConfig.getClientIdValue());
        headers.add(X_IBM_CLIENT_SECRET, apiManagerConfig.getClientSecretValue());
        headers.add("Content-Type", "application/json");
        return headers;
    }

}
