package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OErcStepDetailsTab extends ModelBase {

    @JsonProperty("o_erc_step_details")
    private List<OErcStepDetail> oErcStepDetails;
}
