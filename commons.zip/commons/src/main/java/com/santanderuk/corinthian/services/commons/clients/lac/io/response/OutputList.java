package com.santanderuk.corinthian.services.commons.clients.lac.io.response;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OutputList extends ModelBase {
    private String contractOutputId;
    private String outputContractIdentifierType;
}
