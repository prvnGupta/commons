
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OActiveFlexiLoanDetail extends ModelBase {
    private final static long serialVersionUID = -1680375461528825840L;

    @JsonProperty("o_loan_scheme")
    private String oLoanScheme;
    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;
    @JsonProperty("o_repayment_type")
    private String oRepaymentType;
    @JsonProperty("o_repayment_type_lit")
    private String oRepaymentTypeLit;
    @JsonProperty("o_balance")
    private BigDecimal oBalance;
    @JsonProperty("o_start_date")
    private String oStartDate;
    @JsonProperty("o_redemption_date")
    private String oRedemptionDate;
    @JsonProperty("o_remaining_instlm")
    private int oRemainingInstlm;
    @JsonProperty("o_rem_term_years")
    private int oRemTermYears;
    @JsonProperty("o_rem_term_months")
    private int oRemTermMonths;
    @JsonProperty("o_pend_redemption_date")
    private String oPendRedemptionDate;
    @JsonProperty("o_pend_remaining_instlm")
    private int oPendRemainingInstlm;
    @JsonProperty("o_product_code")
    private String oProductCode;
    @JsonProperty("o_product_catergory")
    private String oProductCatergory;
    @JsonProperty("o_product_catergory_desc")
    private String oProductCatergoryDesc;
    @JsonProperty("o_charged_until")
    private String oChargedUntil;
    @JsonProperty("o_chrge_until_mths")
    private int oChrgeUntilMths;
    @JsonProperty("o_mort_range")
    private String oMortRange;
    @JsonProperty("o_range_name")
    private String oRangeName;
    @JsonProperty("o_interest_rate")
    private BigDecimal oInterestRate;
    @JsonProperty("o_base_rate")
    private BigDecimal oBaseRate;
    @JsonProperty("o_base_rate_diff")
    private BigDecimal oBaseRateDiff;
    @JsonProperty("o_product_type")
    private String oProductType;
    @JsonProperty("o_product_desc")
    private String oProductDesc;
    @JsonProperty("o_product_end_date")
    private String oProductEndDate;

}
