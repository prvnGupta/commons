package com.santanderuk.corinthian.services.commons.anmfclient.io.simulations;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.anmfclient.io.EStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OutputStruc extends ModelBase {

    @JsonProperty("o_simulation_id")
    private int oSimulationId;

    @JsonProperty("o_tot_ovp_amount")
    private BigDecimal oTotOvpAmount;

    @JsonProperty("o_tot_erc")
    private BigDecimal oTotErc;

    @JsonProperty("o_tot_payment")
    private BigDecimal oTotPayment;

    @JsonProperty("o_tot_sim_mon_pay")
    private BigDecimal oTotSimMonPay;

    @JsonProperty("o_tot_int_bef_sim")
    private BigDecimal oTotIntBefSim;

    @JsonProperty("o_tot_int_aft_sim")
    private BigDecimal oTotIntAftSim;

    @JsonProperty("o_cap_bal_aft_sim")
    private BigDecimal oCapBalAftSim;

    @JsonProperty("o_distri_type")
    private String oDistriType;

    @JsonProperty("o_distri_type_desc")
    private String oDistriTypeDesc;

    @JsonProperty("o_erc_allow_imp")
    private String oErcAllowImp;

    @JsonProperty("o_erc_allow_imp_desc")
    private String oErcAllowImpDesc;

    @JsonProperty("o_kfi_ref_no")
    private String oKfiRefNo;

    @JsonProperty("o_tot_next_mon_pay")
    private BigDecimal oTotNextMonPay;

    @JsonProperty("o_tot_second_mon_pay")
    private BigDecimal oTotSecondMonPay;

    @JsonProperty("o_tot_est_final_pay")
    private BigDecimal oTotEstFinalPay;

    @JsonProperty("o_tot_mar_saving")
    private BigDecimal oTotMarSaving;

    @JsonProperty("o_tot_term_saving")
    private BigDecimal oTotTermSaving;

    @JsonProperty("o_tot_int_saving")
    private BigDecimal oTotIntSaving;

    @JsonProperty("o_simulation_status")
    private String oSimulationStatus;

    @JsonProperty("o_loan_data")
    private List<OLoanData> oLoanData;

    @JsonProperty("o_message")
    private String oMessage;

    @JsonProperty("o_warning")
    private String oWarning;

    @JsonProperty("e_struc")
    private EStruc eStruc;
}
