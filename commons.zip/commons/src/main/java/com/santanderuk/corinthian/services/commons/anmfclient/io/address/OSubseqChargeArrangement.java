package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_subseq_chrg_seq",
        "o_lender_s_name",
        "o_amount",
        "o_subsq_chg_stat",
        "o_subsq_chg_stat_lit",
        "o_stat_of_subqchrg",
        "o_stat_of_subqchrg_lit",
        "o_lender_s_addr",
        "o_lender_s_addr_1",
        "o_lender_s_addr_2",
        "o_lender_s_addr_3",
        "o_lender_s_county",
        "o_lender_s_p_c",
        "o_account_roll_no",
        "o_charge_type",
        "o_charge_type_lit",
        "o_start_date",
        "o_action_required",
        "o_action_required_lit",
        "o_liability_amount",
        "o_valid_to_date",
        "o_term",
        "o_account_holder",
        "o_account_holder_1",
        "o_account_holder_2",
        "o_account_holder_3",
        "o_monthly_payment",
        "o_purpose_of_loan",
        "o_enquiry_date",
        "o_notifc_date",
        "o_fee_received",
        "o_num_borr_auth",
        "o_contact_name",
        "o_telephone",
        "o_fax_number",
        "o_send_by_fax",
        "o_dx_address",
        "o_spec_uw_reqd",
        "o_spec_uw_action",
        "o_spec_uw_action_lit",
        "o_in_favour_of"
})
public class OSubseqChargeArrangement extends ModelBase {

    private static final long serialVersionUID = 1456755099745983485L;

    @JsonProperty("o_subseq_chrg_seq")
    private int oSubseqChrgSeq;
    @JsonProperty("o_lender_s_name")
    private String oLenderSName;
    @JsonProperty("o_amount")
    private BigDecimal oAmount;
    @JsonProperty("o_subsq_chg_stat")
    private String oSubseqChgStat;
    @JsonProperty("o_subsq_chg_stat_lit")
    private String oSubseqChgStatLit;
    @JsonProperty("o_stat_of_subqchrg")
    private String oStatOfSubqchrg;
    @JsonProperty("o_stat_of_subqchrg_lit")
    private String oStatOfSubqchrgLit;
    @JsonProperty("o_lender_s_addr")
    private String oLenderSAddr;
    @JsonProperty("o_lender_s_addr_1")
    private String oLenderSAddr1;
    @JsonProperty("o_lender_s_addr_2")
    private String oLenderSAddr2;
    @JsonProperty("o_lender_s_addr_3")
    private String oLenderSAddr3;
    @JsonProperty("o_lender_s_county")
    private String oLenderSCounty;
    @JsonProperty("o_lender_s_p_c")
    private String oLenderSPostCode;
    @JsonProperty("o_account_roll_no")
    private String oAccountRollNo;
    @JsonProperty("o_charge_type")
    private String oChargeType;
    @JsonProperty("o_charge_type_lit")
    private String oChargeTypeLit;
    @JsonProperty("o_start_date")
    private String oStartDate;
    @JsonProperty("o_action_required")
    private String oActionRequired;
    @JsonProperty("o_action_required_lit")
    private String oActionRequiredLit;
    @JsonProperty("o_liability_amount")
    private BigDecimal oLiabilityAmount;
    @JsonProperty("o_valid_to_date")
    private String oValidToDate;
    @JsonProperty("o_term")
    private int oTerm;
    @JsonProperty("o_account_holder")
    private String oAccountHolder;
    @JsonProperty("o_account_holder_1")
    private String oAccountHolder1;
    @JsonProperty("o_account_holder_2")
    private String oAccountHolder2;
    @JsonProperty("o_account_holder_3")
    private String oAccountHolder3;
    @JsonProperty("o_monthly_payment")
    private BigDecimal oMonthlyPayment;
    @JsonProperty("o_purpose_of_loan")
    private String oPurposeOfLoan;
    @JsonProperty("o_enquiry_date")
    private String oEnquiryDate;
    @JsonProperty("o_notifc_date")
    private String oNotifcDate;
    @JsonProperty("o_fee_received")
    private BigDecimal oFeeReceived;
    @JsonProperty("o_num_borr_auth")
    private int oNumBorrAuth;
    @JsonProperty("o_contact_name")
    private String oContactName;
    @JsonProperty("o_telephone")
    private String oTelephone;
    @JsonProperty("o_fax_number")
    private String oFaxNumber;
    @JsonProperty("o_send_by_fax")
    private String oSendByFax;
    @JsonProperty("o_dx_address")
    private String oDxAddress;
    @JsonProperty("o_spec_uw_reqd")
    private String oSpecUwReqd;
    @JsonProperty("o_spec_uw_action")
    private String oSpecUwAction;
    @JsonProperty("o_spec_uw_action_lit")
    private String oSpecUwActionLit;
    @JsonProperty("o_in_favour_of")
    private String oInFavourOf;
}
