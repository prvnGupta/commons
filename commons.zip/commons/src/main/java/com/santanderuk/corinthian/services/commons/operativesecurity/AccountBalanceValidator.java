package com.santanderuk.corinthian.services.commons.operativesecurity;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.atomic.AtomicReference;

import static java.util.Collections.singletonList;

@Component
public class AccountBalanceValidator {

    private final AccountBalancesClient accountBalancesClient;
    private final InternalAccountFormatConverter internalAccountFormatConverter;

    @Autowired
    public AccountBalanceValidator(AccountBalancesClient accountBalancesClient, InternalAccountFormatConverter internalAccountFormatConverter) {
        this.accountBalancesClient = accountBalancesClient;
        this.internalAccountFormatConverter = internalAccountFormatConverter;
    }

    public void validate(BigDecimal amount, PartenonAccountNumber partenonAccountNumber, String accountBalancesUrl, boolean excludingOverdraftBalance) throws GeneralException {

        String partenonAccountFormatted = internalAccountFormatConverter.convertPartenonAccountNumberToStringFormat(partenonAccountNumber);
        AccountBalancesResponse accountBalancesResponse = accountBalancesClient.fetchBalances(accountBalancesUrl, singletonList(partenonAccountFormatted));
        AccountBalance matchedAccount = fetchMatchedAccount(accountBalancesResponse, partenonAccountFormatted);
        if (matchedAccount == null) {
            throw new ValidationsException(ValidationsException.Type.EXC_ACCOUNT_BALANCES_NOT_FOUND);
        }
        if (accountInsufficientBalance(amount, matchedAccount, excludingOverdraftBalance)) {
            throw new ValidationsException(ValidationsException.Type.EXC_ACCOUNT_INSUFFICIENT_BALANCE);
        }
    }

    private AccountBalance fetchMatchedAccount(AccountBalancesResponse accountBalancesResponse, String partenonContractId) {
        AtomicReference<AccountBalance> matchedAccountBalance = new AtomicReference<>();
        accountBalancesResponse.getAccountBalances().forEach(
                accountBalance -> {
                    if (accountBalance.getPartenonContractId().trim().equalsIgnoreCase(partenonContractId.trim())) {
                        matchedAccountBalance.set(accountBalance);
                    }
                });
        return matchedAccountBalance.get();
    }

    private boolean accountInsufficientBalance(BigDecimal amountToPay, AccountBalance accountBalance, boolean excludingOverdraftBalance) {
        return excludingOverdraftBalance ?
                convertStringToBigDecimal(accountBalance.getBalanceIncPending()).compareTo(amountToPay) < 0 :
                convertStringToBigDecimal(accountBalance.getBalanceIncPending()).add(convertStringToBigDecimal(accountBalance.getOverdraftRemaining())).compareTo(amountToPay) < 0;
    }

    private BigDecimal convertStringToBigDecimal(String amount) {
        if (null != amount) {
            String sanitisedString = amount.replace(",", "");
            String[] split = sanitisedString.split(" ");
            if (split[1].equalsIgnoreCase("c")) {
                return new BigDecimal(split[0]).setScale(2, RoundingMode.HALF_UP);
            } else {
                return new BigDecimal("-" + split[0]).setScale(2, RoundingMode.HALF_UP);
            }
        } else {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
    }
}
