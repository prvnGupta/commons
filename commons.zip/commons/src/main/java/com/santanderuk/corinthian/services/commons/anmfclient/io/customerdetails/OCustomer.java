
package com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OCustomer extends ModelBase {

    @JsonProperty("o_customer_no")
    public Integer oCustomerNo;
    @JsonProperty("o_bdp_type")
    public String oBdpType;
    @JsonProperty("o_customer_id")
    public Integer oCustomerId;
    @JsonProperty("o_customer_title")
    public String oCustomerTitle;
    @JsonProperty("o_customer_title_bdp")
    public String oCustomerTitleBdp;
    @JsonProperty("o_initials")
    public String oInitials;
    @JsonProperty("o_forename1")
    public String oForename1;
    @JsonProperty("o_forename2")
    public String oForename2;
    @JsonProperty("o_forename3")
    public String oForename3;
    @JsonProperty("o_surname")
    public String oSurname;
    @JsonProperty("o_corresp_addr1")
    public String oCorrespAddr1;
    @JsonProperty("o_corresp_addr2")
    public String oCorrespAddr2;
    @JsonProperty("o_corresp_addr3")
    public String oCorrespAddr3;
    @JsonProperty("o_corresp_addr4")
    public String oCorrespAddr4;
    @JsonProperty("o_corresp_country")
    public String oCorrespCountry;
    @JsonProperty("o_corresp_postcode")
    public String oCorrespPostcode;
    @JsonProperty("o_corresp_country_code")
    public String oCorrespCountryCode;
    @JsonProperty("o_corresp_addr_type")
    public String oCorrespAddrType;
    @JsonProperty("o_date_of_birth")
    public String oDateOfBirth;
    @JsonProperty("o_deceased")
    public String oDeceased;
    @JsonProperty("o_date_of_death")
    public String oDateOfDeath;
    @JsonProperty("o_death_cert_flag")
    public String oDeathCertFlag;
    @JsonProperty("o_dcert_fup_date")
    public String oDcertFupDate;
    @JsonProperty("o_ccn_flag")
    public String oCcnFlag;
    @JsonProperty("o_ccn_flag_desc")
    public String oCcnFlagDesc;
    @JsonProperty("o_ccn_flag_date")
    public String oCcnFlagDate;
    @JsonProperty("o_staff_mortgage")
    public String oStaffMortgage;
    @JsonProperty("o_gender")
    public String oGender;
    @JsonProperty("o_gender_desc")
    public String oGenderDesc;
    @JsonProperty("o_probate_required")
    public String oProbateRequired;
    @JsonProperty("o_probate_required_desc")
    public String oProbateRequiredDesc;
    @JsonProperty("o_bankrupt")
    public String oBankrupt;
    @JsonProperty("o_bankrupt_date")
    public String oBankruptDate;
    @JsonProperty("o_marital_status")
    public String oMaritalStatus;
    @JsonProperty("o_marital_status_desc")
    public String oMaritalStatusDesc;
    @JsonProperty("o_e_mail_address")
    public String oEMailAddress;
    @JsonProperty("o_mobile_phone")
    public String oMobilePhone;
    @JsonProperty("o_home_phone")
    public String oHomePhone;
    @JsonProperty("o_business_phone")
    public String oBusinessPhone;
    @JsonProperty("o_business_phone_ext")
    public int oBusinessPhoneExt;
    @JsonProperty("o_fax_number")
    public String oFaxNumber;
    @JsonProperty("o_special_needs")
    public Integer oSpecialNeeds;
    @JsonProperty("o_special_needs_desc")
    public String oSpecialNeedsDesc;
    @JsonProperty("o_preferred_method")
    public String oPreferredMethod;
    @JsonProperty("o_preferred_time_f")
    public String oPreferredTimeF;
    @JsonProperty("o_preferred_time_t")
    public String oPreferredTimeT;
    @JsonProperty("o_returned_mail")
    public String oReturnedMail;
    @JsonProperty("o_marketing_flag")
    public String oMarketingFlag;
    @JsonProperty("o_previous_title")
    public String oPreviousTitle;
    @JsonProperty("o_previous_surname")
    public String oPreviousSurname;
    @JsonProperty("o_prev_forename")
    public String oPrevForename;
    @JsonProperty("o_prev_forename_1")
    public String oPrevForename1;
    @JsonProperty("o_prev_forename_2")
    public String oPrevForename2;
    @JsonProperty("o_company_name")
    public String oCompanyName;
    @JsonProperty("o_position")
    public String oPosition;
    @JsonProperty("o_income")
    public List<OIncome> oIncome = null;
    @JsonProperty("o_self_cert")
    public String oSelfCert;
    @JsonProperty("o_company_address1")
    public String oCompanyAddress1;
    @JsonProperty("o_company_address2")
    public String oCompanyAddress2;
    @JsonProperty("o_company_address3")
    public String oCompanyAddress3;
    @JsonProperty("o_company_address4")
    public String oCompanyAddress4;
    @JsonProperty("o_postcode")
    public String oPostcode;

}
