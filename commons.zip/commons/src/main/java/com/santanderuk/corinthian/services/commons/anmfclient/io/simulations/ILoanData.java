package com.santanderuk.corinthian.services.commons.anmfclient.io.simulations;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ILoanData extends ModelBase {
    @JsonProperty("i_loan_sch")
    private String iLoanSch;

    @JsonProperty("i_appl_seq_no")
    private int iApplSeqNo;

    @JsonProperty("i_ln_ovp_amount")
    private BigDecimal iLnOvpAmount;

    @JsonProperty("i_change_type")
    private String iChangeType;

    @JsonProperty("i_erc_waiver")
    private String iErcWaiver;

    @JsonProperty("i_erc_waiver_rsn")
    private String iErcWaiverRsn;
}
