package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_avm_valuation_dt",
        "o_avm_upd_tmstmp",
        "o_avm_valuation",
        "o_avm_conf_level"
})
public class OAvmValuationGrp extends ModelBase {

    private static final long serialVersionUID = 1L;

    @JsonProperty("o_avm_valuation_dt")
    public String oAvmValuationDt;
    @JsonProperty("o_avm_upd_tmstmp")
    public String oAvmUpdTmstmp;
    @JsonProperty("o_avm_valuation")
    public BigDecimal oAvmValuation;
    @JsonProperty("o_avm_conf_level")
    public BigDecimal oAvmConfLevel;
}
