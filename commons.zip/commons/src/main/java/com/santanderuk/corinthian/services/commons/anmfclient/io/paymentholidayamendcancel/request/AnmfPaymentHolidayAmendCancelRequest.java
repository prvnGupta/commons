package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "PaymentHolidayRequest"
})
public class AnmfPaymentHolidayAmendCancelRequest extends ModelBase {

    private static final long serialVersionUID = -8797721935471615939L;

    @JsonProperty("PaymentHolidayRequest")
    private PaymentHolidayRequest paymentHolidayRequest;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    @JsonProperty("PaymentHolidayRequest")
    public PaymentHolidayRequest getPaymentHolidayRequest() {
        return paymentHolidayRequest;
    }

    @JsonProperty("PaymentHolidayRequest")
    public void setPaymentHolidayRequest(PaymentHolidayRequest paymentHolidayRequest) {
        this.paymentHolidayRequest = paymentHolidayRequest;
    }
}
