package com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonInclude.Include;

@Getter
@Setter
@JsonInclude(Include.NON_NULL)
public class ContractsInMccDataResponse extends ModelBase {

    private OperativeSecurity operativeSecurityOutput;
    private KcError2 kcError;
    private String listEnd;
    private Repos repos;
    private DataList dataList;
    private MccAccessType mccAccessType;
    private String mccType;
}
