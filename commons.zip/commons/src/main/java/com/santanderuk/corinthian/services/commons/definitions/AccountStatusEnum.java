package com.santanderuk.corinthian.services.commons.definitions;

public enum AccountStatusEnum {
    ACTIVE,
    REDEEMED,
    SOLD,
    LITIGATION,
    MERGED,
    PENDING,
    CLOSED,
    CANCELLED;
}
