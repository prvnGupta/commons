package com.santanderuk.corinthian.services.commons.exceptions;

public class JsonParseException extends GeneralException {

    public JsonParseException(String code, String message) {
        super(code, message);
    }

    public JsonParseException(final String code, final String message, final Exception e) {
        super(code, message, e);
    }
}
