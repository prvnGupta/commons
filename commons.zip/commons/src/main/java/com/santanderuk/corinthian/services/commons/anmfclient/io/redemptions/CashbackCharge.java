package com.santanderuk.corinthian.services.commons.anmfclient.io.redemptions;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CashbackCharge extends ModelBase {

    private static final long serialVersionUID = -2787372641032827505L;
    @JsonProperty("o_sundy_type_desc")
    private String sundryTypeDescription;
    @JsonProperty("o_fee_amt")
    private BigDecimal feeAmount;
}
