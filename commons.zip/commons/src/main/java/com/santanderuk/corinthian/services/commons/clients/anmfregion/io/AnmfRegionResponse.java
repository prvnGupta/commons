package com.santanderuk.corinthian.services.commons.clients.anmfregion.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnmfRegionResponse extends ModelBase {

    private String code;
    private String message;
    private String region;
}
