
package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class OStruc extends ModelBase {

    @JsonProperty("o_acc_status")
    private String oAccStatus;
    @JsonProperty("o_acc_status_lit")
    private String oAccStatusLit;
    @JsonProperty("o_active_loan_count")
    private int oActiveLoanCount;
    @JsonProperty("o_capital_balance")
    private BigDecimal oCapitalBalance;
    @JsonProperty("o_mortgage_balance")
    private BigDecimal oMortgageBalance;
    @JsonProperty("o_arrears_balance")
    private BigDecimal oArrearsBalance;
    @JsonProperty("o_rec_balance")
    private BigDecimal oRecBalance;
    @JsonProperty("o_total_arrears")
    private BigDecimal oTotalArrears;
    @JsonProperty("o_sundries_arrears")
    private BigDecimal oSundriesArrears;
    @JsonProperty("o_sundries_rec")
    private BigDecimal oSundriesRec;
    @JsonProperty("o_ovp_balance")
    private BigDecimal oOvpBalance;
    @JsonProperty("o_outstanding_balance")
    private BigDecimal oOutstandingBalance;
    @JsonProperty("o_product_switch_outstanding_balance")
    private BigDecimal oProductSwitchOutstandingBalance;
    @JsonProperty("o_total_borrowed_amount")
    private BigDecimal oTotalBorrowedAmount;
    @JsonProperty("o_original_drawdown")
    private BigDecimal oOriginalDrawdown;
    @JsonProperty("o_cca_flexi_credit_limit_ok")
    private String oCcaFlexiCreditLimitOk;
    @JsonProperty("o_tot_credit_limit")
    private BigDecimal oTotCreditLimit;
    @JsonProperty("o_flexi_ind")
    private String oFlexiInd;
    @JsonProperty("o_mortgage_type")
    private String oMortgageType;
    @JsonProperty("o_available_funds_grp")
    private OAvailableFundsGrp oAvailableFundsGrp;
    @JsonProperty("o_flexi_overpaid_funds_grp")
    private OFlexiOverpaidFundsGrp oFlexiOverpaidFundsGrp;
    @JsonProperty("o_savings_balance_grp")
    private OSavingsBalanceGrp oSavingsBalanceGrp;
    @JsonProperty("o_credit_limit_grp")
    private OCreditLimitGrp oCreditLimitGrp;
    @JsonProperty("o_personnal_drawdown_grp")
    private OPersonnalDrawdownGrp oPersonnalDrawdownGrp;
    @JsonProperty("o_cont_mon_pay")
    private BigDecimal oContMonPay;
    @JsonProperty("o_cur_cont_mon_pay")
    private BigDecimal oCurContMonPay;
    @JsonProperty("o_next_monthly_payment")
    private BigDecimal oNextMonthlyPayment;
    @JsonProperty("o_second_monthly_payment")
    private BigDecimal oSecondMonthlyPayment;
    @JsonProperty("o_next_payment_dt")
    private String oNextPaymentDt;
    @JsonProperty("o_last_payment_dt")
    private String oLastPaymentDt;
    @JsonProperty("o_pend_next_payment_dt")
    private String oPendNextPaymentDate;
    @JsonProperty("o_first_fee_amount")
    private BigDecimal oFirstFeeAmount;
    @JsonProperty("o_lender_code")
    private int oLenderCode;
    @JsonProperty("o_lender_code_lit")
    private String oLenderCodeLit;
    @JsonProperty("o_first_completion")
    private String oFirstCompletion;
    @JsonProperty("o_original_completion_dt")
    private String oOriginalCompletionDt;
    @JsonProperty("o_delayed_completion_date")
    private String oDelayedCompletionDate;
    @JsonProperty("o_last_lit")
    private int oLastLit;
    @JsonProperty("o_lit_status")
    private int oLitStatus;
    @JsonProperty("o_secured_loan")
    private String oSecuredLoan;
    @JsonProperty("o_f_a_pending")
    private String oFAPending;
    @JsonProperty("o_ccy")
    private String oCcy;
    @JsonProperty("o_red_solicitor")
    private int oRedSolicitor;
    @JsonProperty("o_solicitor_code")
    private int oSolicitorCode;
    @JsonProperty("o_lit_solicitor_code")
    private int oLitSolicitorCode;
    @JsonProperty("o_present_location")
    private int oPresentLocation;
    @JsonProperty("o_rep_fee_paid")
    private String oRepFeePaid;
    @JsonProperty("o_rep_pd_date")
    private String oRepPdDate;
    @JsonProperty("o_rep_amt_pd")
    private BigDecimal oRepAmtPd;
    @JsonProperty("o_guarantor_mort")
    private String oGuarantorMort;
    @JsonProperty("o_subsequent_charges_present")
    private String oSubsequentChargesPresent;
    @JsonProperty("o_dhss_arrangement")
    private String oDhssArrangement;
    @JsonProperty("o_mortgage_end_date")
    private String oMortgageEndDate;
    @JsonProperty("o_remaining_term")
    private int oRemainingTerm;
    @JsonProperty("o_arr_multiplier")
    private int oArrMultiplier;
    @JsonProperty("o_psf_arr_mult")
    private int oPsfArrMult;
    @JsonProperty("o_governance_type")
    private String oGovernanceType;
    @JsonProperty("o_governance_type_lit")
    private String oGovernanceTypeLit;
    @JsonProperty("o_bankruptcy_ind")
    private String oBankruptcyInd;
    @JsonProperty("o_overpay_num")
    private int oOverpayNum;
    @JsonProperty("o_erc_allowance")
    private BigDecimal oErcAllowance;
    @JsonProperty("o_help_to_buy_guarantee_sch")
    private String oHelpToBuyGuaranteeSch;
    @JsonProperty("o_help_to_buy_guarantee_lit")
    private String oHelpToBuyGuaranteeLit;
    @JsonProperty("o_h2b_mig_expiry")
    private String oH2bMigExpiry;
    @JsonProperty("o_esto_flag")
    private String oEstoFlag;
    @JsonProperty("o_net_user")
    private String oNetUser;
    @JsonProperty("o_net_user_lit")
    private String oNetUserLit;
    @JsonProperty("o_next_statement_dt")
    private String oNextStatementDt;
    @JsonProperty("o_avail_funds_rate")
    private BigDecimal oAvailFundsRate;
    @JsonProperty("o_avail_funds_arrs")
    private BigDecimal oAvailFundsArrs;
    @JsonProperty("o_arrs_three_mths")
    private BigDecimal oArrsThreeMths;
    @JsonProperty("o_next_chosen_pay")
    private BigDecimal oNextChosenPay;
    @JsonProperty("o_psf_start_date")
    private String oPsfStartDate;
    @JsonProperty("o_days_delinquent")
    private int oDaysDelinquent;
    @JsonProperty("o_cap_rate_used")
    private String oCapRateUsed;
    @JsonProperty("o_collar_rate_used")
    private String oCollarRateUsed;
    @JsonProperty("o_linked_account")
    private List<OLinkedAccount> oLinkedAccount = null;
    @JsonProperty("o_active_blocks")
    private List<OActiveBlocks> oActiveBlocks = null;
    @JsonProperty("o_active_loans")
    private List<OActiveLoan> oActiveLoans = null;
    @JsonProperty("o_active_loan_details")
    private List<OActiveLoanDetail> oActiveLoanDetails = null;
    @JsonProperty("o_inactive_loan_details")
    private List<OInactiveLoanDetail> oInActiveLoanDetails = null;
    @JsonProperty("o_active_flexi_loan_details")
    private List<OActiveFlexiLoanDetail> oActiveFlexiLoanDetails = null;
    @JsonProperty("o_inactive_flexi_loan_details")
    private List<OInactiveFlexiLoanDetail> oInActiveFlexiLoanDetails = null;
    @JsonProperty("e_struc")
    private EStruc eStruc;

}
