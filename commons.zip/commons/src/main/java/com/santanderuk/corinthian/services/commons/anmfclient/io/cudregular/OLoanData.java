package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OLoanData extends ModelBase {

    private static final long serialVersionUID = -250212667437606397L;

    @JsonProperty("o_loan_sch")
    private String oLoanSch;
    @JsonProperty("o_appl_seq_no")
    private int oApplSeqNo;
    @JsonProperty("o_loan_order")
    private int oLoanOrder;
    @JsonProperty("o_ovp_inst_stop_erc")
    private String oOvpInstStopErc;
}
