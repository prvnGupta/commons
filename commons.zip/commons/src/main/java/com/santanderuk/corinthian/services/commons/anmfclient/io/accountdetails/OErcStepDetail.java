package com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class OErcStepDetail extends ModelBase {

    @JsonProperty("o_erc_step_seq")
    private int oErcStepSeq;
    @JsonProperty("o_erc_rate")
    private BigDecimal oErcRate;
    @JsonProperty("o_erc_multiplier")
    private BigDecimal oErcMultiplier;
    @JsonProperty("o_months_diff")
    private int oMonthsDiff;
    @JsonProperty("o_erc_start_date")
    private String oErcStartDate;
    @JsonProperty("o_erc_end_date")
    private String oErcEndDate;

}
