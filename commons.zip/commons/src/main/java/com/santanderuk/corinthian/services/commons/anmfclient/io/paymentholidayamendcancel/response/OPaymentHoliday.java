package com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
@NoArgsConstructor
public class OPaymentHoliday extends ModelBase {

    private static final long serialVersionUID = -6690954776549645705L;
    @JsonProperty("o_ph_term_req_mth")
    private int oPhTermReqMth;

    @JsonProperty("o_ph_email")
    private String oPhEmail;

    @JsonProperty("o_ph_canc_mth_used")
    private String oPhCancMthUsed;

    @JsonProperty("o_ph_event")
    private String oPhEvent;

    @JsonProperty("o_ph_term_adj_mth")
    private int oPhTermAdjMth;

    @JsonProperty("o_ph_eff_date")
    private String oPhEffDate;

    @JsonProperty("o_ph_status_desc")
    private String oPhStatusDesc;

    @JsonProperty("o_ph_mobile")
    private String oPhMobile;

    @JsonProperty("o_ph_event_date")
    private String oPhEventDate;

    @JsonProperty("o_ph_req_date")
    private String oPhReqDate;

    @JsonProperty("o_ph_status")
    private String oPhStatus;

    @JsonProperty("o_ph_app_date")
    private String oPhAppDate;

    @JsonProperty("o_ph_source_code")
    private String oPhSourceCode;

    @JsonProperty("o_ph_end_date")
    private String oPhEndDate;

    @JsonProperty("o_ph_seq")
    private int oPhSeq;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }
}
