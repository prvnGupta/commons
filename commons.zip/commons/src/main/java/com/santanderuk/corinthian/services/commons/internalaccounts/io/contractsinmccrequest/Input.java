package com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.Profile;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.Cesta;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Input extends ModelBase {

    private Profile profile;
    private String operation;
    private String conexionChannel;
    private String electronicChannel;
    private String personalizationChannel;
    private String reposCardPan;
    private Cesta cesta;
    private Cesta reposCesta;
    private BdpCustomer bdpCustomer;
    private PartenonContract mccPartenonContract;
    private PartenonContract reposPartenonContract;
    private String company;
    private String service;
    private Integer reposPresOrder;
}
