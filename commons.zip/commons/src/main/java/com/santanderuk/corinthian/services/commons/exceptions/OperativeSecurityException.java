package com.santanderuk.corinthian.services.commons.exceptions;


public class OperativeSecurityException extends GeneralException {

    public OperativeSecurityException(String code, String message) {
        super(code, message);
    }

    public OperativeSecurityException(String code, String message, Exception e) {
        super(code, message, e);
    }

}
