package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(NON_NULL)
public class AnmfRegularOverpaymentCUDRequest extends ModelBase {

    private static final long serialVersionUID = 6194075437259328887L;

    @JsonProperty("OverpaymentArrangementRequest")
    private OverpaymentArrangementRequest overpaymentArrangementRequest;

}
