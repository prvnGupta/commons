package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ILoanData {

    @JsonProperty("i_loan_sch")
    private String iLoanSch;
    @JsonProperty("i_appl_seq_no")
    private String iApplSeqNo;
    @JsonProperty("i_loan_order")
    private Integer iLoanOrder;
    @JsonProperty("i_ovp_inst_stop_erc")
    private String iOvpInstStopErc;
    @JsonProperty("i_ovp_inst_impact")
    private String iOvpInstImpact;
}
