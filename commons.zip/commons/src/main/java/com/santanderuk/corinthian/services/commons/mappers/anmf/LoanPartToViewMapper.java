package com.santanderuk.corinthian.services.commons.mappers.anmf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.definitions.ProductTypes;
import com.santanderuk.corinthian.services.commons.mappers.BodyView;
import com.santanderuk.corinthian.services.commons.mappers.HeaderView;
import com.santanderuk.corinthian.services.commons.mappers.View;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class LoanPartToViewMapper {

    public static final HeaderView FIXED = HeaderView.FIXED;
    public static final HeaderView NOT_FIXED = HeaderView.NOT_FIXED;
    private static final BodyView TRACKING = BodyView.TRACKING;
    private static final BodyView NOT_TRACKING = BodyView.NOT_TRACKING;

    public View toView(final OActiveLoanDetail oLoan) {

        final View view = new View();

        view.setHeaderView(getHeaderView(oLoan));
        view.setBodyView(getBodyView(oLoan));

        return view;
    }

    public String toAbbreviatedProductDescription(String oProductDesc) {

        String lowerCased = StringUtils.lowerCase(oProductDesc);

        int endIndex = lowerCased.indexOf('(');
        if (endIndex > 0) {

            lowerCased = lowerCased.substring(0, endIndex);
        }

        return WordUtils.capitalize(lowerCased).trim();

    }

    private HeaderView getHeaderView(final OActiveLoanDetail oLoan) {
        ProductTypes productType = getType(oLoan.getOProductDesc());
        if (productType == ProductTypes.SVR || productType == ProductTypes.FOR || productType == ProductTypes.FLEXI) {
            return NOT_FIXED;
        } else {
            return FIXED;
        }
    }

    private ProductTypes getType(final String productDescription) {
        if (null == productDescription) {
            return ProductTypes.UNKNOWN;
        }
        final String noCasingDesc = productDescription.toLowerCase();

        if (noCasingDesc.contains("fixed")) {
            return ProductTypes.FIXED;
        } else if (noCasingDesc.contains("year variable")) {
            return ProductTypes.VARIABLE;
        } else if (noCasingDesc.contains("year tracker")) {
            return ProductTypes.STT;
        } else if (noCasingDesc.contains("standard variable rate")) {
            return ProductTypes.SVR;
        } else if (noCasingDesc.contains("santander's follow-on rate")) {
            return ProductTypes.FOR;
        } else if (noCasingDesc.contains("lifetime tracker")) {
            return ProductTypes.LTT;
        } else if (noCasingDesc.contains("flexible")) {
            return ProductTypes.FLEXI;
        } else {
            return ProductTypes.UNKNOWN;
        }

    }

    private BodyView getBodyView(final OActiveLoanDetail oLoan) {
        final ProductTypes productType = getType(oLoan.getOProductDesc());
        return isVariableProduct(productType) ? TRACKING : NOT_TRACKING;
    }

    private boolean isVariableProduct(final ProductTypes productType) {
        final List<ProductTypes> listOfVariableProducts = Arrays.asList(ProductTypes.FLEXI, ProductTypes.STT, ProductTypes.LTT, ProductTypes.FOR);
        return listOfVariableProducts.contains(productType);
    }
}
