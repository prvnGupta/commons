package com.santanderuk.corinthian.services.commons.clients.bksconnect.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "profile",
        "operation",
        "inputChannel",
        "option",
        "partenonContract",
        "ldapUid"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveMccDataRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("profile")
    private Profile profile;
    @JsonProperty("operation")
    private String operation;
    @JsonProperty("inputChannel")
    private String inputChannel;
    @JsonProperty("option")
    private String option;
    @JsonProperty("partenonContract")
    private PartenonContract partenonContract;
    @JsonProperty("ldapUid")
    private String ldapUid;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("profile", profile)
                .append("operation", operation)
                .append("inputChannel", inputChannel)
                .append("option", option)
                .append("partenonContract", partenonContract)
                .append("ldapUid", ldapUid)
                .toString();
    }
}
