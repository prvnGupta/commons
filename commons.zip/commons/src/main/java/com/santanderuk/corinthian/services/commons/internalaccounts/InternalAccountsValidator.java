package com.santanderuk.corinthian.services.commons.internalaccounts;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractElement;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.commons.operativesecurity.AccountBalanceValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

import static com.santanderuk.corinthian.services.commons.operativesecurity.PersonalAccountBelongsToCustomerValidator.validateAccountBelongToCustomer;

@Component
public class InternalAccountsValidator {

    private final AccountBalanceValidator accountBalanceValidator;

    @Autowired
    public InternalAccountsValidator(AccountBalanceValidator accountBalanceValidator) {
        this.accountBalanceValidator = accountBalanceValidator;
    }

    public void validateAccountBelongToCustomerAndHasBalance(BigDecimal amount, LocalAccountNumber account, String accountBalancesUrl, List<ContractElement> contractElements) throws GeneralException {
        PartenonAccountNumber partenonAccountNumber = validateAccountBelongToCustomer(account, contractElements);
        accountBalanceValidator.validate(amount, partenonAccountNumber, accountBalancesUrl, false);
    }

    public void validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(BigDecimal amount, LocalAccountNumber account, String accountBalancesUrl, List<ContractElement> contractElements) throws GeneralException {
        PartenonAccountNumber partenonAccountNumber = validateAccountBelongToCustomer(account, contractElements);
        accountBalanceValidator.validate(amount, partenonAccountNumber, accountBalancesUrl, true);
    }
}
