package com.santanderuk.corinthian.services.commons.operativesecurity;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractElement;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;

import java.util.List;

public class PersonalAccountBelongsToCustomerValidator {

    public static PartenonAccountNumber validateAccountBelongToCustomer(LocalAccountNumber localAccountNumber, List<ContractElement> contractElements) throws ValidationsException {
        try {
            for (ContractElement contractElement : contractElements) {
                if (contractElement.getContractDetails().getLocalContract().getLocalContractNumber().contains(localAccountNumber.getSortcode().substring(0, 6).concat(getAccountNumber(localAccountNumber)))) {
                    return partenonContractToPartenonAccountNumber(contractElement.getContractDetails().getPartenonContract());
                }
            }
            throw new ValidationsException(ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT);
        } catch (Exception e) {
            throw new ValidationsException(ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_NO_ACCOUNT);
        }
    }

    private static String getAccountNumber(LocalAccountNumber localAccountNumber) {
        if (localAccountNumber.getAccountNumber().length() > 8) {
            return localAccountNumber.getAccountNumber().substring(0, 9);
        } else {
            return localAccountNumber.getAccountNumber().substring(0, 8);
        }
    }

    private static PartenonAccountNumber partenonContractToPartenonAccountNumber(PartenonContract partenonContract) {
        return new PartenonAccountNumber(
                partenonContract.getCentre().getCompany(),
                partenonContract.getCentre().getCentreCode(),
                partenonContract.getProductTypeCode(),
                partenonContract.getContractNumber()
        );
    }
}
