package com.santanderuk.corinthian.services.commons.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class ApiManagerConfig {

    @Value("${apimanager.client-id-value}")
    private String clientIdValue;

    @Value("${apimanager.client-secret-value}")
    private String clientSecretValue;

}
