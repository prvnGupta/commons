package com.santanderuk.corinthian.services.commons.clients.cae.io;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account extends ModelBase {
    private String partenonContract;
    private String alias;
    private String id;
    private String localNumber;
    private String sortCode;
    private String currency;
    private String type;
    private String confidentialFlag;
    private String last4Pan;
}
