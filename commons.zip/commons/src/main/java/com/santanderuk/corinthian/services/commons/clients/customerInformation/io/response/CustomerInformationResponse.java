package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerInformationResponse extends ModelBase {

    private static final long serialVersionUID = -6970507585445620826L;

    private String customerId;
    private CustomerBasicDataEnquire customerBasicDataEnquire;
}
