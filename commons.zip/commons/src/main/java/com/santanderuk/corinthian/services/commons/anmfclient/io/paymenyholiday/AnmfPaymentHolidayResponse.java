package com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "PaymentHolidayResponse"
})
@Getter
@Setter
@NoArgsConstructor
public class AnmfPaymentHolidayResponse extends ModelBase {
    private static final long serialVersionUID = -7294521703341557608L;

    @JsonProperty("PaymentHolidayResponse")
    private PaymentHolidayResponse paymentHolidayResponse;
}
