package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OSubseqChargeArrangementTab extends ModelBase {

    private static final long serialVersionUID = -6781865079735363675L;

    @JsonProperty("o_subseq_charge_arr")
    private List<OSubseqChargeArrangement> oSubseqChargeArrangements;
}
