package com.santanderuk.corinthian.services.commons.anmfclient;

import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpHeaders.ACCEPT;
import static org.springframework.http.HttpHeaders.CONTENT_TYPE;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@Slf4j
@Component
public class SimulationClient {

    public static final ConnectionException.Type ANMF_UNAVAILABLE = ConnectionException.Type.ANMF_UNAVAILABLE;
    public static final ConnectionException.Type ANMF_RESPONSE_BAD_FORMAT = ConnectionException.Type.ANMF_RESPONSE_BAD_FORMAT;

    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public SimulationClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    public ANMFSimulationResponse simulate(final String url, final ANMFSimulationRequest request, AnmfRegion region) throws ConnectionException {
        MultiValueMap<String, String> headers = generateHttpHeaders(region);
        HttpEntity<ANMFSimulationRequest> httpEntity = new HttpEntity<>(request, headers);
        ResponseEntity<ANMFSimulationResponse> responseEntity;

        try {
            log.info("SimulationClient - > Calling ANMF simulation microservice: {}", url);
            log.debug("SimulationClient - > Sending object: {}", request);

            responseEntity = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    ANMFSimulationResponse.class
            );
            log.info("SimulationClient - > Call to ANMF simulation microservice was OK");
            log.debug("JSON Response -> {}", responseEntity.getBody());
        } catch (RestClientException e) {
            log.error("SimulationClient -> error while connecting to ANMF Simulation microservice");
            throw new ConnectionException(ANMF_UNAVAILABLE, e);
        }
        return responseEntity.getBody();
    }

    private HttpHeaders generateHttpHeaders(AnmfRegion region) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("Region", region.toString());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add(ACCEPT, APPLICATION_JSON_VALUE);
        headers.add(CONTENT_TYPE, APPLICATION_JSON_VALUE);
        return headers;
    }

}
