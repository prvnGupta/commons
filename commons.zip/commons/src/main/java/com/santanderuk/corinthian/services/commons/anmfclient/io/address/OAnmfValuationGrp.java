package com.santanderuk.corinthian.services.commons.anmfclient.io.address;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "o_valuation_date",
        "o_valuation",
        "o_base_valuation",
        "o_valuer_firm",
        "o_valuer_name",
        "o_valuer_addr1",
        "o_valuer_addr2",
        "o_valuer_addr3",
        "o_valuer_addr4",
        "o_valuer_postcode",
        "o_valuer_phone",
        "o_valuer_code"
})
public class OAnmfValuationGrp extends ModelBase {

    private static final long serialVersionUID = 1L;

    @JsonProperty("o_valuation_date")
    public String oValuationDate;
    @JsonProperty("o_valuation")
    public BigDecimal oValuation;
    @JsonProperty("o_base_valuation")
    public BigDecimal oBaseValuation;
    @JsonProperty("o_valuer_firm")
    public String oValuerFirm;
    @JsonProperty("o_valuer_name")
    public String oValuerName;
    @JsonProperty("o_valuer_addr1")
    public String oValuerAddr1;
    @JsonProperty("o_valuer_addr2")
    public String oValuerAddr2;
    @JsonProperty("o_valuer_addr3")
    public String oValuerAddr3;
    @JsonProperty("o_valuer_addr4")
    public String oValuerAddr4;
    @JsonProperty("o_valuer_postcode")
    public String oValuerPostcode;
    @JsonProperty("o_valuer_phone")
    public String oValuerPhone;
    @JsonProperty("o_valuer_code")
    public int oValuerCode;
}
