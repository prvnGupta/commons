package com.santanderuk.corinthian.services.commons.anmfclient;

import com.santanderuk.corinthian.services.commons.anmfclient.io.warning.AnmfWarnResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.springframework.http.HttpMethod.GET;

@Slf4j
@Component
public class AnmfWarningClient {
    public static final ConnectionException.Type ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR = ConnectionException.Type.ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR;
    public static final String SHORT_LIFE_CACHE = "cacheManagerShortLife";
    public static final String KEY_ACCOUNT_WARNING_DETAILS = "fetch-account-warning-details-";
    private final RestTemplate restTemplate;
    private final ApiManagerConfig apiManagerConfig;

    @Autowired
    public AnmfWarningClient(RestTemplate restTemplate, ApiManagerConfig apiManagerConfig) {
        this.restTemplate = restTemplate;
        this.apiManagerConfig = apiManagerConfig;
    }

    @Cacheable(cacheManager = SHORT_LIFE_CACHE,
            cacheNames = "fetch-account-warning-details",
            value = "fetch-account-warning-details",
            key = "#root.target.KEY_ACCOUNT_WARNING_DETAILS + #accountNumber")
    public AnmfWarnResponse getWarningDetails(final int accountNumber, final String url, AnmfRegion region) throws ConnectionException {
        ResponseEntity<AnmfWarnResponse> responseEntity;
        try {
            String warningUrl = getWarningUrl(url, accountNumber);
            log.info("AnmfWarningClient - > Calling mortgage account details warning microservice: {}", warningUrl);

            responseEntity = restTemplate.exchange(warningUrl, GET, generateHttpEntity(region), AnmfWarnResponse.class);

            log.info("AnmfWarningClient - > Call to mortgage account details warning microservice was OK");
            log.debug("JSON Response -> {}", responseEntity.getBody());
        } catch (RestClientException e) {
            log.error("ApplyOverpaymentClient -> error while connecting to Mortgage account details warning service api");
            throw new ConnectionException(ACCOUNT_WARNING_SERVICE_CONNECTION_ERROR, e);
        }
        return responseEntity.getBody();
    }

    private HttpEntity generateHttpEntity(AnmfRegion region) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add("x-ibm-client-id", apiManagerConfig.getClientIdValue());
        headers.add("x-ibm-client-secret", apiManagerConfig.getClientSecretValue());
        headers.add("Region", region.toString());
        headers.add("Content-Type", "application/json");
        return new HttpEntity(headers);
    }

    private String getWarningUrl(final String url, final int accountNumber) {
        return url.replace("{account}", Integer.toString(accountNumber));
    }

}
