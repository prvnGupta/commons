package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AvailibilityMobile extends ModelBase {

    private static final long serialVersionUID = -9187104736386279563L;

    private String fromTimeMobile;
    private String toTimeMobile;

}



