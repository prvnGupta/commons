package com.santanderuk.corinthian.services.commons.clients.productcatalog.io;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShortestChargeEndDateResponse {

    private String code;
    private String status;
    private String message;
    private ShortestChargeEndDateData data;
}
