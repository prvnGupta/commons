package com.santanderuk.corinthian.services.commons.clients.bksconnect;

import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.*;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccrequest.*;
import org.springframework.stereotype.Component;

import static com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectConfig.*;

@Component
public class BksConnectMapper {

    public static final String EMPTY_STRING = "";

    public RetrieveMccControllerRequest getRetrieveMccRequest(final String ldapUid) {
        final RetrieveMccControllerRequest retrieveMccControllerRequest = new RetrieveMccControllerRequest();

        final Profile profile = new Profile();
        profile.setCompany(RETRIEVE_MCC_PROFILE_COMPANY);
        profile.setChannel(RETRIEVE_MCC_PROFILE_CHANNEL);
        RetrieveMccDataRequest dataRequest = new RetrieveMccDataRequest();
        dataRequest.setProfile(profile);
        dataRequest.setInputChannel(RETRIEVE_MCC_INPUT_CHANNEL);
        dataRequest.setOption(RETRIEVE_MCC_OPTION);
        dataRequest.setLdapUid(ldapUid);

        final PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany(RETRIEVE_MCC_PROFILE_COMPANY);
        centre.setCentreCode(EMPTY_STRING);
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode(EMPTY_STRING);
        partenonContract.setContractNumber(EMPTY_STRING);
        dataRequest.setPartenonContract(partenonContract);

        retrieveMccControllerRequest.setDataRequest(dataRequest);
        return retrieveMccControllerRequest;
    }

    public ContractsInMccRequest getCustomerAccountsRequest(RetrieveMccResponse retrieveMccResponse, BdpCustomer bdpCustomer) {

        SecurityInput securityInput = new SecurityInput();
        securityInput.setChannel(CONTRACTS_IN_MCC_SECURITY_INPUT_CHANNEL);

        ContractsInMccDataRequest dataRequest = new ContractsInMccDataRequest();
        dataRequest.setSecurityInput(securityInput);

        Input input = new Input();
        input.setOperation(CONTRACTS_IN_MCC_INPUT_OPERATION);
        input.setConexionChannel(CONTRACTS_IN_MCC_INPUT_CONNECTION_CHANNEL);
        input.setPersonalizationChannel(CONTRACTS_IN_MCC_INPUT_PERSONALISATION_CHANNEL);
        input.setElectronicChannel(CONTRACTS_IN_MCC_INPUT_ELECTRONIC_CHANNEL);
        input.setBdpCustomer(bdpCustomer);
        input.setMccPartenonContract(retrieveMccResponse.getDataResponse().getMccContract().getPartenonContract());
        input.setCompany(CONTRACTS_IN_MCC_INPUT_COMPANY);
        input.setService(CONTRACTS_IN_MCC_INPUT_SERVICE);
        dataRequest.setInput(input);

        ContractsInMccRequest contractsInMccRequest = new ContractsInMccRequest();
        contractsInMccRequest.setDataRequest(dataRequest);

        return contractsInMccRequest;
    }
}
