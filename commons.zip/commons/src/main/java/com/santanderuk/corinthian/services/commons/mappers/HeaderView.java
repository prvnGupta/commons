package com.santanderuk.corinthian.services.commons.mappers;

public enum HeaderView {

    NOT_FIXED, FIXED
}
