package com.santanderuk.corinthian.services.commons.clients.productdirectory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QueryParams {
    private String resultFilter;
    private String applicationType;
    private String rangeType;
}
