package com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class AvailibilityEmail extends ModelBase {

    private static final long serialVersionUID = 1665724095548138578L;

    private String fromTimeEmail;
    private String toTimeEmail;

}
