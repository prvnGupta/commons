package com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OOvpInstOvpPayGrp {

    @JsonProperty("o_ovp_inst_ovp_pay_appl")
    private String oOvpInstOvpPayAppl;
    @JsonProperty("o_ovp_inst_ovp_pay")
    private Integer oOvpInstOvpPay;
    @JsonProperty("o_ovp_inst_tot_mon_pay")
    private Integer oOvpInstTotMonPay;
}
