package com.santanderuk.corinthian.services.commons.clients.cop;

import com.santanderuk.corinthian.services.commons.clients.cop.io.ConfirmationOfPayeeRequest;
import com.santanderuk.corinthian.services.commons.clients.cop.io.VerificationReportResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class ConfirmationOfPayeeClient {

    private final RestTemplate restTemplate;

    @Value("${apimanager.client-id-value}")
    private String clientId;

    public ConfirmationOfPayeeClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public VerificationReportResponse fetchCopRequest(String url, ConfirmationOfPayeeRequest confirmationOfPayeeRequest) throws GeneralException {
        log.info("About to call Confirmation Of Payee");
        final ResponseEntity<VerificationReportResponse> verificationReportResponseResponse;
        try {
            log.debug("Calling endpoint with URL: {}", url);
            log.debug("JSON Request: {}", confirmationOfPayeeRequest);
            final HttpEntity<ConfirmationOfPayeeRequest> httpEntity = getCopEntity(confirmationOfPayeeRequest);
            verificationReportResponseResponse = restTemplate.postForEntity(
                    url,
                    httpEntity,
                    VerificationReportResponse.class);
            log.info("Confirmation Of Payee core api response received");
            log.debug("Confirmation Of Payee core api response: {}", verificationReportResponseResponse);
        } catch (Exception ex) {
            log.error("Confirmation Of Payee/handle-outbound service did not respond correctly: " , ex);
            throw new ConnectionException(ex.getMessage(), "Error while calling Confirmation Of Payee/handle-outbound api", ex);
        }
        return verificationReportResponseResponse.getBody();
    }

    private HttpEntity<ConfirmationOfPayeeRequest> getCopEntity(final ConfirmationOfPayeeRequest confirmationOfPayeeRequest) {
        final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", "application/json");
        headers.add("x-ibm-client-id", clientId);
        return new HttpEntity<>(confirmationOfPayeeRequest, headers);
    }
}
